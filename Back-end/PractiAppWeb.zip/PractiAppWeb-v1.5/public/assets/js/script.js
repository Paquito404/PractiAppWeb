function loadContent(pagina) {
    const contentDiv = document.getElementById('content');

    fetch(baseUrl + '/carga/' + pagina)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar el contenido');
                      

            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar el contenido.</p>';
            console.error('Error:', error);
        });
  }

  document.querySelectorAll('nav ul li button').forEach(btn => {
  btn.addEventListener('click', e => {
    e.preventDefault();
    const pagina = btn.getAttribute('onclick').match(/'(.+?)'/)[1];
    loadContent(pagina);

    setTimeout(() => window.scrollTo(0, 0), 50);
  });
});
  
  window.onload = function () {
        loadContent('inicio');

    
  };

// -------------------------------------------------------------------------- //

// -------------------------- usuario.php ------------------------------ //

function mostrarAlumno(){
    if (!idUsuario) {
        document.getElementById('infoUsuario').innerHTML = `<p>Error: ID de usuario no disponible.</p>`;
        document.getElementById('usuarioPanel').style.display = 'block';
               

        return;
    }

    fetch(`${baseUrl}obtenerA/${idUsuario}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                document.getElementById('infoUsuario').innerHTML = `<p>${data.error}</p>`;
            } else {
                const imgPath = `${baseUrl}alumnos/${data.ID}-${data.correo}.jpg`;
                document.getElementById('infoUsuario').innerHTML = `
                    <img src="${imgPath}" alt="Foto de perfil" width="100"><br>
                    <strong>Nombre:</strong> ${data.nombre}<br>
                    <strong>Carrera:</strong> ${data.carrera}<br>
                    <strong>Correo:</strong> ${data.correo}<br>
                `;
            }
            document.getElementById('usuarioPanel').style.display = 'block';
        })
        .catch(error => {
            console.error('Error al obtener los datos del alumno:', error);
            document.getElementById('infoUsuario').innerHTML = `<p>Error al cargar la información.</p>`;
            document.getElementById('usuarioPanel').style.display = 'block';
        });
}

function mostrarMaestro(){
    if (!idUsuario) {
        document.getElementById('infoUsuario').innerHTML = `<p>Error: ID de usuario no disponible.</p>`;
        document.getElementById('usuarioPanel').style.display = 'block';
        return;
    }

    fetch(`${baseUrl}obtenerM/${idUsuario}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                document.getElementById('infoUsuario').innerHTML = `<p>${data.error}</p>`;
            } else {
                const imgPath = `${baseUrl}maestros/${data.ID}-${data.correo}.jpg`;
                document.getElementById('infoUsuario').innerHTML = `
                    <img src="${imgPath}" alt="Foto de perfil" width="100"><br>
                    <strong>Nombre:</strong> ${data.nombre}<br>
                    <strong>Departamento:</strong> ${data.departamento}<br>
                    <strong>Correo:</strong> ${data.correo}<br>
                `;
            }
            document.getElementById('usuarioPanel').style.display = 'block';
        })
        .catch(error => {
            console.error('Error al obtener los datos del maestro:', error);
            document.getElementById('infoUsuario').innerHTML = `<p>Error al cargar la información.</p>`;
            document.getElementById('usuarioPanel').style.display = 'block';
        });
}

function mostrarCoordinador(){
    if (!idUsuario) {
        document.getElementById('infoUsuario').innerHTML = `<p>Error: ID de usuario no disponible.</p>`;
        document.getElementById('usuarioPanel').style.display = 'block';
        return;
    }

    fetch(`${baseUrl}obtenerC/${idUsuario}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                document.getElementById('infoUsuario').innerHTML = `<p>${data.error}</p>`;
            } else {
                const imgPath = `${baseUrl}coordinadores/${data.ID}-${data.correo}.jpg`;
                document.getElementById('infoUsuario').innerHTML = `
                    <img src="${imgPath}" alt="Foto de perfil" width="100"><br>
                    <strong>Nombre:</strong> ${data.nombre}<br>
                    <strong>Departamento:</strong> ${data.departamento}<br>
                    <strong>Correo:</strong> ${data.correo}<br>
                `;
            }
            document.getElementById('usuarioPanel').style.display = 'block';
        })
        .catch(error => {
            console.error('Error al obtener los datos del coordinador:', error);
            document.getElementById('infoUsuario').innerHTML = `<p>Error al cargar la información.</p>`;
            document.getElementById('usuarioPanel').style.display = 'block';
        });
}

function mostrarModerador() {
    if (!idUsuario) {
        document.getElementById('infoUsuario').innerHTML = `<p>Error: ID de usuario no disponible.</p>`;
        document.getElementById('usuarioPanel').style.display = 'block';
        return;
    }

    fetch(`${baseUrl}obtenerMo/${idUsuario}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                document.getElementById('infoUsuario').innerHTML = `<p>${data.error}</p>`;
            } else {
                const imgPath = `${baseUrl}moderadores/${data.ID}-${data.correo}.jpg`;
                document.getElementById('infoUsuario').innerHTML = `
                    <img src="${imgPath}" alt="Foto de perfil" width="100"><br>
                    <strong>Nombre:</strong> ${data.nombre}<br>
                    <strong>Departamento:</strong> ${data.departamento}<br>
                    <strong>Correo:</strong> ${data.correo}<br>
                `;
            }
            document.getElementById('usuarioPanel').style.display = 'block';
        })
        .catch(error => {
            console.error('Error al obtener los datos del moderador:', error);
            document.getElementById('infoUsuario').innerHTML = `<p>Error al cargar la información.</p>`;
            document.getElementById('usuarioPanel').style.display = 'block';
        });
}

function cerrarPanel() {
    document.getElementById('usuarioPanel').style.display = 'none';
}


// -------------------------------------------------------------------------- //

// --------------------------- revisar.php ---------------------------------- //

function revisar(id) {
      const contentDiv = document.getElementById('content');
      fetch(`${baseUrl}/revision/${id}`)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al cargar la práctica');
              }
              return response.text();
          })
          .then(data => {
              contentDiv.innerHTML = data;
          })
          .catch(error => {
              contentDiv.innerHTML = '<p>Error al cargar la práctica.</p>';
              console.error('Error:', error);
          });
  }

function fase(id) {
    fetch(`${baseUrl}/fase/${id}`, {
        method: 'POST'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error al actualizar la práctica');
        }
          
        return response.json();
    })
    .then(data => {
         alert('Se aprobo el proyecto');
        if (data.success) {
           
            loadContent('inicio');
        }
         
    })
    .catch(error => {
        console.error('Error:', error);
    });
}



function Restaurar(id) {
    fetch(`${baseUrl}/fase/${id}`, {
        method: 'POST'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error al actualizar la práctica');
        }
          
        return response.json();
    })
    .then(data => {
       alert('Se restauro tu proyecto');
        if (data.success) {
           
            loadContent('inicio');
        }
         
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

// ------------------------------------------------------------------------ //

// --------------------------- papelera.php ------------------------------- //

function papelera(id) {
    fetch(`${baseUrl}/papelera/${id}`, {
        method: 'POST'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error al actualizar la práctica');
        }
        return response.json();
    })
    .then(data => {
        alert('Se mando a papelera tu proyecto');

        if (data.success) {
            loadContent('inicio');
            
        }
    })
    .catch(error => {
        console.error('Error:', error);
        
    });
}

function borrar(id) {
      const contentDiv = document.getElementById('content');
    
      fetch(`${baseUrl}/borracion/${id}`)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al cargar la práctica');
              }
              return response.text();
          })
          .then(data => {
              contentDiv.innerHTML = data;
          })
          .catch(error => {
              contentDiv.innerHTML = '<p>Error al cargar la práctica.</p>';
              console.error('Error:', error);
          });
  }

// ------------------------------------------------------------------------ //

// --------------------------- CRUD PRACTICAS ----------------------------- //

  function loadPractica(id) {
      const contentDiv = document.getElementById('content');
      fetch(`${baseUrl}/vista/${id}`)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al cargar la práctica');
              }
              return response.text();
          })
          .then(data => {
              contentDiv.innerHTML = data;
          })
          .catch(error => {
              contentDiv.innerHTML = '<p>Error al cargar la práctica.</p>';
              console.error('Error:', error);
              
          });
  }
  
  function editarPractica(id) {
      const contentDiv = document.getElementById('content');
      
      fetch(`${baseUrl}/editar/${id}`)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al cargar el formulario de edición');
              }
              return response.text();
          })
          .then(data => {
              contentDiv.innerHTML = data;
          })
          .catch(error => {
              contentDiv.innerHTML = '<p>Error al cargar el formulario de edición.</p>';
              console.error('Error:', error);
          });
  }
  
  function actualizarPractica(event, id) {
      event.preventDefault();
      
      const form = event.target;
      const formData = new FormData(form);
      
      fetch(`${baseUrl}/actualizar/${id}`, {
          method: 'POST',
          body: formData
      })
      .then(response => {
          if (!response.ok) {
              throw new Error('Error al actualizar la práctica');
          }
          return response.json();
      })
      .then(data => {
          if (data.success) {
           
              loadContent('inicio');
                alert('Se actualizo tu practica');
          }
      })
      .catch(error => {
          console.error('Error:', error);      
      });
  }
  
  function eliminarPractica(id) {
      if (confirm('¿Estás seguro de que deseas eliminar esta práctica?')) {

          fetch(`${baseUrl}/eliminar/${id}`, {

              method: 'DELETE'
             
          })

          
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al eliminar la práctica');
              }
              return response.json();
          })
          .then(data => {
              if (data.success) {
                  loadContent('inicio');
                    alert('Se elimino tu practica');
            
              }
          })
          .catch(error => {
              console.error('Error:', error);
          });
      }
      
  }
// --------------------------------------------------------------------- //

function mostrarIMG(){
    document.getElementById('imagen').addEventListener('change', function (event) {
            const file = event.target.files[0];
            const reader = new FileReader();

            reader.onload = function () {
                let output = document.getElementById('vistaPrevia');
                output.src = reader.result;
                output.style.display = 'block';
            }
            reader.readAsDataURL(file);

                         
                   

        });
}

function filtrarFilas() {
    const input = document.getElementById("buscador");
    const filter = input.value.toLowerCase();
    const botones = document.querySelectorAll(".boton-buscador");

    botones.forEach(btn => {
        const nombre = btn.innerText.toLowerCase();
        btn.style.display = nombre.includes(filter) ? "" : "none";
    });
}

function aplicarFiltros() {
    const estatus = document.getElementById("filtro-estatus").value;
    const fecha = document.getElementById("filtro-fecha").value;
    const carrera = document.getElementById("filtro-carrera").value;
    const integrantes = document.getElementById("filtro-integrantes").value;

    const params = new URLSearchParams({
        estatus,
        fecha,
        carrera,
        integrantes
    });

    fetch(`${baseUrl}/carga/buscar?${params}`)
        .then(res => res.text())
        .then(html => {
            
            const temp = document.createElement('div');
            temp.innerHTML = html;
            const practicas = temp.querySelector("#resultado-filtro");

            if (practicas) {
                document.getElementById("resultado-filtro").innerHTML = practicas.innerHTML;
            }
        })
        .catch(err => {
            console.error("Error al aplicar filtros:", err);
        });
}

function restaurarFiltros() {
    document.getElementById("filtro-estatus").value = "";
    document.getElementById("filtro-fecha").value = "";
    document.getElementById("filtro-carrera").value = "";
    document.getElementById("filtro-integrantes").value = "";

    aplicarFiltros(); 
}

  // ----------------------------- Alumnos ------------------------------- //

  function loadPracticaA(id) {
      const contentDiv = document.getElementById('content');
    
      fetch(`${baseUrl}/vistaA/${id}`)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al cargar la práctica');
              }
              return response.text();
          })
          .then(data => {
              contentDiv.innerHTML = data;

              
          })
          .catch(error => {
              contentDiv.innerHTML = '<p>Error al cargar la práctica.</p>';
              console.error('Error:', error);
          });
  }

  function aplicar(id) {
    const contentDiv = document.getElementById('content');
    if(confirm('Estas seguro de que quieres aplicar para esta practica??')){

        fetch(`${baseUrl}/aplicar/${id}`)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al cargar la práctica');
              }
              return response.text();
          })
          .then(data => {
            alert("Haz aplicado a esta practica");
              contentDiv.innerHTML = data;
                 
          })
          .catch(error => {
              contentDiv.innerHTML = '<p>Error al cargar la práctica</p>';
              console.error('Error:', error);
          });

    }

  }

  function estudiantes(id) {
      const contentDiv = document.getElementById('content');
    
      fetch(`${baseUrl}/estudiantes/${id}`)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al cargar la lista');
              }
              return response.text();
          })
          .then(data => {
              contentDiv.innerHTML = data;
          })
          .catch(error => {
              contentDiv.innerHTML = '<p>Error al cargar la lista.</p>';
              console.error('Error:', error);
          });
  }

  function postulados(id) {
      const contentDiv = document.getElementById('content');
    
      fetch(`${baseUrl}/postulados/${id}`)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al cargar la lista');
              }
              return response.text();
          })
          .then(data => {
              contentDiv.innerHTML = data;
          })
          .catch(error => {
              contentDiv.innerHTML = '<p>Error al cargar la lista.</p>';
              console.error('Error:', error);
          });
  }

  function datos_estudiante(id) {
      const contentDiv = document.getElementById('content');
    
      fetch(`${baseUrl}/datos_estudiante/${id}`)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al cargar el estudiante');
              }
              return response.text();
          })
          .then(data => {
              contentDiv.innerHTML = data;
          })
          .catch(error => {
              contentDiv.innerHTML = '<p>Error al cargar el estudiante.</p>';
              console.error('Error:', error);
          });
  }

  function datos_postulados(id) {
      const contentDiv = document.getElementById('content');
    
      fetch(`${baseUrl}/datos_postulados/${id}`)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al cargar el estudiante');
              }
              return response.text();
          })
          .then(data => {
              contentDiv.innerHTML = data;
          })
          .catch(error => {
              contentDiv.innerHTML = '<p>Error al cargar el estudiante.</p>';
              console.error('Error:', error);
          });
  }

  function aprobar(id) {
      const contentDiv = document.getElementById('content');
      if(confirm('seguro de que quieres aprobar el estudiante')){

        fetch(`${baseUrl}/aprobar/${id}`)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al aprobar el estudiante');
              }
              return response.text();
          })
          .then(data => {
            alert('Alumno aprobado');
              contentDiv.innerHTML = data;
          })
          .catch(error => {
              contentDiv.innerHTML = '<p>Error al aprobar el estudiante</p>';
              console.error('Error:', error);
          });

      }
  }

  function rechazar(id) {
      const contentDiv = document.getElementById('content');
      if(confirm(' seguro de que quieres retirar el alumno de la practica')){

        fetch(`${baseUrl}/rechazar/${id}`)
          .then(response => {
              if (!response.ok) {
                  throw new Error('Error al rechazar el estudiante');
              }
              return response.text();
          })
          .then(data => {
            alert('Alumno rechazado');
              contentDiv.innerHTML = data;
          })
          .catch(error => {
              contentDiv.innerHTML = '<p>Error al rechazar el estudiante.</p>';
              console.error('Error:', error);
          });

      }
  }
  // --------------------------------------------------------------------- //