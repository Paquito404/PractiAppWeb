<?php if (session()->has('success')): ?>
  <div class="alert alert-success">
    <?= session()->getFlashdata('success') ?>
  </div>
<?php endif; ?>
<h1>Formulario</h1>
<p>Aqui tendras un formulario para subir proyectos</p>
<br></br>

<?php 

$departamento = session()->get('departamento');
$tipo = session()->get('tipo');

?><body>
    


<form action="<?php echo base_url('escuela')?>" method="post" autocomplete="off" enctype="multipart/form-data">

    <h2>Titulo</h2>
    <input type="text" name="Titulo" id="Titulo" required>
    <br>

    <h2>Requisitos</h2>
    <input type="number" name="Requisitos" id="Requisitos" required>
    <br>

    <h2>Carrera</h2>
    <select name="Carrera" id="Carrera" required>
        <option value="">Seleccione una opción</option>

        <?php if ($tipo != 'moderador'): ?>
            <?php foreach ($carrera as $car): ?>
                <?php if ($car['Departamento'] == $departamento): ?>
                    <option value=<?= $car['nombre'] ?>><?= $car['nombre'] ?></option>
                <?php endif; ?>
            <?php endforeach; ?>    
        <?php else: ?>
            <?php foreach ($carrera as $car): ?>
                <option value=<?= $car['nombre'] ?>><?= $car['nombre'] ?></option>
            <?php endforeach; ?> 
        <?php endif; ?>
    </select>
    <br>

    <h2>Estatus</h2>
    <select name="Estatus" id="Estatus" required>
        <option value="">Seleccione una opción</option>
        <option value="Activo">Activo</option>
        <option value="Inactivo">Inactivo</option>
    </select>
    <br>

    <h2>Integrantes</h2>
    <input type="number" name="Integrantes" id="Integrantes" required>
    <br>

    <h2>Pago</h2>
    <input type="number" name="Pago" id="Pago" required>
    <br>

    <h2>HorarioInicio</h2>
    <input type="time" name="HorarioInicio" id="HorarioInicio" required>
    <br>

    <h2>HorarioFinal</h2>
    <input type="time" name="HorarioFinal" id="HorarioFinal" required>
    <br>

    <h2>FechaRegistroInicio</h2>
    <input type="date" name="FechaRegistroInicio" id="FechaRegistroInicio" required>
    <br>

    <h2>FechaRegistroFinal</h2>
    <input type="date" name="FechaRegistroFinal" id="FechaRegistroFinal" required>
    <br>

    <h2>FechaActividadInicio</h2>
    <input type="date" name="FechaActividadInicio" id="FechaActividadInicio" required>
    <br>

    <h2>FechaActividadFinal</h2>
    <input type="date" name="FechaActividadFinal" id="FechaActividadFinal" required>
    <br>

    <h2>Imagen (JPG)</h2>

  
    <input type="file" id="imagen" name="imagen" accept="image/jpeg" onclick= "mostrarIMG()" required>
        <br>
        <img id="vistaPrevia" src="#" alt="Vista previa"
            style="display:none; max-width: 300px; max-height: 300px;">
        <br>

    <br>
    <input type="submit" name="Subir" id="Subir">
    <br>

</form>
</body>
<?php if (session()->getFlashdata('imagen_subida')): ?>
<script>
    alert("<?= session()->getFlashdata('imagen_subida') ?>");
</script>
<?php endif; ?>