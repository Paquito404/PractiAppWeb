function loadContent(pagina) {
    const contentDiv = document.getElementById('content');

    fetch(baseUrl + '/carga/' + pagina)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar el contenido');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
            initializeImageUploadPreviews();
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar el contenido.</p>';
            console.error('Error:', error);
        });
}

document.querySelectorAll('nav ul li button').forEach(btn => {
    btn.addEventListener('click', e => {
        e.preventDefault();
        const pagina = btn.getAttribute('onclick').match(/'(.+?)'/)[1];
        loadContent(pagina);
        setTimeout(() => window.scrollTo(0, 0), 50);
    });
});

window.onload = function () {
    loadContent('inicio');
    initializeProfileDropdown();
    updateActiveNavItem();
};


function initializeProfileDropdown() {
    const profileIcon = document.getElementById('profileIcon');
    const profileDropdown = document.getElementById('profileDropdown');

    if (profileIcon && profileDropdown) {
        profileIcon.addEventListener('click', function (e) {
            e.stopPropagation();
            profileDropdown.classList.toggle('active');
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function (e) {
            if (!profileIcon.contains(e.target) && !profileDropdown.contains(e.target)) {
                profileDropdown.classList.remove('active');
            }
        });
    }
}


function updateActiveNavItem() {
    const navLinks = document.querySelectorAll('.nav-item a');
    navLinks.forEach(link => {
        link.addEventListener('click', function () {
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });
}


function initializeImageUploadPreviews() {
    const inputs = document.querySelectorAll('#imagen');
    inputs.forEach(input => {
        const area = document.getElementById('imageUploadArea') || document.getElementById('imageUploadAreaC');
        const preview = document.getElementById('vistaPrevia') || document.getElementById('vistaPreviaC');
        if (!area || !preview) return;
        // Avoid duplicating listeners
        area.addEventListener('click', () => input.click(), { once: true });
        input.addEventListener('change', function (e) {
            const file = e.target.files && e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = function (evt) {
                preview.src = evt.target.result;
                preview.style.display = 'block';
                const ph = area.querySelector('.upload-placeholder');
                if (ph) ph.style.display = 'none';
            };
            reader.readAsDataURL(file);
        }, { once: true });
    });
}


function activateNavForPage(pageKey) {
    const navLinks = document.querySelectorAll('.nav-item a');
    let target = null;
    navLinks.forEach(link => {
        const on = link.getAttribute('onclick') || '';
        if (on.includes("'" + pageKey + "'") || on.includes('"' + pageKey + '"')) {
            target = link;
        }
    });
    if (target) {
        navLinks.forEach(l => l.classList.remove('active'));
        target.classList.add('active');
    }
}


window.goToAvailable = function () {
    activateNavForPage('inicio');
    loadContent('inicio');
}





function mostrarAlumno() {
    if (!idUsuario) {
        document.getElementById('infoUsuario').innerHTML = `<p>Error: ID de usuario no disponible.</p>`;
        document.getElementById('usuarioPanel').style.display = 'block';
        return;
    }

    fetch(`${baseUrl}obtenerA/${idUsuario}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                document.getElementById('infoUsuario').innerHTML = `<p>${data.error}</p>`;
            } else {
                const imgPath = `${baseUrl}alumnos/${data.ID}-${data.correo}.jpg`;
                document.getElementById('infoUsuario').innerHTML = `
                    <img src="${imgPath}" alt="Foto de perfil" width="100"><br>
                    <strong>Nombre:</strong> ${data.nombre}<br>
                    <strong>Carrera:</strong> ${data.carrera}<br>
                    <strong>Correo:</strong> ${data.correo}<br>
                `;
            }
            document.getElementById('usuarioPanel').style.display = 'block';
        })
        .catch(error => {
            console.error('Error al obtener los datos del alumno:', error);
            document.getElementById('infoUsuario').innerHTML = `<p>Error al cargar la información.</p>`;
            document.getElementById('usuarioPanel').style.display = 'block';
        });
}

function mostrarMaestro() {
    if (!idUsuario) {
        document.getElementById('infoUsuario').innerHTML = `<p>Error: ID de usuario no disponible.</p>`;
        document.getElementById('usuarioPanel').style.display = 'block';
        return;
    }

    fetch(`${baseUrl}obtenerM/${idUsuario}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                document.getElementById('infoUsuario').innerHTML = `<p>${data.error}</p>`;
            } else {
                const imgPath = `${baseUrl}maestros/${data.ID}-${data.correo}.jpg`;
                document.getElementById('infoUsuario').innerHTML = `
                    <img src="${imgPath}" alt="Foto de perfil" width="100"><br>
                    <strong>Nombre:</strong> ${data.nombre}<br>
                    <strong>Departamento:</strong> ${data.departamento}<br>
                    <strong>Correo:</strong> ${data.correo}<br>
                `;
            }
            document.getElementById('usuarioPanel').style.display = 'block';
        })
        .catch(error => {
            console.error('Error al obtener los datos del maestro:', error);
            document.getElementById('infoUsuario').innerHTML = `<p>Error al cargar la información.</p>`;
            document.getElementById('usuarioPanel').style.display = 'block';
        });
}

function mostrarCoordinador() {
    if (!idUsuario) {
        document.getElementById('infoUsuario').innerHTML = `<p>Error: ID de usuario no disponible.</p>`;
        document.getElementById('usuarioPanel').style.display = 'block';
        return;
    }

    fetch(`${baseUrl}obtenerC/${idUsuario}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                document.getElementById('infoUsuario').innerHTML = `<p>${data.error}</p>`;
            } else {
                const imgPath = `${baseUrl}coordinadores/${data.ID}-${data.correo}.jpg`;
                document.getElementById('infoUsuario').innerHTML = `
                    <img src="${imgPath}" alt="Foto de perfil" width="100"><br>
                    <strong>Nombre:</strong> ${data.nombre}<br>
                    <strong>Departamento:</strong> ${data.departamento}<br>
                    <strong>Correo:</strong> ${data.correo}<br>
                `;
            }
            document.getElementById('usuarioPanel').style.display = 'block';
        })
        .catch(error => {
            console.error('Error al obtener los datos del coordinador:', error);
            document.getElementById('infoUsuario').innerHTML = `<p>Error al cargar la información.</p>`;
            document.getElementById('usuarioPanel').style.display = 'block';
        });
}

function mostrarModerador() {
    if (!idUsuario) {
        document.getElementById('infoUsuario').innerHTML = `<p>Error: ID de usuario no disponible.</p>`;
        document.getElementById('usuarioPanel').style.display = 'block';
        return;
    }

    fetch(`${baseUrl}obtenerMo/${idUsuario}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                document.getElementById('infoUsuario').innerHTML = `<p>${data.error}</p>`;
            } else {
                const imgPath = `${baseUrl}moderadores/${data.ID}-${data.correo}.jpg`;
                document.getElementById('infoUsuario').innerHTML = `
                    <img src="${imgPath}" alt="Foto de perfil" width="100"><br>
                    <strong>Nombre:</strong> ${data.nombre}<br>
                    <strong>Departamento:</strong> ${data.departamento}<br>
                    <strong>Correo:</strong> ${data.correo}<br>
                `;
            }
            document.getElementById('usuarioPanel').style.display = 'block';
        })
        .catch(error => {
            console.error('Error al obtener los datos del moderador:', error);
            document.getElementById('infoUsuario').innerHTML = `<p>Error al cargar la información.</p>`;
            document.getElementById('usuarioPanel').style.display = 'block';
        });
}

function cerrarPanel() {
    document.getElementById('usuarioPanel').style.display = 'none';
}





// Expose selection handlers globally for revisar view
window.selectReviewProject = function (cardEl) {
    const id = cardEl.dataset.id;
    const titulo = cardEl.dataset.titulo || 'Proyecto';
    const carrera = cardEl.dataset.carrera || '—';
    const estado = cardEl.dataset.estado || '—';
    const integrantes = cardEl.dataset.integrantes || '—';
    const imgUrl = cardEl.dataset.img || '';

    const panel = document.getElementById('revDetailPanel');
    if (!panel) return;

    const imageBlock = imgUrl
        ? `<div class="selected-project-image" id="revImageWrapper"><img src="${imgUrl}" alt="Imagen del proyecto" style="width:100%;height:100%;object-fit:cover;"></div>`
        : `<div class="selected-project-image placeholder" id="revImageWrapper"><span>Sin imagen disponible</span></div>`;

    panel.innerHTML = `
        ${imageBlock}
        <div id="revDetailSection">
            <div class="selected-project-info">
                <h3 id="revTitulo">${titulo}</h3>
                <div class="detail-row"><strong>ID del Proyecto:</strong><p id="revId">${id}</p></div>
                <div class="detail-row"><strong>Carrera:</strong><p id="revCarrera">${carrera}</p></div>
                <div class="detail-row"><strong>Estado:</strong><p id="revEstado">${estado}</p></div>
                <div class="detail-row"><strong>Integrantes:</strong><p id="revIntegrantes">${integrantes}</p></div>
                <div class="detail-row"><strong>Fase:</strong><p>En revisión (Fase 1)</p></div>
            </div>
            <div class="button-container">
                <button class="btn btn-secondary" id="revRejectBtn" onclick="rejectSelected()" data-id="${id}">Desaprobar Proyecto</button>
                <button class="btn btn-primary" id="revApproveBtn" onclick="approveSelected()" data-id="${id}">Aprobar Proyecto</button>
            </div>
        </div>`;
};

window.approveSelected = function () {
    const btn = document.getElementById('revApproveBtn');
    if (btn && btn.dataset.id) {
        fase(btn.dataset.id);
    }
}

window.rejectSelected = function () {
    const btn = document.getElementById('revRejectBtn');
    if (btn && btn.dataset.id) {
        papelera(btn.dataset.id);
    }
}


window.selectTrashProject = function (cardEl) {
    const id = cardEl.dataset.id;
    const titulo = cardEl.dataset.titulo || 'Proyecto';
    const carrera = cardEl.dataset.carrera || '—';
    const estado = cardEl.dataset.estado || '—';
    const integrantes = cardEl.dataset.integrantes || '—';
    const imgUrl = cardEl.dataset.img || '';

    const panel = document.getElementById('trashDetailPanel');
    if (!panel) return;

    const imageBlock = imgUrl
        ? `<div class="selected-project-image" id="trashImageWrapper"><img src="${imgUrl}" alt="Imagen del proyecto" style="width:100%;height:100%;object-fit:cover;"></div>`
        : `<div class="selected-project-image placeholder" id="trashImageWrapper"><span>Sin imagen disponible</span></div>`;

    panel.innerHTML = `
        ${imageBlock}
        <div id="trashDetailSection">
            <div class="selected-project-info">
                <h3 id="trashTitulo">${titulo}</h3>
                <div class="detail-row"><strong>ID del Proyecto:</strong><p id="trashId">${id}</p></div>
                <div class="detail-row"><strong>Carrera:</strong><p id="trashCarrera">${carrera}</p></div>
                <div class="detail-row"><strong>Estado:</strong><p id="trashEstado">${estado}</p></div>
                <div class="detail-row"><strong>Integrantes:</strong><p id="trashIntegrantes">${integrantes}</p></div>
                <div class="detail-row"><strong>Fase:</strong><p>En papelera (Fase 0)</p></div>
            </div>
            <div class="button-container">
                <button class="btn btn-secondary" id="trashRestoreBtn" onclick="restoreSelected()" data-id="${id}">Restaurar</button>
                <button class="btn btn-primary" id="trashDeleteBtn" onclick="executeTrashDeletion(event)" data-id="${id}">Eliminar definitivamente</button>
            </div>
        </div>`;
};

window.restoreSelected = function () {
    const btn = document.getElementById('trashRestoreBtn');
    if (btn && btn.dataset.id) {
        showConfirm('¿Estás seguro de que deseas restaurar este proyecto?', function () {
            fetch(`${baseUrl}/fase/${btn.dataset.id}`, { method: 'POST' })
                .then(r => r.ok ? r.json() : Promise.reject())
                .then(data => {
                    if (data.success) { // Assuming backend returns {success:true} similar to other endpoints
                        showSuccess('Proyecto restaurado correctamente', function () {
                            loadContent('papelera');
                        });
                    } else {
                        // Fallback if data.success is missing but request was ok, or handle specific error
                        showSuccess('Proyecto restaurado correctamente', function () {
                            loadContent('papelera');
                        });
                    }
                })
                .catch(() => showError('Error al restaurar el proyecto'));
        });
    }
}

window.executeTrashDeletion = function (event) {
    if (event) event.preventDefault();
    const btn = document.getElementById('trashDeleteBtn');
    if (btn && btn.dataset.id) {
        const id = btn.dataset.id;
        showConfirm('¿Estás seguro de que deseas eliminar este proyecto definitivamente?', function () {
            fetch(`${baseUrl}coordinador/eliminarPermanente/${id}`, {
                method: 'POST'
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showSuccess('Proyecto eliminado', function () {
                            loadContent('papelera');
                        });
                    } else {
                        showError('Error al eliminar el proyecto');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showError('Error al eliminar el proyecto');
                });
        });
    }
}

function revisar(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/revision/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar la práctica');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
            initializeImageUploadPreviews();
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar la práctica.</p>';
            console.error('Error:', error);
        });
}

function fase(id) {
    fetch(`${baseUrl}/fase/${id}`, {
        method: 'POST'
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al actualizar la práctica');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                showSuccess('Estado del proyecto actualizado', function () {
                    loadContent('inicio');
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Error al actualizar la práctica');
        });
}





function papelera(id) {
    showConfirm('¿Estás seguro de que deseas enviar este proyecto a la papelera?', function () {
        fetch(`${baseUrl}/papelera/${id}`, {
            method: 'POST'
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al actualizar la práctica');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    showSuccess('Proyecto enviado a la papelera', function () {
                        loadContent('inicio');
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showError('Error al actualizar la práctica');
            });
    });
}

function borrar(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/borracion/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar la práctica');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
            initializeImageUploadPreviews();
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar la práctica.</p>';
            console.error('Error:', error);
        });
}





function loadPractica(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/vista/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar la práctica');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
            initializeImageUploadPreviews();
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar la práctica.</p>';
            console.error('Error:', error);
        });
}

function editarPractica(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/editar/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar el formulario de edición');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar el formulario de edición.</p>';
            console.error('Error:', error);
        });
}

function actualizarPractica(event, id) {
    event.preventDefault();

    const form = event.target;
    const formData = new FormData(form);

    fetch(`${baseUrl}/actualizar/${id}`, {
        method: 'POST',
        body: formData
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al actualizar la práctica');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                showSuccess('Práctica actualizada correctamente', function () {
                    loadContent('inicio');
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Error al actualizar la práctica');
        });
}

function eliminarPractica(id) {
    showConfirm('¿Estás seguro de que deseas eliminar esta práctica?', function () {
        fetch(`${baseUrl}/eliminar/${id}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al eliminar la práctica');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    showSuccess('Práctica eliminada correctamente', function () {
                        loadContent('inicio');
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showError('Error al eliminar la práctica');
            });
    });
}


function mostrarIMG() {
    document.getElementById('imagen').addEventListener('change', function (event) {
        const file = event.target.files[0];
        const reader = new FileReader();

        reader.onload = function () {
            let output = document.getElementById('vistaPrevia');
            output.src = reader.result;
            output.style.display = 'block';
        }
        reader.readAsDataURL(file);
    });
}

function filtrarFilas() {
    const input = document.getElementById("buscador");
    const filter = input.value.toLowerCase();
    const botones = document.querySelectorAll(".boton-buscador");

    botones.forEach(btn => {
        const nombre = btn.innerText.toLowerCase();
        btn.style.display = nombre.includes(filter) ? "" : "none";
    });
}

function aplicarFiltros() {
    const estatus = document.getElementById("filtro-estatus").value;
    const fecha = document.getElementById("filtro-fecha").value;
    const carrera = document.getElementById("filtro-carrera").value;
    const integrantes = document.getElementById("filtro-integrantes").value;

    const params = new URLSearchParams({
        estatus,
        fecha,
        carrera,
        integrantes
    });

    fetch(`${baseUrl}/carga/buscar?${params}`)
        .then(res => res.text())
        .then(html => {

            const temp = document.createElement('div');
            temp.innerHTML = html;
            const practicas = temp.querySelector("#resultado-filtro");

            if (practicas) {
                document.getElementById("resultado-filtro").innerHTML = practicas.innerHTML;
            }
        })
        .catch(err => {
            console.error("Error al aplicar filtros:", err);
        });
}

function restaurarFiltros() {
    document.getElementById("filtro-estatus").value = "";
    document.getElementById("filtro-fecha").value = "";
    document.getElementById("filtro-carrera").value = "";
    document.getElementById("filtro-integrantes").value = "";

    aplicarFiltros();
}

// ----------------------------- Alumnos ------------------------------- //

function loadPracticaA(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/vistaA/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar la práctica');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar la práctica.</p>';
            console.error('Error:', error);
        });
}

function aplicar(id) {
    const contentDiv = document.getElementById('content');
    showConfirm('¿Estás seguro de que quieres aplicar para esta práctica?', function () {

        fetch(`${baseUrl}/aplicar/${id}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al cargar la práctica');
                }
                return response.text();
            })
            .then(data => {
                contentDiv.innerHTML = data;
                showSuccess('Has aplicado correctamente');
            })
            .catch(error => {
                contentDiv.innerHTML = '<p>Error al cargar la práctica</p>';
                console.error('Error:', error);
            });

    });

}

function estudiantes(id) {
    // Inline render inside project detail view; keep left image
    const panel = document.querySelector('.project-detail-card .project-info-container');
    const imgContainer = document.querySelector('.project-detail-card .project-image-container');
    if (!panel || !imgContainer) {
        // Fallback to previous navigation if structure isn't present
        const contentDiv = document.getElementById('content');
        fetch(`${baseUrl}/estudiantes/${id}`).then(r => r.text()).then(html => { contentDiv.innerHTML = html; });
        return;
    }

    fetch(`${baseUrl}/api/estudiantes/${id}`)
        .then(res => res.json())
        .then(json => {
            const items = (json && json.data) ? json.data : [];
            const header = `
                  <h2 class=\"project-detail-title\">Estudiantes</h2>
                  <div class=\"info-group\"><p class=\"text-left\">Estudiantes aceptados en este proyecto</p></div>
              `;
            if (!items.length) {
                panel.innerHTML = `${header}<div class=\"no-projects\"><h3>No hay estudiantes aún</h3><p>Cuando existan, aparecerán aquí.</p></div>`;
                return;
            }
            const cards = items.map(a => {
                const img = `${baseUrl}alumnos/${a.ID}-${a.correo}.jpg`;
                return `
                  <div class=\"applicant-card\">
                      <div class=\"applicant-image\"><img src=\"${img}\" onerror=\"this.style.display='none'\" alt=\"${a.nombre}\"></div>
                      <div class=\"applicant-info\">
                          <h4 class=\"applicant-name\">${a.nombre}</h4>
                          <p class=\"applicant-field\"><strong>Carrera:</strong> ${a.carrera}</p>
                          <p class=\"applicant-field\"><strong>Correo:</strong> ${a.correo}</p>
                          <div class=\"applicant-actions\">
                              <button class=\"btn btn-secondary\" onclick=\"rechazar(${a.ID})\">Eliminar</button>
                          </div>
                      </div>
                  </div>`;
            }).join('');
            panel.innerHTML = `${header}<div class=\"applicant-list\">${cards}</div>`;
        })
        .catch(() => {
            panel.innerHTML = '<div class=\"error-message\"><h2>Error</h2><p>No se pudieron cargar los estudiantes.</p></div>';
        });
}

function postulados(id) {
    // Try inline render inside current detail view; keep image
    const panel = document.querySelector('.project-detail-card .project-info-container');
    const imgContainer = document.querySelector('.project-detail-card .project-image-container');
    if (!panel || !imgContainer) {
        // Fallback: navigate as before
        const contentDiv = document.getElementById('content');
        fetch(`${baseUrl}/postulados/${id}`)
            .then(r => r.text())
            .then(html => { contentDiv.innerHTML = html; })
            .catch(() => { contentDiv.innerHTML = '<p>Error al cargar la lista.</p>'; });
        return;
    }

    fetch(`${baseUrl}/api/postulados/${id}`)
        .then(res => res.json())
        .then(json => {
            const items = (json && json.data) ? json.data : [];
            const header = `
                  <h2 class="project-detail-title">Postulados</h2>
                  <div class="info-group"><p class="text-left">Aplicantes para este proyecto</p></div>
              `;
            if (!items.length) {
                panel.innerHTML = `${header}<div class="no-projects"><h3>No hay postulados aún</h3><p>Cuando existan, aparecerán aquí.</p></div>`;
                return;
            }
            const cards = items.map(a => {
                const img = `${baseUrl}alumnos/${a.ID}-${a.correo}.jpg`;
                return `
                  <div class="applicant-card">
                      <div class="applicant-image"><img src="${img}" onerror="this.style.display='none'" alt="${a.nombre}"></div>
                      <div class="applicant-info">
                          <h4 class="applicant-name">${a.nombre}</h4>
                          <p class="applicant-field"><strong>Carrera:</strong> ${a.carrera}</p>
                          <p class="applicant-field"><strong>Correo:</strong> ${a.correo}</p>
                          <div class="applicant-actions">
                              <button class="btn btn-secondary" onclick="rechazar(${a.ID})">Rechazar</button>
                              <button class="btn btn-primary" onclick="aprobar(${a.ID})">Aprobar</button>
                          </div>
                      </div>
                  </div>`;
            }).join('');
            panel.innerHTML = `${header}<div class="applicant-list">${cards}</div>`;
        })
        .catch(() => {
            panel.innerHTML = '<div class="error-message"><h2>Error</h2><p>No se pudieron cargar los postulados.</p></div>';
        });
}

function datos_estudiante(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/datos_estudiante/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar el estudiante');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar el estudiante.</p>';
            console.error('Error:', error);
        });
}

function datos_postulados(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/datos_postulados/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar el estudiante');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar el estudiante.</p>';
            console.error('Error:', error);
        });
}

function aprobar(id) {
    const contentDiv = document.getElementById('content');
    showConfirm('¿Estás seguro de que quieres aprobar el estudiante?', function () {

        fetch(`${baseUrl}/aprobar/${id}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al aprobar el estudiante');
                }
                return response.text();
            })
            .then(data => {
                contentDiv.innerHTML = data;
                showSuccess('Estudiante aprobado correctamente');
            })
            .catch(error => {
                contentDiv.innerHTML = '<p>Error al aprobar el estudiante</p>';
                console.error('Error:', error);
            });

    });
}

// Inject modal and styles if not present
function injectStudentRejectionModal() {
    if (!document.getElementById('studentRejectionModal')) {
        const modalHtml = `
<div class="modal fade bootstrap-modal" id="studentRejectionModal" tabindex="-1" role="dialog" aria-labelledby="studentRejectionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content modern-modal">
            <form id="formRechazoEstudiante">
                <input type="hidden" name="id" id="rechazoAlumnoId">
                <div class="modal-header modern-modal-header">
                    <div class="modal-icon-wrapper">
                        <span class="modal-icon warning">⚠️</span>
                    </div>
                    <h5 class="modal-title modern-modal-title" id="studentRejectionModalLabel">Motivo de Eliminación</h5>
                    <button type="button" class="close modern-close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body modern-modal-body">
                    <p class="modal-description">Ingrese el motivo para retirar al estudiante. Se le notificará por correo.</p>
                    <div class="input-group-modern">
                        <label for="commentRechazo" class="modern-label">Motivo de la baja</label>
                        <textarea class="form-control modern-textarea" id="commentRechazo" name="comment" rows="5" placeholder="Describe el motivo..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer modern-modal-footer">
                    <button type="button" class="btn btn-secondary modern-btn-cancel" data-dismiss="modal">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary modern-btn-submit">
                        Enviar correo
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<style id="studentRejectionStyles">
.modern-modal { border: none; border-radius: 12px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15); overflow: hidden; }
.modern-modal-header { background: linear-gradient(135deg, #2675db 0%, #1e5bb8 100%); color: white; border: none; padding: 2rem 1.5rem 1.5rem; position: relative; text-align: center; }
.modal-icon { font-size: 3rem; display: inline-block; }
.modern-modal-title { font-size: 1.5rem; font-weight: 600; margin: 0; color: white; }
.modern-close { position: absolute; top: 1rem; right: 1rem; color: white; opacity: 0.8; font-size: 1.5rem; font-weight: 300; transition: opacity 0.2s; }
.modern-close:hover { opacity: 1; }
.modern-modal-body { padding: 2rem 1.5rem; background: #f8f9fa; }
.input-group-modern { text-align: left; width: 100%; display: block; }
.modal-description { color: #666666; font-size: 0.95rem; margin-bottom: 1.5rem; line-height: 1.6; text-align: center; }
.modern-label { font-weight: 600; color: #333333; margin-bottom: 0.5rem; display: block; width: 100%; }
.modern-textarea { border: 2px solid #e0e0e0; border-radius: 8px; padding: 0.75rem; font-size: 0.95rem; transition: all 0.3s ease; resize: vertical; width: 100% !important; display: block; }
.modern-textarea:focus { border-color: #2675db; box-shadow: 0 0 0 3px rgba(38, 117, 219, 0.1); outline: none; }
.modern-modal-footer { background: white; border-top: 1px solid #e9ecef; padding: 1rem 1.5rem; display: flex; gap: 0.75rem; justify-content: flex-end; }
.modern-modal-footer .modern-btn-cancel, .modern-modal-footer .modern-btn-submit { padding: 0.75rem 2rem !important; font-weight: 500 !important; border-radius: 25px !important; border: none !important; cursor: pointer; transition: all 0.3s ease; font-size: 1rem !important; min-width: 120px !important; }
.modern-modal-footer .modern-btn-cancel { background-color: #2675db !important; color: white !important; }
.modern-modal-footer .modern-btn-cancel:hover { background-color: #1e5bb8 !important; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(38, 117, 219, 0.3); }
.modern-modal-footer .modern-btn-submit { background-color: #2675db !important; color: white !important; }
.modern-modal-footer .modern-btn-submit:hover { background-color: #1e5bb8 !important; transform: translateY(-2px); box-shadow: 0 4px 16px rgba(38, 117, 219, 0.4); }
</style>`;
        document.body.insertAdjacentHTML('beforeend', modalHtml);

        // Add submit handler
        document.getElementById('formRechazoEstudiante').addEventListener('submit', function (e) {
            e.preventDefault();
            const id = document.getElementById('rechazoAlumnoId').value;
            const formData = new FormData(this);
            // Append ID manually if not picked up (input disabled/hidden issues sometimes)
            formData.set('id', id);

            $('#studentRejectionModal').modal('hide');

            const contentDiv = document.getElementById('content');

            // Use sendCommentA to send email and delete
            fetch(`${baseUrl}home/sendCommentA`, {
                method: 'POST',
                body: formData
            })
                .then(response => {
                    if (!response.ok) throw new Error('Error en la petición');
                    return response.text();
                })
                .then(data => {
                    // If sendCommentA redirects, we get the HTML page. 
                    // We update the content.
                    contentDiv.innerHTML = data;
                    showSuccess('Acción completada: Alumno notificado y rechazado');
                })
                .catch(error => {
                    console.error('Error:', error);
                    showError('Error al procesar la solicitud');
                });
        });
    }
}

function rechazar(id) {
    injectStudentRejectionModal();
    document.getElementById('rechazoAlumnoId').value = id;
    document.getElementById('commentRechazo').value = ''; // Reset comment
    $('#studentRejectionModal').modal('show');
}

// ----------------------------- Empresas ------------------------------- //

function loadEmpresa(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/vistaE/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar la empresa');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar la empresa.</p>';
            console.error('Error:', error);
        });
}

function unirse(id) {
    showConfirm('¿Estás seguro de que quieres aprobar esta empresa?', function () {
        fetch(`${baseUrl}/unirse/${id}`, {
            method: 'POST'
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al aprobar la empresa');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    showSuccess('Empresa aprobada exitosamente', function () {
                        loadContent('empresas');
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showError('Error al aprobar la empresa');
            });
    });
}

// --------------------------------------------------------------------- //