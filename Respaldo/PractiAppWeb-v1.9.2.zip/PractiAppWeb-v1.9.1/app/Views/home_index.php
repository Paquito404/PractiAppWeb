<!DOCTYPE html>
<html>
<head>
    <title>Enviar Comentario</title>
    <!-- Asegúrate de incluir Bootstrap + jQuery (o el framework que uses para el modal) -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h1>Enviar correo con comentario</h1>



    <!-- Botón para abrir el modal -->
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#commentModal">
      Añadir comentario
    </button>
</div>

<!-- Modal -->
<div class="modal fade" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="commentModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form action="<?= site_url('home/sendComment') ?>" method="post">
        <div class="modal-header">
          <h5 class="modal-title" id="commentModalLabel">Tu comentario</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label for="comment">Comentario:</label>
            <textarea class="form-control" id="comment" name="comment" rows="4" required></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-primary">Enviar correo</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Scripts Bootstrap + jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
