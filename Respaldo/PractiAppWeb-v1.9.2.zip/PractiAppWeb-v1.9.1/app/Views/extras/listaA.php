<?php
$fecha_actual = date('Y-m-d');
$fechaRegistroInicio = date($practica['FechaRegistroInicio']);
$fechaRegistroFinal = date($practica['FechaRegistroFinal']);

$imagenPath = base_url('imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg');
$imagenArchivo = FCPATH . 'imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg';
?>

<div class="project-detail-container">
    <div class="project-detail-card">
        <div class="project-detail-grid">
            <div class="project-image-container">
                <?php if (file_exists($imagenArchivo)): ?>
                    <img src="<?= $imagenPath . '?v=' . time() ?>" alt="Imagen de la práctica" class="project-detail-image">
                <?php else: ?>
                    <div class="project-detail-image placeholder">
                        <span>Sin imagen disponible</span>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="project-info-container">
                <?php if (isset($practica)): ?>
                    <h2 class="project-detail-title"><?= htmlspecialchars($practica['Titulo']) ?></h2>
                    
                    <div class="project-detail-info">
                        <div class="info-group">
                            <label>Descripción</label>
                            <p>Proyecto de <?= htmlspecialchars($practica['Carrera']) ?>.</p>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>ID del Proyecto</label>
                                <p><?= htmlspecialchars($practica['ID']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Carrera</label>
                                <p><?= htmlspecialchars($practica['Carrera']) ?></p>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Requisitos</label>
                                <p><?= htmlspecialchars($practica['Requisitos']) ?> semestre(s) o más</p>
                            </div>
                            <div class="info-group">
                                <label>Número de vacantes</label>
                                <p><?= htmlspecialchars($practica['Integrantes']) ?></p>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Apoyo económico</label>
                                <p>$<?= htmlspecialchars($practica['Pago']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Estado</label>
                                <p><?= htmlspecialchars($practica['Estatus']) ?></p>
                            </div>
                        </div>

                        <div class="info-group">
                            <label>Horario</label>
                            <p><?= substr(htmlspecialchars($practica['HorarioInicio']), 0, 5) ?> a <?= substr(htmlspecialchars($practica['HorarioFinal']), 0, 5) ?></p>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Registro</label>
                                <p><?= htmlspecialchars($practica['FechaRegistroInicio']) ?> a <?= htmlspecialchars($practica['FechaRegistroFinal']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Período de Actividad</label>
                                <p><?= htmlspecialchars($practica['FechaActividadInicio']) ?> a <?= htmlspecialchars($practica['FechaActividadFinal']) ?></p>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <p>No se encontraron datos para esta práctica.</p>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="button-container">
            <?php if ($fecha_actual <= $fechaRegistroFinal && $fecha_actual >= $fechaRegistroInicio && $practica['Integrantes'] > 0): ?>
                <button class="btn btn-primary" onclick="aplicar(<?= $practica['ID'] ?>)">Unirse al Proyecto</button>
            <?php elseif ($practica['Integrantes'] <= 0): ?>
                <button class="btn btn-secondary" disabled style="opacity: 0.6;">Sin Vacantes Disponibles</button>
            <?php else: ?>
                <button class="btn btn-secondary" disabled style="opacity: 0.6;">Fuera del Período de Registro</button>
            <?php endif; ?>
            <button class="btn btn-secondary" onclick="loadContent('inicio')">Regresar</button>
        </div>
    </div>
</div>
