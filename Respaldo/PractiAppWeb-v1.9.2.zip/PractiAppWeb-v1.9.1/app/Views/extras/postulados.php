<h1>Lista de postulados</h1>
<p>Aqui esta la lista de estudiantes que quieren participar en la practica</p>


<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="contenedor-botones">
                <?php foreach ($alumno as $al): 

                ?>
                      
                    <?php 

                        $ID = $practica['ID'];

                        $id_alumno = $al['ID'];
                        $fase = $al['Fase'];
                        $correo = $al['correo'];
                        $ID_practica = $al['ID_Practica'];

                        $imgPath = base_url('alumnos/' . $id_alumno . '-' . $correo .'.jpg');
                        $imgFile = FCPATH . 'alumnos/' . $id_alumno . '-' . $correo . '.jpg';
                        $hasImage = file_exists($imgFile);
                     
                    ?>
                    <?php if ($fase == 2 && $ID_practica == $ID): ?>
                    <button class="boton-izquierda" onclick="datos_postulados('<?= $id_alumno ?>')">
                        <div style="display: flex; align-items: center;">
                        
                            <?php if ($hasImage): ?>
                                <img src="<?= $imgPath . '?v=' . time() ?>" alt="Imagen <?= $id_alumno ?>" width="60" height="60" style="margin-right: 15px; object-fit: cover; border-radius: 5px;">
                            <?php else: ?>
                                <div style="width: 60px; height: 60px; background: #ccc; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 12px; margin-right: 15px; border-radius: 5px;">
                                    Sin<br>Imagen
                                </div>
                            <?php endif; ?>

                            <div>
                                <?= 
                                    htmlspecialchars($al['ID']) . "<br>" .
                                    htmlspecialchars($al['nombre']) . "<br>" .
                                    htmlspecialchars($al['carrera']) . "<br>" .
                                    htmlspecialchars($al['correo']) . "<br>" 
                                    ?>
                                    
                            </div>
                        </div>
                    </button>
                        <?php endif; ?> 

                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div> 