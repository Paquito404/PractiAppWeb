<?php
    $correo = session()->get('correo');
    $imagenPath = base_url('imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg');
    $imagenArchivo = FCPATH . 'imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg';
?>

<div class="project-detail-container">
    <div class="project-detail-card">
        <div class="project-detail-grid">
            <div class="project-image-container">
                <?php if (file_exists($imagenArchivo)): ?>
                    <img src="<?= $imagenPath . '?v=' . time() ?>" alt="Imagen de la práctica" class="project-detail-image">
                <?php else: ?>
                    <div class="project-detail-image placeholder">
                        <span>Sin imagen disponible</span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="project-info-container">
                <?php if (isset($practica)): ?>
                    <h2 class="project-detail-title"><?= htmlspecialchars($practica['Titulo']) ?></h2>
                    
                    <div class="project-detail-info">
                        <div class="info-group">
                            <label>Descripción</label>
                            <p>Proyecto de <?= htmlspecialchars($practica['Carrera']) ?>.</p>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>ID del Proyecto</label>
                                <p><?= htmlspecialchars($practica['ID']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Carrera</label>
                                <p><?= htmlspecialchars($practica['Carrera']) ?></p>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Requisitos</label>
                                <p><?= htmlspecialchars($practica['Requisitos']) ?> semestre(s) o más</p>
                            </div>
                            <div class="info-group">
                                <label>Número de vacantes</label>
                                <p><?= htmlspecialchars($practica['Integrantes']) ?></p>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Apoyo económico</label>
                                <p>$<?= htmlspecialchars($practica['Pago']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Estado</label>
                                <p><?= htmlspecialchars($practica['Estatus']) ?></p>
                            </div>
                        </div>

                        <div class="info-group">
                            <label>Horario</label>
                            <p><?= substr(htmlspecialchars($practica['HorarioInicio']), 0, 5) ?> a <?= substr(htmlspecialchars($practica['HorarioFinal']), 0, 5) ?></p>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Registro</label>
                                <p><?= htmlspecialchars($practica['FechaRegistroInicio']) ?> a <?= htmlspecialchars($practica['FechaRegistroFinal']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Período de actividad</label>
                                <p><?= htmlspecialchars($practica['FechaActividadInicio']) ?> a <?= htmlspecialchars($practica['FechaActividadFinal']) ?></p>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <p>No se encontraron datos para esta práctica.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="button-container">
            <?php if ($correo == $practica['Autor']): ?>
                <?php if ($practica['Estatus'] == 'Activo'): ?>
                    <button class="btn btn-secondary" onclick="estudiantes(<?= $practica['ID'] ?>)">Estudiantes</button>
                    <?php if ($practica['Integrantes'] > 0): ?>
                        <button class="btn btn-secondary" onclick="postulados(<?= $practica['ID'] ?>)">Postulados</button>
                    <?php endif; ?>
                <?php endif; ?>
                <button class="btn btn-secondary" onclick="editarPractica(<?= $practica['ID'] ?>)">Editar</button>
                <button class="btn btn-secondary" onclick="papelera(<?= $practica['ID'] ?>)">Eliminar</button>
            <?php else: ?>
                <button class="btn btn-primary" type="button" onclick="confirmarEliminacionPractica()">Eliminar definitivamente</button>
            <?php endif; ?>
            <button class="btn btn-primary" onclick="loadContent('inicio')">Regresar</button>
        </div>
    </div>
</div>

<!-- Modal para eliminar con comentario (cuando no eres el autor) -->
<div class="modal fade bootstrap-modal" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="commentModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form id="Formulario correo" action="<?= site_url('home/sendCommentP') ?>" method="post">
                <input type="hidden" name="id" value="<?= $practica['ID'] ?>">
                <div class="modal-header">
                    <h5 class="modal-title" id="commentModalLabel">Motivo de Eliminación</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <label for="comment">Ingrese el motivo por el cual se eliminará:</label>
                    <textarea class="form-control" id="comment" name="comment" rows="4" required></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Enviar correo</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function confirmarEliminacionPractica() {
    Swal.fire({
        title: '¿Está seguro?',
        text: "¿Desea eliminar definitivamente esta práctica?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            // Si confirma, abrir el modal para ingresar el motivo
            $('#commentModal').modal('show');
        }
    });
}
</script>
