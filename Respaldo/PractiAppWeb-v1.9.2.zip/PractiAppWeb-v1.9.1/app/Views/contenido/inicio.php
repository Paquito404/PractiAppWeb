
<?php 
    use App\Models\AlumnoModel;
    $tipo = session()->get('tipo');
    $correo = session()->get('correo'); 
    $fecha = CodeIgniter\I18n\Time::now()->toDateTimeString();
?>

<?php if($tipo == 'alumno'): ?>

<?php
    $id_alumno  = session()->get('usuario_id'); 
    $semestre = session()->get('semestre'); 
    $alumnoModel = new AlumnoModel();
    $alumno = $alumnoModel->find($id_alumno);
    $Fase = $alumno['Fase'];

switch($Fase){
    case 2:
        echo '<div class="modern-projects-layout">
                <div class="projects-header">
                    <h1>Estado de Aplicación</h1>
                </div>
                <div class="no-projects-modern">
                    <div class="icon">⏳</div>
                    <h3>Aplicación en Proceso</h3>
                    <p>Actualmente estás aplicando para una práctica profesional. Por favor espera la respuesta del coordinador.</p>
                </div>
              </div>';
        return;
    case 3:
        echo '<div class="modern-projects-layout">
                <div class="projects-header">
                    <h1>Práctica Asignada</h1>
                    <p class="subtitle">Ya formas parte de una práctica profesional</p>
                </div>
                <div class="no-projects-modern">
                    <div class="icon">✅</div>
                    <h3>Práctica Activa</h3>
                    <p>Ya eres parte de una práctica profesional. Consulta la sección "Tus proyectos" para más detalles.</p>
                </div>
              </div>';
        return;
}

?>

<div class="modern-projects-layout">
    <div class="projects-header">
        <h1>Proyectos Disponibles</h1>
        <p class="subtitle">Encuentra y aplica a prácticas profesionales disponibles para tu carrera</p>
    </div>
    
    <?php 
    $availableProjects = [];
    foreach ($practica as $prac) {
        $id = $prac['ID'];
        $nombre = $prac['Carrera'];
        $fase = $prac['Fase'];
        $imgPath = base_url('imagenes/' . $id . '-' . $nombre .'.jpg');
        $imgFile = FCPATH . 'imagenes/' . $id . '-' . $nombre . '.jpg';
        $hasImage = file_exists($imgFile);
        
        // Validación incluyendo fechas de registro
        if ($fecha >= $prac['FechaRegistroInicio'] && $fecha <= $prac['FechaRegistroFinal'] && 
            $alumno['carrera'] == $prac['Carrera'] && $fase == 2 && $prac['Estatus'] != 'Inactivo' && 
            $semestre >= $prac['Requisitos'] && $prac['Integrantes'] > 0) {
            $availableProjects[] = [
                'data' => $prac,
                'hasImage' => $hasImage,
                'imgPath' => $imgPath
            ];
        }
    }
    ?>
    
    <?php if (empty($availableProjects)): ?>
        <div class="no-projects-modern">
            <div class="icon">📚</div>
            <h3>No hay proyectos disponibles</h3>
            <p>Por el momento no hay prácticas profesionales disponibles para tu carrera y semestre actual.</p>
        </div>
    <?php else: ?>
        <div class="modern-projects-grid">
            <?php foreach ($availableProjects as $project): ?>
                <?php $prac = $project['data']; ?>
                <div class="modern-project-card" onclick="loadPracticaA('<?= $prac['ID'] ?>')">
                    <div class="project-card-header">
                        <?php if ($project['hasImage']): ?>
                            <img src="<?= $project['imgPath'] . '?v=' . time() ?>" alt="<?= htmlspecialchars($prac['Titulo']) ?>" class="project-card-image">
                        <?php else: ?>
                            <div class="project-card-image-placeholder">
                                Sin imagen<br>disponible
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="project-card-content">
                        <h3 class="project-card-title"><?= htmlspecialchars($prac['Titulo']) ?></h3>
                        <div class="project-card-meta">
                            <div class="project-meta-item">
                                <span class="label">Carrera:</span>
                                <span class="value"><?= htmlspecialchars($prac['Carrera']) ?></span>
                            </div>
                            <div class="project-meta-item">
                                <span class="label">Estatus:</span>
                                <span class="value"><?= htmlspecialchars($prac['Estatus']) ?></span>
                            </div>
                            <div class="project-meta-item">
                                <span class="label">Integrantes:</span>
                                <span class="value"><?= htmlspecialchars($prac['Integrantes']) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div> 
<?php 
return;
else:?>

<div class="modern-projects-layout">
    <div class="projects-header">
        <h1>Tus Proyectos</h1>
        <p class="subtitle">Administra tus prácticas profesionales creadas</p>
    </div>
    
    <?php
        $correo = session()->get('correo'); 
        $userProjects = [];
        
        foreach ($practica as $prac) {
            $id = $prac['ID'];
            $nombre = $prac['Carrera'];
            $fase = $prac['Fase'];
            $imgPath = base_url('imagenes/' . $id . '-' . $nombre .'.jpg');
            $imgFile = FCPATH . 'imagenes/' . $id . '-' . $nombre . '.jpg';
            $hasImage = file_exists($imgFile);
            
            if ($fase == 2 && $correo == $prac['Autor']) {
                $userProjects[] = [
                    'data' => $prac,
                    'hasImage' => $hasImage,
                    'imgPath' => $imgPath
                ];
            }
        }
    ?>
    
    <?php if (empty($userProjects)): ?>
        <div class="no-projects-modern">
            <div class="icon">📋</div>
            <h3>No tienes proyectos creados</h3>
            <p>Aún no has creado ninguna práctica profesional. Comienza creando tu primer proyecto.</p>
            <button class="btn btn-primary" onclick="loadContent('formulario')">
                Crear Proyecto
            </button>
        </div>
    <?php else: ?>
        <div class="modern-projects-grid">
            <?php foreach ($userProjects as $project): ?>
                <?php $prac = $project['data']; ?>
                <div class="modern-project-card" onclick="loadPractica('<?= $prac['ID'] ?>')">
                    <div class="project-card-header">
                        <?php if ($project['hasImage']): ?>
                            <img src="<?= $project['imgPath'] . '?v=' . time() ?>" alt="<?= htmlspecialchars($prac['Titulo']) ?>" class="project-card-image">
                        <?php else: ?>
                            <div class="project-card-image-placeholder">
                                Sin imagen<br>disponible
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="project-card-content">
                        <h3 class="project-card-title"><?= htmlspecialchars($prac['Titulo']) ?></h3>
                        <div class="project-card-meta">
                            <div class="project-meta-item">
                                <span class="label">Carrera:</span>
                                <span class="value"><?= htmlspecialchars($prac['Carrera']) ?></span>
                            </div>
                            <div class="project-meta-item">
                                <span class="label">Estatus:</span>
                                <span class="value"><?= htmlspecialchars($prac['Estatus']) ?></span>
                            </div>
                            <div class="project-meta-item">
                                <span class="label">Integrantes:</span>
                                <span class="value"><?= htmlspecialchars($prac['Integrantes']) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php endif;?>