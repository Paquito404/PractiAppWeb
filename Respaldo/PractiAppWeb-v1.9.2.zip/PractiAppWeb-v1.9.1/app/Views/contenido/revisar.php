<?php
    $depart = session()->get('departamento');
    $tipo = session()->get('tipo');
?>

<div class="content-wrapper">
    <section class="projects-container">
        <?php 
        $hasProjects = false;
        foreach ($practica as $prac):
            $id = $prac['ID'];
            $nombre = $prac['Carrera'];
            $fase = $prac['Fase'];
            $imgPath = base_url('imagenes/' . $id . '-' . $nombre .'.jpg');
            $imgFile = FCPATH . 'imagenes/' . $id . '-' . $nombre . '.jpg';
            $hasImage = file_exists($imgFile);
            
            // Filtrar por fase 1 y departamento
            if ($fase != 1) continue;
            if ($tipo != 'moderador' && $prac['Departamento'] != $depart) continue;
            
            $hasProjects = true;
        ?>
            <div class="enrolled-project-card" 
                 onclick="selectReviewProject(this)"
                 data-id="<?= $id ?>"
                 data-titulo="<?= htmlspecialchars($prac['Titulo']) ?>"
                 data-carrera="<?= htmlspecialchars($prac['Carrera']) ?>"
                 data-estado="<?= htmlspecialchars($prac['Estatus']) ?>"
                 data-integrantes="<?= htmlspecialchars($prac['Integrantes']) ?>"
                 data-img="<?= $hasImage ? ($imgPath . '?v=' . time()) : '' ?>">
                <div class="enrolled-project-info">
                    <h3 class="enrolled-project-title"><?= htmlspecialchars($prac['Titulo']) ?></h3>
                    <div class="enrolled-project-details">
                        <p class="enrolled-project-field"><strong>Carrera:</strong> <?= htmlspecialchars($prac['Carrera']) ?></p>
                        <p class="enrolled-project-field"><strong>Estado:</strong> <?= htmlspecialchars($prac['Estatus']) ?></p>
                        <p class="enrolled-project-field"><strong>Integrantes:</strong> <?= htmlspecialchars($prac['Integrantes']) ?></p>
                    </div>
                </div>
                <div class="enrolled-project-image <?= $hasImage ? '' : 'placeholder' ?>">
                    <?php if ($hasImage): ?>
                        <img src="<?= $imgPath . '?v=' . time() ?>" alt="Imagen <?= $id ?>">
                    <?php else: ?>
                        <span>Sin imagen disponible</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if (!$hasProjects): ?>
            <div class="no-projects">
                <h3>No hay prácticas en revisión</h3>
                <p>Actualmente no hay prácticas pendientes de revisión.</p>
            </div>
        <?php endif; ?>
    </section>

    <aside class="selected-project" id="revDetailPanel">
        <div class="placeholder-text">
            <p>Selecciona un proyecto para revisar</p>
        </div>
    </aside>
</div>

<script>
window.selectReviewProject = function(card) {
    const id = card.dataset.id;
    const titulo = card.dataset.titulo || 'Proyecto';
    const carrera = card.dataset.carrera || '—';
    const estado = card.dataset.estado || '—';
    const integrantes = card.dataset.integrantes || '—';
    const imgUrl = card.dataset.img || '';

    const panel = document.getElementById('revDetailPanel');
    if (!panel) return;

    const imageBlock = imgUrl
        ? `<div class="selected-project-image" id="revImageWrapper"><img src="${imgUrl}" alt="Imagen del proyecto" style="width:100%;height:100%;object-fit:cover;"></div>`
        : `<div class="selected-project-image placeholder" id="revImageWrapper"><span>Sin imagen disponible</span></div>`;

    panel.innerHTML = `
        ${imageBlock}
        <div id="revDetailSection">
            <div class="selected-project-info">
                <h3 id="revTitulo">${titulo}</h3>
                <div class="detail-row"><strong>ID del Proyecto:</strong><p id="revId">${id}</p></div>
                <div class="detail-row"><strong>Carrera:</strong><p id="revCarrera">${carrera}</p></div>
                <div class="detail-row"><strong>Estado:</strong><p id="revEstado">${estado}</p></div>
                <div class="detail-row"><strong>Integrantes:</strong><p id="revIntegrantes">${integrantes}</p></div>
                <div class="detail-row"><strong>Fase:</strong><p>En revisión (Fase 1)</p></div>
            </div>
            <div class="button-container">
                <button class="btn btn-secondary" id="revRejectBtn" onclick="papelera(${id})" data-id="${id}">Desaprobar Proyecto</button>
                <button class="btn btn-primary" id="revApproveBtn" onclick="fase(${id})" data-id="${id}">Aprobar Proyecto</button>
            </div>
        </div>`;

    // Highlight selected card
    document.querySelectorAll('.enrolled-project-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
};
</script>
