<?php 
use CodeIgniter\I18n\Time;
?>

<div class="content-wrapper">
    <section class="projects-container">
        <?php 
        $now = Time::now()->toDateTimeString();
        $hasAny = false;
        foreach ($practica as $prac):
            $id = $prac['ID'];
            $nombre = $prac['Carrera'];
            $fase = $prac['Fase'];
            $imgPath = base_url('imagenes/' . $id . '-' . $nombre .'.jpg');
            $imgFile = FCPATH . 'imagenes/' . $id . '-' . $nombre . '.jpg';
            $hasImage = file_exists($imgFile);

            // Auto-delete if expiration passed
            if ($prac['Fecha'] != NULL && $now >= $prac['Fecha']) {
                if ($hasImage) { @unlink($imgFile); }
                $escuelaModel = new App\Models\EscuelaModel();
                $escuelaModel->delete($id);
                continue;
            }

            if ($fase != 0) { continue; }
            $hasAny = true;
        ?>
            <div class="enrolled-project-card" 
                 onclick="selectTrashProject(this)"
                 data-id="<?= $id ?>"
                 data-titulo="<?= htmlspecialchars($prac['Titulo']) ?>"
                 data-carrera="<?= htmlspecialchars($prac['Carrera']) ?>"
                 data-estado="<?= htmlspecialchars($prac['Estatus']) ?>"
                 data-integrantes="<?= htmlspecialchars($prac['Integrantes']) ?>"
                 data-img="<?= $hasImage ? ($imgPath . '?v=' . time()) : '' ?>">
                <div class="enrolled-project-info">
                    <h3 class="enrolled-project-title"><?= htmlspecialchars($prac['Titulo']) ?></h3>
                    <div class="enrolled-project-details">
                        <p class="enrolled-project-field"><strong>Carrera:</strong> <?= htmlspecialchars($prac['Carrera']) ?></p>
                        <p class="enrolled-project-field"><strong>Estado:</strong> <?= htmlspecialchars($prac['Estatus']) ?></p>
                        <p class="enrolled-project-field"><strong>Integrantes:</strong> <?= htmlspecialchars($prac['Integrantes']) ?></p>
                    </div>
                </div>
                <div class="enrolled-project-image <?= $hasImage ? '' : 'placeholder' ?>">
                    <?php if ($hasImage): ?>
                        <img src="<?= $imgPath . '?v=' . time() ?>" alt="Imagen <?= $id ?>">
                    <?php else: ?>
                        <span>Sin imagen disponible</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if (!$hasAny): ?>
            <div class="no-projects">
                <h3>No hay proyectos en la papelera</h3>
                <p>Cuando elimines un proyecto aparecerá aquí por un tiempo limitado.</p>
            </div>
        <?php endif; ?>
    </section>

    <aside class="selected-project" id="trashDetailPanel">
        <div class="placeholder-text">
            <p>Selecciona un proyecto para ver los detalles</p>
        </div>
        
        <div id="trashDetailSection" style="display:none;">
            <div class="selected-project-image" id="trashImageWrapper">
                <img id="trashImage" src="" alt="Imagen del proyecto">
            </div>

            <div class="selected-project-info">
                <h3 id="trashTitulo">Proyecto</h3>
                <div class="detail-row">
                    <strong>ID del Proyecto:</strong>
                    <p id="trashId">—</p>
                </div>
                <div class="detail-row">
                    <strong>Carrera:</strong>
                    <p id="trashCarrera">—</p>
                </div>
                <div class="detail-row">
                    <strong>Estado:</strong>
                    <p id="trashEstado">—</p>
                </div>
                <div class="detail-row">
                    <strong>Integrantes:</strong>
                    <p id="trashIntegrantes">—</p>
                </div>
                <div class="detail-row">
                    <strong>Fase:</strong>
                    <p>En papelera (Fase 0)</p>
                </div>
            </div>
            <div style="margin-top: 1.5rem; display: flex; gap: 1rem; justify-content: flex-end;">
                <button class="btn btn-secondary" id="trashRestoreBtn" onclick="borrar(document.getElementById('trashId').textContent)" disabled>Restaurar</button>
                <button class="btn btn-primary" id="trashDeleteBtn" onclick="deleteProject(document.getElementById('trashId').textContent)" disabled>Eliminar definitivamente</button>
            </div>
        </div>
    </aside>
</div>

<script>
function selectTrashProject(card) {
    const id = card.dataset.id;
    const titulo = card.dataset.titulo;
    const carrera = card.dataset.carrera;
    const estado = card.dataset.estado;
    const integrantes = card.dataset.integrantes;
    const imgSrc = card.dataset.img;

    // Update detail panel
    document.getElementById('trashId').textContent = id;
    document.getElementById('trashTitulo').textContent = titulo;
    document.getElementById('trashCarrera').textContent = carrera;
    document.getElementById('trashEstado').textContent = estado;
    document.getElementById('trashIntegrantes').textContent = integrantes;

    // Update image
    const imgEl = document.getElementById('trashImage');
    const imgWrapper = document.getElementById('trashImageWrapper');
    if (imgSrc) {
        imgEl.src = imgSrc;
        imgEl.style.display = 'block';
        imgWrapper.classList.remove('placeholder');
    } else {
        imgEl.style.display = 'none';
        imgWrapper.classList.add('placeholder');
        imgWrapper.innerHTML = '<span>Sin imagen disponible</span>';
    }

    // Show detail section and enable buttons
    document.querySelector('.placeholder-text').style.display = 'none';
    document.getElementById('trashDetailSection').style.display = 'block';
    document.getElementById('trashRestoreBtn').disabled = false;
    document.getElementById('trashDeleteBtn').disabled = false;

    // Highlight selected card
    document.querySelectorAll('.enrolled-project-card').forEach(c => c.classList.remove('selected'));
    card.classList.add('selected');
}

function deleteProject(id) {
    showConfirm('¿Estás seguro de que deseas eliminar este proyecto definitivamente?', function() {
        fetch(baseUrl + 'coordinador/eliminarPermanente/' + id, {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showSuccess('Proyecto eliminado', function() {
                    loadContent('papelera');
                });
            } else {
                showError('Error al eliminar el proyecto');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Error al eliminar el proyecto');
        });
    });
}
</script>
