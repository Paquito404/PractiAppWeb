<?php

namespace App\Models;
use CodeIgniter\Model;

class DepartamentoModel extends Model
{
    protected $table = 'Departamentos';
    protected $returnType = 'array';
    protected $allowedFields = ['nombre'];

    protected $useTimestamps = false; 
}