<?php if (session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
  <?= session()->getFlashdata('success') ?>
  <button type="button" class="close" data-dismiss="alert" aria-label="Cerrar">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>

<h1>Registro para Maestros</h1>
<p>Este apartado se enfoca en registrar maestros</p>
<br></br>

<form action="<?php echo base_url('registroM')?>" method="post" autocomplete="off" enctype="multipart/form-data">

    <h2>Nombre</h2>
    <input type="text" name="nombre" id="nombre" required>
    <br>

    <h2>Departamento</h2>
    <select name="departamento" id="departamento" required>
        <option value="">Seleccione una opción</option>
        <?php foreach ($departamento as $depa): ?>
                <option value=<?= $depa['nombre'] ?>><?= $depa['nombre'] ?></option>
            <?php endforeach; ?>
    </select>
    <br>

    <h2>Correo</h2>
    <input type="text" name="correo" id="correo" required>
    <br>

    <h2>Password</h2>
    <input type="text" name="password" id="password" required>
    <br>

    <h2>Imagen (JPG)</h2>

  
    <input type="file" id="imagen" name="imagen" accept="image/jpeg" onclick= "mostrarIMG()" required>
        <br>
        <img id="vistaPrevia" src="#" alt="Vista previa"
            style="display:none; max-width: 300px; max-height: 300px;">
        <br>

    <br>
    <input type="submit" name="Subir" id="Subir">
    <br>

</form>