
<?php 
    use App\Models\AlumnoModel;
    $tipo = session()->get('tipo');
    $correo = session()->get('correo'); 
?>

<?php if($tipo == 'alumno'): ?>

    <h1>Bienvenido <?= $correo ?></h1>
    <p>Aqui se muestran practicas disponibles para el usuario</p>
    <br>

<?php
    $id_alumno  = session()->get('usuario_id'); 
    $semestre = session()->get('semestre'); 
    $alumnoModel = new AlumnoModel();
    $alumno = $alumnoModel->find($id_alumno);
    $Fase = $alumno['Fase'];

switch($Fase){
    case 2:
        echo "ESTAS APLICANDO PARA UNA PRACTICA";
        return;
    case 3:
        echo "YA ERES PARTE DE UNA PRACTICA";
        return;
}

?>

<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="contenedor-botones">
               
                <?php foreach ($practica as $prac): ?>
                      
                    <?php 

                        $id = $prac['ID'];
                        $nombre = $prac['Carrera'];
                        $fase = $prac['Fase'];
                        $imgPath = base_url('imagenes/' . $id . '-' . $nombre .'.jpg');
                        $imgFile = FCPATH . 'imagenes/' . $id . '-' . $nombre . '.jpg';
                        $hasImage = file_exists($imgFile);
                     
                    ?>
                    <?php if ($alumno['carrera'] == $prac['Carrera'] && $fase == 2 && $prac['Estatus'] != 'Inactivo' && $semestre >= $prac['Requisitos']): ?>
                    <button class="boton-izquierda" onclick="loadPracticaA('<?= $id ?>')">
                        <div style="display: flex; align-items: center;">
                        
                            <?php if ($hasImage): ?>
                                <img src="<?= $imgPath . '?v=' . time() ?>" alt="Imagen <?= $id ?>" width="60" height="60" style="margin-right: 15px; object-fit: cover; border-radius: 5px;">
                            <?php else: ?>
                                <div style="width: 60px; height: 60px; background: #ccc; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 12px; margin-right: 15px; border-radius: 5px;">
                                    Sin<br>Imagen
                                </div>
                            <?php endif; ?>

                            <div>
                                <?= 
                                    "Practica: ". htmlspecialchars($prac['ID']) . "<br>" .
                                    htmlspecialchars($prac['Titulo']) . "<br>" .
                                    htmlspecialchars($prac['Carrera']) . "<br>" .
                                    htmlspecialchars($prac['Estatus']) . "<br>" .
                                    "Integrantes: " . htmlspecialchars($prac['Integrantes'])
                                    ?>
                                    
                            </div>
                        </div>
                    </button>
                        <?php endif; ?>        
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div> 
<?php 
return;
else:?>

    <h1>Bienvenido <?= $correo ?></h1>
    <p>Aqui se muestran tus practicas creadas</p>
    <br>

     <?php
        $correo = session()->get('correo'); 
        $contador = 0;
     ?>
                            
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="contenedor-botones">
               
                <?php foreach ($practica as $prac): ?>
                      
                    <?php 

                        $id = $prac['ID'];
                        $nombre = $prac['Carrera'];
                        $fase = $prac['Fase'];
                        $correo = session()->get('correo'); 
                        $imgPath = base_url('imagenes/' . $id . '-' . $nombre .'.jpg');
                        $imgFile = FCPATH . 'imagenes/' . $id . '-' . $nombre . '.jpg';
                        $hasImage = file_exists($imgFile);

                    ?>
                    <?php if ($fase == 2 && $correo == $prac['Autor']): ?>
                    <button class="boton-izquierda" onclick="loadPractica('<?= $id ?>')">
                        <div style="display: flex; align-items: center;">
                        
                            <?php if ($hasImage): ?>
                                <img src="<?= $imgPath . '?v=' . time() ?>" alt="Imagen <?= $id ?>" width="60" height="60" style="margin-right: 15px; object-fit: cover; border-radius: 5px;">
                            <?php else: ?>
                                <div style="width: 60px; height: 60px; background: #ccc; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 12px; margin-right: 15px; border-radius: 5px;">
                                    Sin<br>Imagen
                                </div>
                            <?php endif; ?>

                            <div>
                                <?= 
                                    "Practica: ". htmlspecialchars($prac['ID']) . "<br>" .
                                    htmlspecialchars($prac['Titulo']) . "<br>" .
                                    htmlspecialchars($prac['Carrera']) . "<br>" .
                                    htmlspecialchars($prac['Estatus']) . "<br>" .
                                    "Integrantes: " . htmlspecialchars($prac['Integrantes'])
                                    ?>
                                    
                               <?php  $contador=$contador+1 ?>
                            </div>
                        </div>
                    </button>
                        <?php endif; ?>        
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div> 
<?php if($contador==0): ?>

    <Center><h2>DE MOMENTO NO CUENTAS CON PROYECTOS DISPONIBLES</h2></Center>
    <br>
    <div class="botones-tabla">
        <button onclick="loadContent('formulario')">Subir proyectos</button>
    </div>

<?php endif;?>

<?php endif;?>