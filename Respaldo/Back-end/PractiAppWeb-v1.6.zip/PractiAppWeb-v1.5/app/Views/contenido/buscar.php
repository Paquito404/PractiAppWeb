<h1>Vista Combinada de prácticas</h1>
<p>Aquí se mostrarán todas las prácticas disponibles sin excepción</p>
<br>

<?php 

$departamento_usuario = session()->get('departamento');
$tipo = session()->get('tipo');

?>

<div class="acciones">
    <input type="text" id="buscador" placeholder="Buscar por nombre..." onkeyup="filtrarFilas()">
</div>

<div class="filtros">
    <ul>
        <li>
            <select id="filtro-estatus">
                <option value="">Estatus</option>
                <option value="Activo">Activo</option>
                <option value="Inactivo">Inactivo</option>
            </select>
        </li>
        <li>
            <select id="filtro-fecha">
                <option value="">Ordenar por fecha</option>
                <option value="desc">Más viejos</option>
                <option value="asc">Más nuevos</option>
            </select>
        </li>
        <li>
            <select id="filtro-carrera">
                <option value="">Carrera</option>
                <?php if ($tipo != 'moderador'): ?>
                    <?php foreach ($carrera as $car): ?>
                        <?php if ($car['Departamento'] == $departamento): ?>
                            <option value="<?= $car['nombre'] ?>"><?= $car['nombre'] ?></option>
                        <?php endif; ?>
                    <?php endforeach; ?>    
                <?php else: ?>
                    <?php foreach ($carrera as $car): ?>
                        <option value="<?= $car['nombre'] ?>"><?= $car['nombre'] ?></option>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>
        </li>
        <li>
            <select id="filtro-integrantes">
                <option value="">Integrantes</option>
                <option value="0">0 integrantes</option>
                <option value="1">1 o más</option>
            </select>
        </li>
    </ul>
</div>

<div class="botones-tabla">

<button onclick="aplicarFiltros()">Aplicar filtros</button>
<button onclick="restaurarFiltros()">Restaurar</button>

</div>

<br>
<div class="Reja-Botones" id="resultado-filtro">
    <?php if ($tipo != 'moderador'): ?>
        <?php foreach ($practica as $prac): ?>
            <?php if ($prac['Departamento'] == $departamento_usuario): ?>
                <button class="boton-buscador" onclick="loadPractica('<?= $prac['ID'] ?>')">
                    <?= 
                        "Práctica: " . htmlspecialchars($prac['ID']) . "<br>" .
                        htmlspecialchars($prac['Titulo']) . "<br>" .
                        htmlspecialchars($prac['Carrera']) . "<br>" .
                        htmlspecialchars($prac['Estatus']) . "<br>" .
                        "Integrantes: " . htmlspecialchars($prac['Integrantes'])
                    ?>
                </button>
            <?php endif; ?>
        <?php endforeach; ?>    
    <?php else: ?>
        <?php foreach ($practica as $prac): ?>
            <button class="boton-buscador" onclick="loadPractica('<?= $prac['ID'] ?>')">
                <?= 
                    "Práctica: " . htmlspecialchars($prac['ID']) . "<br>" .
                    htmlspecialchars($prac['Titulo']) . "<br>" .
                    htmlspecialchars($prac['Carrera']) . "<br>" .
                    htmlspecialchars($prac['Estatus']) . "<br>" .
                    "Integrantes: " . htmlspecialchars($prac['Integrantes'])
                ?>
            </button>
        <?php endforeach; ?>
    <?php endif; ?>
</div>