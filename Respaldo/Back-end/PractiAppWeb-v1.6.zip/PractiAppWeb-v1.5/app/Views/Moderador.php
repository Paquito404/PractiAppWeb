
<?php if (session()->has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
  <?= session()->getFlashdata('success') ?>
  <button type="button" class="close" data-dismiss="alert" aria-label="Cerrar">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
<?php endif; ?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moderador</title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/css/styles.css') ?>">
</head>
<body>

<div class="nav-wrapper">
        <nav id="navbar" class="navbar">
  <div class="header-container">
            <img src="<?= base_url('assets/img/logo.png') ?>" alt="Nombre de tu Sitio" width="70" height="70">
            <h1 class="texto-header">Practicas profesionales unison (moderador)</h1>
        </div>
        <ul>
            <li><button onclick="loadContent('inicio')">Tus proyectos</button></li>
            <li><button onclick="loadContent('formulario')">Subir proyectos</button></li>
            <li><button onclick="loadContent('papelera')">Papelera</button></li>
            <li><button onclick="loadContent('revisar')">En revision</button></li>
            <li><button onclick="loadContent('buscar')">Base de datos</button></li>
            <li><button onclick="loadContent('registroM')">Registrar maestro</button></li>
            <li><button onclick="loadContent('registroC')">Registrar coordinador</button></li>
            <li class="alinear-derecha"><button id="btnUsuario" onclick="mostrarModerador()">Usuario</button></li>
        </ul>

        </nav>
    </div>

    <div id="content"> 
    </div>

    <div id="usuarioPanel">
    <div id="infoUsuario">
        <p>Cargando información...</p>
    </div>
    <button onclick="cerrarPanel()">Cerrar</button>
    <a href="<?= base_url('logout') ?>"><button>Cerrar sesión</button></a>
    </div>

    <script>
    const baseUrl = "<?= base_url() ?>";
    const idUsuario = <?= session('usuario_id') ?? 'null' ?>;
    </script>
    <script src="<?= base_url('assets/js/script.js') ?>"></script>
<!-- Incluye SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if (session()->has('success')): ?>
  <script>
    Swal.fire({
      text: '<?= esc(session()->getFlashdata('success')) ?>',
      confirmButtonText: 'Aceptar'
    });
  </script>
<?php endif; ?>
</body>
</html>