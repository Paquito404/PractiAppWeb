<h1 class="texto-practica">Detalles del estudiante</h1>

<div class="tabla-contenedor">
    <?php if (isset($alumno)): ?>
        <table border="1" cellpadding="10">
            <tr>
                <th>ID</th>
                <th>nombre</th>
                <th>Carrera</th>
                <th>Correo</th>
            </tr>
            <tr>
                <td><?= htmlspecialchars($alumno['ID']) ?></td>
                <td><?= htmlspecialchars($alumno['nombre']) ?></td>
                <td><?= htmlspecialchars($alumno['carrera']) ?></td>
                <td><?= htmlspecialchars($alumno['correo']) ?></td>
            </tr>
        </table>
    <?php else: ?>
        <p>No se encontraron los datos del alumno</p>
    <?php endif; ?>
</div>

<?php
    // Ruta a la imagen
    $imagenPath = base_url('alumnos/' . $alumno['ID'] . '-' . $alumno['correo'] . '.jpg');
    $imagenArchivo = FCPATH . 'alumnos/' . $alumno['ID'] . '-' . $alumno['correo'] . '.jpg';
?>

<?php if (file_exists($imagenArchivo)): ?>
    <div style="text-align: center; margin-top: 20px;">
        <h3>Imagen de la Práctica</h3>
        <img src="<?= $imagenPath . '?v=' . time() ?>" alt="Imagen de la práctica" width="200" height="200" style="object-fit: cover; border: 1px solid #ccc;">
    </div>
<?php else: ?>
    <div style="text-align: center; margin-top: 20px;">
        <p><em>No hay imagen asociada a este alumno</em></p>
    </div>
<?php endif; ?>

<div class="botones-tabla">
    <button onclick="aprobar(<?= $alumno['ID'] ?>)">Aprobar</button>
    <button onclick="rechazar(<?= $alumno['ID'] ?>)">Rechazar</button>
</div>