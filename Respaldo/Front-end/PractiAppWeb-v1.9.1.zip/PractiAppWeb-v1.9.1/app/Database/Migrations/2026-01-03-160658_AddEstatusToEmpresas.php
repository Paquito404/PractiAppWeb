<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddEstatusToEmpresas extends Migration
{
    public function up()
    {
        $this->forge->addColumn('empresas', [
            'estatus' => [
                'type'       => 'VARCHAR',
                'constraint' => 50,
                'default'    => 'En revisión',
                'null'       => false,
            ],
        ]);
        
        // Optional: Update existing records based on Fase (if needed)
        // $this->db->query("UPDATE empresas SET estatus = 'Aprobada' WHERE Fase = 2");
    }

    public function down()
    {
        $this->forge->dropColumn('empresas', 'estatus');
    }
}
