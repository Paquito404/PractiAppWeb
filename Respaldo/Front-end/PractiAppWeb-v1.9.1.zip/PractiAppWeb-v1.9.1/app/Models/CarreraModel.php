<?php

namespace App\Models;
use CodeIgniter\Model;

class CarreraModel extends Model
{
    protected $table = 'Carreras';
    protected $returnType = 'array';
    protected $primaryKey = 'ID';
    protected $allowedFields = ['nombre', 
                                'Departamento'];

    protected $useTimestamps = false; 
}