<?php

/* 
//
TEMARIO

1.-Login
// Realiza todas las funciones del login
2.-Contenido dinamico
// Se encargar de cambiar el contenido de las paginas
3.-CRUD Practicas
// Encarga de insertar, crear, actualizar y la vista de practicas
4.-Registro
//Se encarga de registrar usuarios nuevos 
5.-Obtencion
//Obtiene los datos de usuarios ya registrados 
6.-Lista de estudiantes
//Encargado de manejar todo lo relacionado con la pestaña alumnos 

*/

namespace App\Controllers;

use CodeIgniter\I18n\Time;

use App\Models\EscuelaModel;
use App\Models\AlumnoModel;
use App\Models\CarreraModel;
use App\Models\MaestroModel;
use App\Models\EmpresaModel;
use App\Models\CoordinadorModel;
use App\Models\DepartamentoModel;
use App\Models\ModeradorModel;

class Home extends BaseController
{
    //---------------------- Login -------------------------//

    public function index()
    {   
        $tipo = session()->get('tipo');

        if (session()->get('logged_in') && $tipo == 'alumno') {
            
            return view('Alumno', [
            'nombre' => session()->get('nombre'),
            'correo' => session()->get('correo'),
            'tipo' => session()->get('tipo')
            ]);

        }

        if (session()->get('logged_in') && $tipo == 'maestro') {
            
            return view('Maestro', [
            'nombre' => session()->get('nombre'),
            'correo' => session()->get('correo'),
            'tipo' => session()->get('tipo')
            ]);

        }

        if (session()->get('logged_in') && $tipo == 'coordinador') {
            
            return view('Coordinador', [
            'nombre' => session()->get('nombre'),
            'correo' => session()->get('correo'),
            'tipo' => session()->get('tipo')
            ]);

        }

        if (session()->get('logged_in') && $tipo == 'moderador') {
            
            return view('Moderador', [
            'nombre' => session()->get('nombre'),
            'correo' => session()->get('correo'),
            'tipo' => session()->get('tipo')
        ]);

        }

        if (session()->get('logged_in') && $tipo == 'empresa') {
            
            return view('Empresa', [
            'nombre' => session()->get('nombre'),
            'correo' => session()->get('correo'),
            'tipo' => session()->get('tipo')
        ]);

        }

        return view('Login');

    }

    public function login(){

        $alumnoModel = new AlumnoModel();
        $maestroModel = new MaestroModel();
        $coordinadorModel = new CoordinadorModel();
        $moderadorModel = new ModeradorModel();
        $empresaModel = new EmpresaModel();

        $correo = $this->request->getPost('correo');
        $contraseña = $this->request->getPost('password');

        $alumno = $alumnoModel->where('correo', $correo)->first();
        $maestro = $maestroModel->where('correo', $correo)->first();
        $coordinador = $coordinadorModel->where('correo', $correo)->first();
        $moderador = $moderadorModel->where('correo', $correo)->first();
        $empresa = $empresaModel->where('correo', $correo)->first();

        if ($alumno && $alumno['password'] === $contraseña) {
            session()->set([
                'usuario_id' => $alumno['ID'],
                'nombre' => $alumno['nombre'],
                'carrera' => $alumno['carrera'],
                'correo' => $alumno['correo'],
                'semestre' => $alumno['semestre'],
                'tipo' => 'alumno',
                'logged_in' => true
            ], $alumno['ID']);
            return redirect()->to('/alumno');
        }

        if ($maestro && $maestro['password'] === $contraseña) {
            session()->set([
                'usuario_id' => $maestro['ID'],
                'nombre' => $maestro['nombre'],
                'departamento' => $maestro['departamento'],
                'correo' => $maestro['correo'],
                'tipo' => 'maestro',
                'logged_in' => true
            ], $maestro['ID']);
            return redirect()->to('/maestro');
        }

        if ($coordinador && $coordinador['password'] === $contraseña) {
            session()->set([
                'usuario_id' => $coordinador['ID'],
                'nombre' => $coordinador['nombre'],
                'departamento' => $coordinador['departamento'],
                'correo' => $coordinador['correo'],
                'tipo' => 'coordinador',
                'logged_in' => true
            ], $coordinador['ID']);
            return redirect()->to('/coordinador');
        }

        if ($moderador && $moderador['password'] === $contraseña) {
            session()->set([
                'usuario_id' => $moderador['ID'],
                'nombre' => $moderador['nombre'],
                'departamento' => $moderador['departamento'],
                'correo' => $moderador['correo'],
                'tipo' => 'moderador',
                'logged_in' => true
            ], $moderador['ID']);
            return redirect()->to('/moderador');
        }

        if ($empresa && $empresa['password'] === $contraseña) {
            if($empresa['estatus'] === 'Aprobada'){
                session()->set([
                'usuario_id' => $empresa['ID'],
                'nombre' => $empresa['nombre'],
                'departamento' => $empresa['departamento'],
                'correo' => $empresa['correo'],
                'tipo' => 'empresa',
                'logged_in' => true
            ], $empresa['ID']);
            return redirect()->to('/empresa');
            }else{
                return redirect()->to('/')->with('error', 'Este usuario no ha sido aprobado');
            }
        }

        return redirect()->to('/')->with('error', 'Correo o contraseña incorrectos');
        
    }

    public function alumno(){

        $tipo = session()->get('tipo');
        if (!session()->get('logged_in') || $tipo != 'alumno') {
            return redirect()->to('/');
        }

        return view('Alumno', [
            'nombre' => session()->get('nombre'),
            'correo' => session()->get('correo'),
            'tipo' => session()->get('tipo')
        ]);

    }

    public function maestro(){

        $tipo = session()->get('tipo');
        if (!session()->get('logged_in') || $tipo != 'maestro') {
            return redirect()->to('/');
        }

        return view('Maestro', [
            'nombre' => session()->get('nombre'),
            'correo' => session()->get('correo'),
            'tipo' => session()->get('tipo')
        ]);

    }

    public function coordinador(){

        
        $tipo = session()->get('tipo');
        if (!session()->get('logged_in') || $tipo != 'coordinador') {
            return redirect()->to('/');
        }

        return view('Coordinador', [
            'nombre' => session()->get('nombre'),
            'correo' => session()->get('correo'),
            'tipo' => session()->get('tipo')
        ]);

    }

    public function moderador(){

        $tipo = session()->get('tipo');
        if (!session()->get('logged_in') || $tipo != 'moderador') {
            return redirect()->to('/');
        }

        return view('Moderador', [
            'nombre' => session()->get('nombre'),
            'correo' => session()->get('correo'),
            'tipo' => session()->get('tipo')
        ]);

    }

    public function empresa(){

        $tipo = session()->get('tipo');
        if (!session()->get('logged_in') || $tipo != 'empresa') {
            return redirect()->to('/');
        }

        return view('Empresa', [
            'nombre' => session()->get('nombre'),
            'correo' => session()->get('correo'),
            'tipo' => session()->get('tipo')
        ]);

    }

    public function form_empresa(){
        $carreraModel = new CarreraModel();
        $departamentoModel = new DepartamentoModel();

        $data = [
            'departamento' => $departamentoModel->findAll(),
            'carrera' => $carreraModel->findAll()
        ];

        return view('Form_Empresa', $data);
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/');
    }

    //------------------------------------------------------//

///////////////////////////////////////////////////////////////////////

    //--------------- contenido dinamico -------------------//

    public function carga($pagina){

    $escuelaModel = new EscuelaModel();
    $carreraModel = new CarreraModel();
    $departamentoModel = new DepartamentoModel();
    $empresaModel = new EmpresaModel();
    
    $empresa = $empresaModel->findAll();
    $departamento = $departamentoModel->findAll();
    $carrera = $carreraModel->findAll();

    $practica = [];

    // En esta parte si ingresas a la pestaña "base de datos" este codigo la hace funcionar

    if ($pagina === 'buscar') {
        $estatus = $this->request->getGet('estatus');
        $fecha = $this->request->getGet('fecha');
        $carreraFiltro = $this->request->getGet('carrera');
        $integrantes = $this->request->getGet('integrantes');

        $builder = $escuelaModel->builder();

        if ($estatus) {
            $builder->where('Estatus', $estatus);
        }

        if ($carreraFiltro) {
            $builder->where('Carrera', $carreraFiltro);
        }

        if ($integrantes !== null && $integrantes !== '') {
            if ($integrantes == 0) {
                $builder->where('Integrantes', 0);
            } else {
                $builder->where('Integrantes >', 0);
            }
        }

        if ($fecha) {
            $builder->orderBy('ID', $fecha); 
        } else {
            $builder->orderBy('ID', 'asc');
        }

        $practica = $builder->get()->getResultArray();
        } else {
        $practica = $escuelaModel->findAll();
        }

        // Hasta aqui termina 

        $allowedPages = [
        'buscar',
        'datos_practica',
        'formulario',
        'inicio',
        'papelera',
        'registroC',
        'registroM',
        'revisar',
        'proyectos',
        'empresas'
        ];

    if (!in_array($pagina, $allowedPages)) {
        return $this->response->setStatusCode(404)->setBody('Página no encontrada');
    }

    $data = [
        'practica' => $practica,
        'carrera' => $carrera,
        'departamento' => $departamento,
        'empresa' => $empresa

    ];

    return view('contenido/' . $pagina, $data);
}

    public function carga_debug($pagina){

    $escuelaModel = new EscuelaModel();
    $carreraModel = new CarreraModel();
    $departamentoModel = new DepartamentoModel();
    $empresaModel = new EmpresaModel();
    
    $empresa = $empresaModel->findAll();
    $departamento = $departamentoModel->findAll();
    $carrera = $carreraModel->findAll();

    $practica = [];

    // En esta parte si ingresas a la pestaña "base de datos" este codigo la hace funcionar

    if ($pagina === 'buscar') {
        $estatus = $this->request->getGet('estatus');
        $fecha = $this->request->getGet('fecha');
        $carreraFiltro = $this->request->getGet('carrera');
        $integrantes = $this->request->getGet('integrantes');

        $builder = $escuelaModel->builder();

        if ($estatus) {
            $builder->where('Estatus', $estatus);
        }

        if ($carreraFiltro) {
            $builder->where('Carrera', $carreraFiltro);
        }

        if ($integrantes !== null && $integrantes !== '') {
            if ($integrantes == 0) {
                $builder->where('Integrantes', 0);
            } else {
                $builder->where('Integrantes >', 0);
            }
        }

        if ($fecha) {
            $builder->orderBy('ID', $fecha); 
        } else {
            $builder->orderBy('ID', 'asc');
        }

        $practica = $builder->get()->getResultArray();
        } else {
        $practica = $escuelaModel->findAll();
        }

        // Hasta aqui termina 

        $allowedPages = [
        'buscar',
        'datos_practica',
        'formulario',
        'inicio',
        'papelera',
        'registroC',
        'registroM',
        'revisar',
        'proyectos',
        'empresas'
        ];

    if (!in_array($pagina, $allowedPages)) {
        return $this->response->setStatusCode(404)->setBody('Página no encontrada');
    }

    $data = [
        'practica' => $practica,
        'carrera' => $carrera,
        'departamento' => $departamento,
        'empresa' => $empresa

    ];

    // Use debug version for inicio page
    if ($pagina === 'inicio') {
        return view('contenido/inicio_debug', $data);
    }

    return view('contenido/' . $pagina, $data);
}

    public function revision($id = null){

        if ($id === null) {
            return $this->response->setStatusCode(400)->setBody('Practica no proporcionado');
        }

        $escuelaModel = new EscuelaModel();
        $practica = $escuelaModel->find($id);

        if (!$practica) {
            return $this->response->setStatusCode(404)->setBody('Práctica no encontrada');
        }

        return view('extras/revision', ['practica' => $practica]);

    }

    public function borracion($id = null){

        if ($id === null) {
            return $this->response->setStatusCode(400)->setBody('Practica no proporcionado');
        }

        $escuelaModel = new EscuelaModel();
        $practica = $escuelaModel->find($id);

        if (!$practica) {
            return $this->response->setStatusCode(404)->setBody('Práctica no encontrada');
        }

        return view('extras/borracion', ['practica' => $practica]);

    }

    public function fase($id = null){

        $escuelaModel = new EscuelaModel();
        $moderadorModel = new ModeradorModel();
        $coordinadorModel = new CoordinadorModel();
        $maestroModel = new MaestroModel();
        $empresaModel = new EmpresaModel();

        $escuela = $escuelaModel->find($id);

        $maestro = $maestroModel->where('correo', $escuela['Autor'])->first();
        $coordinador = $coordinadorModel->where('correo', $escuela['Autor'])->first();
        $moderador = $moderadorModel->where('correo', $escuela['Autor'])->first();
        $empresa = $empresaModel->where('correo', $escuela['Autor'])->first();


        if ($maestro) {
            $post = $maestro['nombre'];
            $co = $maestro['correo'];
        }
        if ($coordinador) {
            $post = $coordinador['nombre'];
            $co = $coordinador['correo'];
        }

        if ($moderador) {
            $post = $moderador['nombre'];
            $co = $moderador['correo'];
        }
        if ($empresa) {
            $post = $empresa['nombre'];
            $co = $empresa['correo'];
        }

        $email = \Config\Services::email();
    
        $email->setFrom('notificacionesunison@gmail.com','subir proyecto');
        //$email->setTo($co['correo']);
        $email->setTo('joanko1402@gmail.com');
        $email->setSubject('proyecto');

        $subject3 = 'practica subida con exito';
        $message = "Hola, $post <br>"
             . "se subio tu practica.<br>"
             . "Saludos.";

        $email->setSubject($subject3);
        $email->setMessage($message);

        if (!$email->send()){
           session()->setFlashdata('success', 'Correo no enviado correctamente.');
        } else{
        $escuelaModel->update($id, [
            'Fase' => 2,
            'Fecha' => NULL
        ]);

        return $this->response->setJSON(['success' => true]);
 
     }
    }

    public function papelera($id = null){

        $escuelaModel = new EscuelaModel();

        $tiempo = Time::now()->addSeconds(10)->toDateTimeString(); 
        //si pasan mas de 10 segundos, se elimina la practica
        
        $escuelaModel->update($id, [
            'Fase' => 0,
            'Fecha' => $tiempo
        ]);

        return $this->response->setJSON(['success' => true]);

    }
    //------------------------------------------------------//

///////////////////////////////////////////////////////////////////////

    //---------------------- CRUD Practicas ----------------//

    public function vista($id = null){

        if ($id === null) {
            return $this->response->setStatusCode(400)->setBody('Practica no proporcionado');
        }

        $escuelaModel = new EscuelaModel();
        $practica = $escuelaModel->find($id);

        if (!$practica) {
            return $this->response->setStatusCode(404)->setBody('Práctica no encontrada');
        }

        return view('extras/lista', ['practica' => $practica]);

    }

    public function guardar(){

        $autor = session()->get('correo');
        $tipo = session()->get('tipo');

        $post = $this->request->getPost(['Titulo', 
                                'Requisitos',
                                'Carrera', 
                                'Estatus', 
                                'Integrantes',
                                'Pago',
                                'HorarioInicio',
                                'HorarioFinal', 
                                'FechaRegistroInicio',
                                'FechaRegistroFinal',
                                'FechaActividadInicio',
                                'FechaActividadFinal',
                                'Fase', 
                                'Fecha', 
                                'Imagen', 
                                'Autor']);
        $escuelaModel = new EscuelaModel();
        $carreraModel = new CarreraModel();
        $carrera = $carreraModel->findAll();

        foreach($carrera as $car){
        if(isset($post)){
            if($post['Carrera'] == $car['nombre']){
            $depart = $car['Departamento'];
            }
        }
        }
    
        $id = $escuelaModel->insert([
            'Titulo' => $post['Titulo'],
            'Requisitos' => $post['Requisitos'],
            'Carrera' => $post['Carrera'],
            'Departamento' => $depart,
            'Estatus' => $post['Estatus'],
            'Integrantes' => $post['Integrantes'],
            'Pago' => $post['Pago'],
            'HorarioInicio' => $post['HorarioInicio'],
            'HorarioFinal' => $post['HorarioFinal'],
            'FechaRegistroInicio' => $post['FechaRegistroInicio'],
            'FechaRegistroFinal' => $post['FechaRegistroFinal'],
            'FechaActividadInicio' => $post['FechaActividadInicio'],
            'FechaActividadFinal' => $post['FechaActividadFinal'],
            'Fase' => 1,
            'Autor' => $autor,
            'Postulados' => 0
        ], true);

        $escuelaModel->update($id, [
            'Imagen' => $id . '-' . $post['Carrera'] .'.jpg'
        ]);

        $imagen = $this->request->getFile('imagen');
            if ($imagen && $imagen->isValid()) {
            $imagen->move(ROOTPATH . 'public/imagenes', $id . '-' . $post['Carrera'] .'.jpg', true);

        }

        switch ($tipo) {
        case 'coordinador':
            $ruta = '/coordinador';
            break;

        case 'moderador':
            $ruta = '/moderador';
            break;

        default:
            $ruta = '/maestro';
            break;
        }

        session()->setFlashdata('success', 'Se subió la practica a revision ');
        return redirect()->to($ruta);

    }    

    public function editar($id = null){

        if ($id === null) {
            return $this->response->setStatusCode(400)->setBody('ID no proporcionado');
        }

        $escuelaModel = new EscuelaModel();
        $carreraModel = new CarreraModel();
        $carrera = $carreraModel->findAll();
        $practica = $escuelaModel->find($id);

        if (!$practica) {
            return $this->response->setStatusCode(404)->setBody('Práctica no encontrada');
        }

        return view('extras/editar', ['practica' => $practica, 'carrera' => $carrera]);

    }

    public function actualizar($id = null){
    
        $post = $this->request->getPost(['Titulo', 
                                'Requisitos',
                                'Carrera', 
                                'Estatus', 
                                'Integrantes',
                                'Pago',
                                'HorarioInicio',
                                'HorarioFinal', 
                                'FechaRegistroInicio',
                                'FechaRegistroFinal',
                                'FechaActividadInicio',
                                'FechaActividadFinal', 
                                'Fecha', 
                                'Imagen']);
        $escuelaModel = new EscuelaModel();

        $Imagen = $escuelaModel->find($id);
        $nombreOriginal = $Imagen['Imagen'];
    
        $escuelaModel->update($id, $post);

        $nombre = $id . '-' . $post['Carrera'] . '.jpg';

        $escuelaModel->update($id, [
            'Imagen' => $nombre
        ]);

        // Try to rename the old image file if it exists
        $OldPath = FCPATH . 'imagenes/' . $nombreOriginal;
        $NewPath = FCPATH . 'imagenes/' . $nombre;

        if (file_exists($OldPath) && $OldPath !== $NewPath) {
            @rename($OldPath, $NewPath);
        }

        // Handle new image upload
        $imagen = $this->request->getFile('imagen');
        if ($imagen && $imagen->isValid()) {
            $imagen->move(ROOTPATH . 'public/imagenes', $nombre, true);
        }

        return $this->response->setJSON(['success' => true]);

    }

    public function eliminar($id = null){

        if ($id === null) {
            return $this->response->setStatusCode(400)->setBody('ID no proporcionado');
        }

        $escuelaModel = new EscuelaModel();
        $practica = $escuelaModel->find($id);

        if (!$practica) {
            return $this->response->setStatusCode(404)->setBody('Práctica no encontrada');
        }


        $escuelaModel->delete($id);

        $imagenPath = ROOTPATH . 'public/imagenes/' . $id . '-' . $practica['Carrera'] . '.jpg';
        if (file_exists($imagenPath)) {
            unlink($imagenPath);
        }

    return $this->response->setJSON(['success' => true]);
         
    }

    //------------------------------------------------------//

//////////////////////////////////////////////////////////////////////

    //--------------------- Registros ------------------//

    public function guardarM(){

        $maestroModel = new MaestroModel();
        $post = $this->request->getPost(['nombre', 'departamento', 'correo', 'password']);
        

        $registro = $maestroModel->insert([
            'nombre' => $post['nombre'],
            'departamento' => $post['departamento'],
            'correo' => $post['correo'],
            'password' => $post['password']
        ], true);
        
        $imagen = $this->request->getFile('imagen');
        if ($imagen && $imagen->isValid()) {
            $imagen->move(ROOTPATH . 'public/maestros', $registro . '-' . $post['correo'] .'.jpg', true);
        }
       
            $tipo = session()->get('tipo');

            switch ($tipo) {
            case 'coordinador':
                $ruta = '/coordinador';
                break;

            case 'moderador':
                $ruta = '/moderador';
                break;

            default:
                $ruta = '/';
                break;
        }
        session()->setFlashdata('success', 'Se subieron los datos del maestro con éxito');
        return redirect()->to($ruta);

        
    }
  //------------------------------------------------------//

//////////////////////////////////////////////////////////////////////

    //--------------------- Registros ------------------//

   public function guardarC(){

        $coordinadorModel = new CoordinadorModel();
        $post = $this->request->getPost(['nombre', 'departamento', 'correo', 'password']); 

        $registro = $coordinadorModel->insert([
            'nombre' => $post['nombre'],
            'departamento' => $post['departamento'],
            'correo' => $post['correo'],
            'password' => $post['password']
        ], true);
        
        $imagen = $this->request->getFile('imagen');
        if ($imagen && $imagen->isValid()) {
            $imagen->move(ROOTPATH . 'public/coordinadores', $registro . '-' . $post['correo'] .'.jpg', true);
        }
        
        $tipo = session()->get('tipo');
        switch ($tipo) {
            case 'coordinador':
                $ruta = '/coordinador';
                break;

            case 'moderador':
                $ruta = '/moderador';
                break;

            default:
                $ruta = '/';
                break;
        }
            session()->setFlashdata('success', 'Se se subieron los datos del coordinador con mucho éxito'); 
            return redirect()->to($ruta); 
    

        }

    //------------------------------------------------------//

    //--------------------- Obtencion ------------------//
    
    public function ObtenerA($id){

        $alumnoModel = new AlumnoModel();
        $alumno = $alumnoModel->find($id);

        if (!$alumno) {
            return $this->response->setJSON(['error' => 'Alumno no encontrado'])->setStatusCode(404);
        }

        return $this->response->setJSON($alumno);

    }
    
    public function ObtenerM($id){

        $maestroModel = new MaestroModel();
        $maestro = $maestroModel->find($id);

        if (!$maestro) {
            return $this->response->setJSON(['error' => 'Maestro no encontrado'])->setStatusCode(404);
        }

        return $this->response->setJSON($maestro);

    }
    
    public function ObtenerC($id){

        $coordinadorModel = new CoordinadorModel();
        $coordinador = $coordinadorModel->find($id);

        if (!$coordinador) {
            return $this->response->setJSON(['error' => 'Coordinador no encontrado'])->setStatusCode(404);
        }

        return $this->response->setJSON($coordinador);

    }

    public function ObtenerMo($id){

        $moderadorModel = new ModeradorModel();
        $moderador = $moderadorModel->find($id);

        if (!$moderador) {
            return $this->response->setJSON(['error' => 'Moderador no encontrado'])->setStatusCode(404);
        }

        return $this->response->setJSON($moderador);

    }

    public function ObtenerE($id){

        $empresaModel = new EmpresaModel();
        $empresa = $empresaModel->find($id);

        if (!$empresa) {
            return $this->response->setJSON(['error' => 'Empresa no encontrada'])->setStatusCode(404);
        }

        return $this->response->setJSON($empresa);

    }

    //--------------------------- lista de estudiantes ------------------------------//

    public function vistaA($id = null){

        if ($id === null) {
            return $this->response->setStatusCode(400)->setBody('Practica no proporcionado');
        }

        $escuelaModel = new EscuelaModel();
        $practica = $escuelaModel->find($id);

        if (!$practica) {
            return $this->response->setStatusCode(404)->setBody('Práctica no encontrada');
        }

        return view('extras/listaA', ['practica' => $practica]);

    }
    
    public function estudiantes($id = null){

        $alumnoModel = new AlumnoModel();
        $alumno = $alumnoModel->findAll();

        $escuelaModel = new EscuelaModel();
        $practica = $escuelaModel->find($id);

        return view('extras/estudiantes', ['alumno' => $alumno, 'practica' => $practica]);
    }

    public function postulados($id = null){ 

        $alumnoModel = new AlumnoModel();
        $alumno = $alumnoModel->findAll();

        $escuelaModel = new EscuelaModel();
        $practica = $escuelaModel->find($id);

        return view('extras/postulados', ['alumno' => $alumno, 'practica' => $practica]);

    }

    public function api_postulados($id = null) {
        if ($id === null) {
            return $this->response->setJSON(['error' => 'ID no proporcionado']);
        }

        $alumnoModel = new AlumnoModel();
        // Filter for all students who applied to this practice and are in Fase 2
        // Using simple query for safety
        $alunos = $alumnoModel->where('ID_Practica', $id)
                            ->where('Fase', 2)
                            ->findAll();

        // The frontend expects { "data": [ ... ] }
        return $this->response->setJSON(['data' => $alunos]);
    }

    public function api_estudiantes($id = null) {
        if ($id === null) {
            return $this->response->setJSON(['error' => 'ID no proporcionado']);
        }

        $alumnoModel = new AlumnoModel();
        // Filter for all students who are accepted (Fase 3) in this practice
        $alunos = $alumnoModel->where('ID_Practica', $id)
                            ->where('Fase', 3)
                            ->findAll();

        return $this->response->setJSON(['data' => $alunos]);
    }

    public function aplicar($id = null){
        $id_alumno = session()->get('usuario_id');
        $alumnoModel = new AlumnoModel();
        $escuelaModel = new EscuelaModel();

        $practica = $escuelaModel->findAll();
        $alumno = $alumnoModel->find($id_alumno);
        $escuela = $escuelaModel->find($id);

        $alumnoModel->update($id_alumno, [
            
            'Fase' => 2,
            'ID_Practica' => $id

        ]);
        $escuelaModel->update($id, [
            
            'Postulados' => $escuela['Postulados'] + 1

        ]);

        return view('contenido/inicio', ['alumno' => $alumno, 'practica' => $practica]);

    }

    public function datos_estudiante($id = null){

        if ($id === null) {
            return $this->response->setStatusCode(400)->setBody('Alumno no proporcionado');
        }

        $alumnoModel = new AlumnoModel();
        $alumno = $alumnoModel->find($id);

        if (!$alumno) {
            return $this->response->setStatusCode(404)->setBody('Alumno no encontrado');
        }

        return view('extras/datos_estudiante', ['alumno' => $alumno]);

    }

    public function datos_postulados($id = null){

        if ($id === null) {
            return $this->response->setStatusCode(400)->setBody('Alumno no proporcionado');
        }

        $alumnoModel = new AlumnoModel();
        $alumno = $alumnoModel->find($id);

        if (!$alumno) {
            return $this->response->setStatusCode(404)->setBody('Alumno no encontrado');
        }

        return view('extras/datos_postulados', ['alumno' => $alumno]);

    }

    public function aprobar($id = null){

        $escuelaModel = new EscuelaModel();
        $alumnoModel = new AlumnoModel();

        $practica = $escuelaModel->findAll();
        $alumno = $alumnoModel->find($id);
        $ID_Practica = $alumno['ID_Practica'];
        $escuela = $escuelaModel->find($ID_Practica);
        $grupo = $alumnoModel->where('ID_Practica', $escuela['ID'])->findAll();

        $escuelaModel->update($ID_Practica, [

            'Integrantes' => $escuela['Integrantes'] - 1

        ]);
        $alumnoModel->update($id, [

            'Fase' => 3

        ]);

        $email = \Config\Services::email();
        $email->setFrom('notificacionesunison@gmail.com', 'Aviso importante');  // Remitente
        $email->setTo('joanko1402@gmail.com');                        // Destinatario: correo del alumno
        $email->setSubject('¡Alumno aprobado!');                 // Asunto
        $email->setMessage('Felicidades: fuiste aprobado en la practica .');  // Mensaje (puedes personalizar)

        if (!$email->send()) {
            log_message('error', 'Error al enviar correo de aprobación a alumno ID '.$id.': '.$email->printDebugger(['headers']));
        }

        $nuevosIntegrantes = $escuela['Integrantes'] - 1;

        if($nuevosIntegrantes <= 0){

            foreach($grupo as $gr){
            
                if($gr['ID_Practica'] == $escuela['ID'] && $gr['ID'] != $id){

                $alumnoModel->update($gr['ID'], [

                    'Fase' => 1,
                    'ID_Practica' => NULL

                ]);
                if (!empty($escuela) && array_key_exists('ID', $escuela) && array_key_exists('Postulados', $escuela)) {
                
                        $escuela['Postulados'] = max(0, $escuela['Postulados'] - 1); 
                        
                        $escuelaModel->update($escuela['ID'], [
                        
                            'Postulados' => $escuela['Postulados']
                        
                        ]);
                }
               }
              } 
             }

        return view('/contenido/inicio', ['practica' => $practica]);
    }

        public function rechazar($id = null){

        $escuelaModel = new EscuelaModel();
        $alumnoModel = new AlumnoModel();
        $practica = $escuelaModel->findAll();
        $alumno = $alumnoModel->find($id);
        $ID_Practica = $alumno['ID_Practica'];
        $escuela = $escuelaModel->find($ID_Practica);

        if($alumno['Fase'] == 3){

            $escuelaModel->update($ID_Practica, [

            'Integrantes' => $escuela['Integrantes'] + 1,
            'Postulados' => $escuela['Postulados'] - 1

        ]);
        }else{

            $escuelaModel->update($ID_Practica, [
                
            'Postulados' => $escuela['Postulados'] - 1

        ]);

        }
        $alumnoModel->update($id, [

            'Fase' => 1,
            'ID_Practica' => NULL

        ]);

        session()->setFlashdata('success', 'Se rechazo el estudiante'); 
        return view('/contenido/inicio', ['practica' => $practica]);

    }

    //----------------------------------- empresas.php --------------------------------------------//

    public function registro(){
        $post = $this->request->getPost(['nombre', 
                                'correo', 
                                'rfc',
                                'departamento', 
                                'password' 
                                ]);
        
        // Validation check to prevent DB crash
        if (empty($post['nombre']) || empty($post['correo']) || empty($post['rfc']) || 
            empty($post['departamento']) || empty($post['password'])) {
            // Simply redirect back - flash data causes session header issues
            return redirect()->to(base_url('form_empresa'));
        }
        
        $empresaModel = new EmpresaModel();

        $id = $empresaModel->insert([
                'nombre' => $post['nombre'], 
                'correo' => $post['correo'], 
                'RFC' => $post['rfc'], 
                'departamento' => $post['departamento'], 
                'password' => $post['password'], 
            'Fase' => 1,
            'estatus' => 'En revisión'
            ], true);

        if ($id) {
            $empresaModel->update($id, [
                'imagen' => $id . '-' . $post['correo'] .'.jpg'
            ]);
            $empresaModel->update($id, [
                'constancia' => $id . '-' . $post['correo'] .'.pdf'
            ]);
            $empresaModel->update($id, [
                'FPP1' => $id . '-' . $post['correo'] .'.pdf'
            ]);

            $imagen = $this->request->getFile('imagen');
            if ($imagen && $imagen->isValid()) {
                $imagen->move(ROOTPATH . 'public/empresas', $id . '-' . $post['correo'] .'.jpg', true);
            }
            
            $constancia = $this->request->getFile('Constancia');
            if ($constancia && $constancia->isValid()) {
                $constancia->move(ROOTPATH . 'public/constancia', $id . '-' . $post['correo'] .'.pdf', true);
            }
            
            $FPP1 = $this->request->getFile('FPP-1');
            if ($FPP1 && $FPP1->isValid()) {
                $FPP1->move(ROOTPATH . 'public/FPP-1', $id . '-' . $post['correo'] .'.pdf', true);
            }
        }

        return redirect()->to('/')->with('message', 'Empresa registrada con éxito. Por favor espera aprobación.');
    }

    public function vistaE($id = null){

        if ($id === null) {
            return $this->response->setStatusCode(400)->setBody('Empresa no proporcionado');
        }

        $empresaModel = new EmpresaModel();
        $empresa = $empresaModel->find($id);

        if (!$empresa) {
            return $this->response->setStatusCode(404)->setBody('Empresa no encontrada');
        }

        return view('extras/listaE', ['empresa' => $empresa]);

    }

    public function unirse($id = null){

        $empresaModel = new EmpresaModel();
        $empresa = $empresaModel->find($id);

        // $alumnoModel = new AlumnoModel():
        // $alumno = $alumnoModel->find($id);
        // $correo = $alumno['correo'];
        $email = \Config\Services::email();
        $email->setFrom('notificacionesunison@gmail.com', 'Aviso importante');  // Remitente
        $email->setTo('joanko1402@gmail.com');                        // Destinatario: correo del alumno
        $email->setSubject('¡Empresa Aprobada!');                 // Asunto
        $email->setMessage('Felicidades, aprobamos la empresa');  // Mensaje (puedes personalizar)
 
        if (!$email->send()) {
            log_message('error', 'Error al enviar correo de aprobación a alumno ID '.$id.': '.$email->printDebugger(['headers']));
        }
      
        $empresaModel = new EmpresaModel();

        $empresaModel->update($id, [
            'Fase' => 2,
            'estatus' => 'Aprobada'
        ]);
        return $this->response->setJSON(['success' => true]);

    }

    /*public function desaprobar($id = null){

        $empresaModel = new EmpresaModel();
        $empresa = $empresaModel->find($id);

        if ($id === null) {
            return $this->response->setStatusCode(400)->setBody('ID no proporcionado');
        }
      
        if (!$empresa) {
            return $this->response->setStatusCode(404)->setBody('empresa no encontrada');
        }

        $empresaModel->delete($id);

        $imagenPath = ROOTPATH . 'public/empresas/' . $id . '-' . $empresa['correo'] . '.jpg';
        $constanciaPath = ROOTPATH . 'public/constancia/' . $id . '-' . $empresa['correo'] . '.pdf';
        $FPP1Path = ROOTPATH . 'public/FPP-1/' . $id . '-' . $empresa['correo'] . '.pdf';
        if (file_exists($imagenPath) && file_exists($constanciaPath) && file_exists($FPP1Path)) {
            unlink($imagenPath);
            unlink($constanciaPath);
            unlink($FPP1Path);
        }

        return $this->response->setJSON(['success' => true]);

    }*/

    //----------------------------------- correos.php --------------------------------------------//

    public function sendCommentE(){

        $empresaModel = new empresaModel();
        $comment = $this->request->getPost('comment');
        $id = $this->request->getPost('id');
        $empresa = $empresaModel->find($id);

        $email = \Config\Services::email();
        $email->setFrom('notificacionesunison@gmail.com','emisor');
        $email->setTo('joanko1402@gmail.com');
        $email->setSubject('Empresa Rechazada');
        $email->setMessage("Razon de su eliminación:\n\n" . $comment);

         if ($email->send()) {
            // Aquí podrías redirigir con un mensaje de éxito
            $imagenPath = ROOTPATH . 'public/empresas/' . $id . '-' . $empresa['correo'] . '.jpg';
            $constanciaPath = ROOTPATH . 'public/constancia/' . $id . '-' . $empresa['correo'] . '.pdf';
            $FPP1Path = ROOTPATH . 'public/FPP-1/' . $id . '-' . $empresa['correo'] . '.pdf';
            if (file_exists($imagenPath) && file_exists($constanciaPath) && file_exists($FPP1Path)) {
                unlink($imagenPath);
                unlink($constanciaPath);
                unlink($FPP1Path);
            }
            $empresaModel->delete($id);
            return redirect()->to('/')->with('success', 'Ya se notifico a la empresa');
        } else {
            // Obtener errores
            $errores = $email->printDebugger(['headers']);
            // Redirigir con error (o mostrar directamente)
            return redirect()->to('/')->with('error', $errores);
        }
    }
    
    public function sendCommentA(){

        $comment = $this->request->getPost('comment');
        $id = $this->request->getPost('id');

        $escuelaModel = new EscuelaModel();
        $alumnoModel = new AlumnoModel();
        $practica = $escuelaModel->findAll();
        $alumno = $alumnoModel->find($id);
        $ID_Practica = $alumno['ID_Practica'];
        $escuela = $escuelaModel->find($ID_Practica);

        $email = \Config\Services::email();
        $email->setFrom('notificacionesunison@gmail.com','emisor');
        $email->setTo('joanko1402@gmail.com');
        $email->setSubject('Lo sentimos, el proyecto te rechazó');
        $email->setMessage("Razon:\n\n" . $comment);

         if ($email->send()) {
            // Aquí podrías redirigir con un mensaje de éxito

            if($alumno['Fase'] == 3){

            $escuelaModel->update($ID_Practica, [

            'Integrantes' => $escuela['Integrantes'] + 1,
            'Postulados' => $escuela['Postulados'] - 1

        ]);
        }else{

            $escuelaModel->update($ID_Practica, [
                
            'Postulados' => $escuela['Postulados'] - 1

        ]);

        }
        $alumnoModel->update($id, [

            'Fase' => 1,
            'ID_Practica' => NULL

        ]);

            return redirect()->to('/')->with('success', 'Ya se notifico al alumno');
        } else {
            // Obtener errores
            $errores = $email->printDebugger(['headers']);
            // Redirigir con error (o mostrar directamente)
            return redirect()->to('/')->with('error', $errores);
        }
    }

    /*public function rechazar($id = null){

        $escuelaModel = new EscuelaModel();
        $alumnoModel = new AlumnoModel();
        $practica = $escuelaModel->findAll();
        $alumno = $alumnoModel->find($id);
        $ID_Practica = $alumno['ID_Practica'];
        $escuela = $escuelaModel->find($ID_Practica);

        if($alumno['Fase'] == 3){

            $escuelaModel->update($ID_Practica, [

            'Integrantes' => $escuela['Integrantes'] + 1,
            'Postulados' => $escuela['Postulados'] - 1

        ]);
        }else{

            $escuelaModel->update($ID_Practica, [
                
            'Postulados' => $escuela['Postulados'] - 1

        ]);

        }
        $alumnoModel->update($id, [

            'Fase' => 1,
            'ID_Practica' => NULL

        ]);

        session()->setFlashdata('success', 'Se rechazo el estudiante'); 
        return view('/contenido/inicio', ['practica' => $practica]);

    }*/

    public function sendCommentP(){

        $escuelaModel = new EscuelaModel();
        $comment = $this->request->getPost('comment');
        $id = $this->request->getPost('id');
        $practica = $escuelaModel->find($id);

        $email = \Config\Services::email();
        $email->setFrom('notificacionesunison@gmail.com','emisor');
        $email->setTo('joanko1402@gmail.com');
        $email->setSubject('Tu practica no fue aceptada');
        $email->setMessage("Razon:\n\n" . $comment);

         if ($email->send()) {
            // Aquí podrías redirigir con un mensaje de éxito
            $escuelaModel->delete($id);

            $imagenPath = ROOTPATH . 'public/imagenes/' . $id . '-' . $practica['Carrera'] . '.jpg';
            if (file_exists($imagenPath)) {
                unlink($imagenPath);
            }

            return redirect()->to('/')->with('success', 'Ya se notifico al practicante');
        } else {
            // Obtener errores
            $errores = $email->printDebugger(['headers']);
            // Redirigir con error (o mostrar directamente)
            return redirect()->to('/')->with('error', $errores);
        }
    }

}