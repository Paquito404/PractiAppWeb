<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Empresa - Prácticas Profesionales Unison</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= base_url('assets/css/styles.css') ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(rgba(255, 255, 255, 0.85), rgba(255, 255, 255, 0.85)),
                        url('<?= base_url('assets/img/background.jpg') ?>');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            height: 100vh;
            overflow: hidden;
        }

        .main-container {
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background: linear-gradient(135deg, #2675db 0%, #1e5bb8 100%);
            padding: 0;
            width: 100%;
            display: flex;
            align-items: center;
            height: 70px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-content {
            display: flex;
            align-items: center;
            padding: 0 2rem;
            width: 100%;
        }

        .logo-img {
            height: 50px;
            margin-right: 1rem;
        }

        .header h1 {
            font-size: 1.5rem;
            color: white;
            margin: 0;
            font-weight: 500;
        }

        .registration-footer {
            margin-top: auto;
            padding: 1rem;
            text-align: center;
            background: rgba(255, 255, 255, 0.8);
            border-top: 1px solid #ddd;
        }

        /* Adjustment for standalone usage */
        .formulario-container {
            max-width: 1000px;
            margin: 2rem auto;
            height: auto;
            max-height: calc(100vh - 150px);
            overflow-y: auto;
        }
        
        @media (max-height: 800px) {
            .formulario-container {
                margin: 1rem auto;
            }
        }
    </style>
</head>
<body>
    <div class="main-container">
        <header class="header">
            <div class="header-content">
                <img src="<?= base_url('assets/img/logo.png') ?>" alt="Logo" class="logo-img">
                <h1>Prácticas Profesionales Unison</h1>
            </div>
        </header>

        <div class="formulario-container">
            <div class="formulario-header">
                <h1>Registro de Empresa</h1>
                <p class="formulario-subtitle">Completa el formulario para registrar tu empresa en el sistema</p>
            </div>

            <form action="<?= base_url('registro') ?>" method="post" autocomplete="off" enctype="multipart/form-data">
                <div class="formulario-content">
                    <div class="formulario-left">
                        <div class="image-upload-section">
                            <label for="imagen" class="image-upload-area" id="imageUploadArea">
                                <div class="upload-placeholder">
                                    <div class="upload-icon">📁</div>
                                    <p>Sube una foto de perfil</p>
                                </div>
                                <img id="vistaPrevia" src="#" alt="Vista previa" style="display:none; width:100%; height:100%; object-fit:cover;">
                            </label>
                            <input type="file" id="imagen" name="imagen" accept="image/jpeg" style="display:none">
                        </div>
                    </div>

                    <div class="formulario-right">
                        <div class="form-grid">
                            <div class="form-group half-width">
                                <label for="nombre">Nombre de la Empresa</label>
                                <input type="text" class="form-control" id="nombre" name="nombre" required placeholder="Nombre de la empresa">
                            </div>

                            <div class="form-group">
                                <label for="correo">Correo Electrónico</label>
                                <input type="email" class="form-control" id="correo" name="correo" required placeholder="ejemplo@correo.com">
                            </div>

                            <div class="form-group">
                                <label for="rfc">RFC de la Empresa</label>
                                <input type="text" class="form-control" id="rfc" name="rfc" required placeholder="RFC con homoclave">
                            </div>

                            <div class="form-group">
                                <label for="departamento">Departamento</label>
                                <select class="form-control" name="departamento" id="departamento" required>
                                    <option value="">Seleccione una opción</option>
                                    <?php foreach ($departamento as $dep): ?>
                                        <option value="<?= htmlspecialchars($dep['nombre']) ?>"><?= htmlspecialchars($dep['nombre']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="password">Contraseña</label>
                                <input type="password" class="form-control" id="password" name="password" required placeholder="Crea una contraseña">
                            </div>

                            <div class="form-group full-width">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="Constancia">Constancia de Situación Fiscal (PDF)</label>
                                        <input type="file" class="form-control" id="Constancia" name="Constancia" accept="application/pdf" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="FPP-1">Formato FPP-1 (PDF)</label>
                                        <input type="file" class="form-control" id="FPP-1" name="FPP-1" accept="application/pdf" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-actions">
                    <a href="<?= base_url('/') ?>" class="btn btn-secondary">Volver al Login</a>
                    <button type="submit" class="btn btn-primary">Registrar Empresa</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modales de notificación -->
    <?= view('partials/notification_modal') ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const input = document.getElementById('imagen');
            const area = document.getElementById('imageUploadArea');
            const preview = document.getElementById('vistaPrevia');
            
            // Image upload preview
            area.addEventListener('click', function(){ input.click(); });
            input.addEventListener('change', function(e){
                const file = e.target.files && e.target.files[0];
                if (!file) return;
                const reader = new FileReader();
                reader.onload = function(evt){
                    preview.src = evt.target.result;
                    preview.style.display = 'block';
                    const ph = area.querySelector('.upload-placeholder');
                    if (ph) ph.style.display = 'none';
                };
                reader.readAsDataURL(file);
            });

            // Form validation
            form.addEventListener('submit', function(e){
                // Check if image is uploaded
                if (!input.files || input.files.length === 0) {
                    e.preventDefault();
                    e.stopPropagation();
                    if (typeof showWarning === 'function') {
                        showWarning('Por favor, agrega una foto de perfil antes de continuar.');
                    } else {
                        alert('Por favor, agrega una foto de perfil antes de continuar.');
                    }
                    return false;
                }
                
                // Check file sizes (PHP limit is 2MB per file, 8MB total)
                const maxFileSize = 2 * 1024 * 1024; // 2MB in bytes
                const maxTotalSize = 8 * 1024 * 1024; // 8MB in bytes
                let totalSize = 0;
                
                // Check image file
                if (input.files[0] && input.files[0].size > maxFileSize) {
                    e.preventDefault();
                    e.stopPropagation();
                    alert('La imagen de perfil no debe exceder 2MB. Por favor selecciona una imagen más pequeña.');
                    return false;
                }
                totalSize += input.files[0] ? input.files[0].size : 0;
                
                // Check Constancia PDF
                const constanciaInput = document.getElementById('Constancia');
                if (constanciaInput && constanciaInput.files[0]) {
                    if (constanciaInput.files[0].size > maxFileSize) {
                        e.preventDefault();
                        e.stopPropagation();
                        alert('La Constancia no debe exceder 2MB. Por favor selecciona un archivo más pequeño.');
                        return false;
                    }
                    totalSize += constanciaInput.files[0].size;
                }
                
                // Check FPP-1 PDF
                const fppInput = document.getElementById('FPP-1');
                if (fppInput && fppInput.files[0]) {
                    if (fppInput.files[0].size > maxFileSize) {
                        e.preventDefault();
                        e.stopPropagation();
                        alert('El formato FPP-1 no debe exceder 2MB. Por favor selecciona un archivo más pequeño.');
                        return false;
                    }
                    totalSize += fppInput.files[0].size;
                }
                
                // Check total size
                if (totalSize > maxTotalSize) {
                    e.preventDefault();
                    e.stopPropagation();
                    alert('El tamaño total de los archivos no debe exceder 8MB. Por favor reduce el tamaño de los archivos.');
                    return false;
                }
            });
        });
    </script>
</body>
</html>
