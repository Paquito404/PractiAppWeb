<?php 
$depart = session()->get('departamento');
$tipo = session()->get('tipo');
?>

<div class="formulario-container">
    <div class="formulario-header">
        <h1>Registrar Maestro</h1>
        <p class="formulario-subtitle">Completa el formulario para registrar un nuevo maestro</p>
    </div>

    <form action="<?= base_url('registroM') ?>" method="post" autocomplete="off" enctype="multipart/form-data">
        <div class="formulario-content">
            <div class="formulario-left">
                <div class="image-upload-section">
                    <label for="imagen" class="image-upload-area" id="imageUploadArea">
                        <div class="upload-placeholder">
                            <div class="upload-icon">📁</div>
                            <p>Sube una imagen</p>
                        </div>
                        <img id="vistaPrevia" src="#" alt="Vista previa" style="display:none; width:100%; height:100%; object-fit:cover;">
                    </label>
                    <input type="file" id="imagen" name="imagen" accept="image/jpeg" style="display:none">
                </div>
            </div>

            <div class="formulario-right">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input class="form-control" type="text" name="nombre" id="nombre" required>
                    </div>
                    
                    <?php if ($tipo == 'moderador'): ?>
                        <div class="form-group">
                            <label for="departamento">Departamento</label>
                            <select class="form-control" name="departamento" id="departamento" required>
                                <option value="">Seleccione una opción</option>
                                <?php foreach ($departamento as $depa): ?>
                                    <option value="<?= htmlspecialchars($depa['nombre']) ?>"><?= htmlspecialchars($depa['nombre']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    <?php else: ?>
                        <input type="hidden" name="departamento" id="departamento" value="<?= htmlspecialchars($depart) ?>">
                        <div class="form-group">
                            <label>Departamento</label>
                            <input class="form-control" type="text" value="<?= htmlspecialchars($depart) ?>" disabled>
                        </div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="correo">Correo</label>
                        <input class="form-control" type="email" name="correo" id="correo" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <input class="form-control" type="password" name="password" id="password" required>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="button" class="btn btn-secondary" onclick="goBack()">Cancelar</button>
            <button type="submit" class="btn btn-primary">Registrar</button>
        </div>
    </form>
</div>

<script>
    // Use setTimeout to ensure the form is in the DOM (since content is loaded via AJAX)
    setTimeout(function(){
        const form = document.querySelector('form[action="<?= base_url('registroM') ?>"]');
        const input = document.getElementById('imagen');
        const area = document.getElementById('imageUploadArea');
        const preview = document.getElementById('vistaPrevia');
        
        if (!input || !area || !preview || !form) {
            console.warn('Form elements not found for registroM validation');
            return;
        }
        
        // Image upload preview - NO click listener needed (label 'for' handles it)
        input.addEventListener('change', function(e){
            const file = e.target.files && e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = function(evt){
                preview.src = evt.target.result;
                preview.style.display = 'block';
                const ph = area.querySelector('.upload-placeholder');
                if (ph) ph.style.display = 'none';
            };
            reader.readAsDataURL(file);
        });

        // Form submission validation
        form.addEventListener('submit', function(e){
            if (!input.files || input.files.length === 0) {
                e.preventDefault();
                e.stopPropagation();
                if (typeof showWarning === 'function') {
                    showWarning('Por favor, agrega una imagen antes de continuar.');
                } else {
                    alert('Por favor, agrega una imagen antes de continuar.');
                }
                return false;
            }
        }, true); // Use capture phase to ensure we catch it first
    }, 100);
</script>
