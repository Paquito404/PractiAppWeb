
<?php 
    use App\Models\AlumnoModel;
    $tipo = session()->get('tipo');
    $correo = session()->get('correo'); 
    $fecha = CodeIgniter\I18n\Time::now()->toDateTimeString();
?>

<?php if($tipo == 'alumno'): ?>

<?php
    $id_alumno  = session()->get('usuario_id'); 
    $semestre = session()->get('semestre'); 
    $alumnoModel = new AlumnoModel();
    $alumno = $alumnoModel->find($id_alumno);
    $Fase = $alumno['Fase'];

// DEBUG: Show student information
echo "<div style='background: #f0f0f0; padding: 20px; margin: 20px; border: 2px solid #333;'>";
echo "<h2>DEBUG - Student Information</h2>";
echo "<p><strong>Student ID:</strong> " . $id_alumno . "</p>";
echo "<p><strong>Student Semester (from session):</strong> " . $semestre . "</p>";
echo "<p><strong>Student Semester (from DB):</strong> " . (isset($alumno['semestre']) ? $alumno['semestre'] : 'NOT SET') . "</p>";
echo "<p><strong>Student Career:</strong> " . $alumno['carrera'] . "</p>";
echo "<p><strong>Student Fase:</strong> " . $Fase . "</p>";
echo "<p><strong>Current Date:</strong> " . $fecha . "</p>";
echo "</div>";

switch($Fase){
    case 2:
        echo '<div class="modern-projects-layout">
                <div class="projects-header">
                    <h1>Estado de Aplicación</h1>
                </div>
                <div class="no-projects-modern">
                    <div class="icon">⏳</div>
                    <h3>Aplicación en Proceso</h3>
                    <p>Actualmente estás aplicando para una práctica profesional. Por favor espera la respuesta del coordinador.</p>
                </div>
              </div>';
        return;
    case 3:
        echo '<div class="modern-projects-layout">
                <div class="projects-header">
                    <h1>Práctica Asignada</h1>
                    <p class="subtitle">Ya formas parte de una práctica profesional</p>
                </div>
                <div class="no-projects-modern">
                    <div class="icon">✅</div>
                    <h3>Práctica Activa</h3>
                    <p>Ya eres parte de una práctica profesional. Consulta la sección "Tus proyectos" para más detalles.</p>
                </div>
              </div>';
        return;
}

?>

<div class="modern-projects-layout">
    <div class="projects-header">
        <h1>Proyectos Disponibles</h1>
        <p class="subtitle">Encuentra y aplica a prácticas profesionales disponibles para tu carrera</p>
    </div>
    
    <?php 
    $availableProjects = [];
    $debugInfo = [];
    
    foreach ($practica as $prac) {
        $id = $prac['ID'];
        $nombre = $prac['Carrera'];
        $fase = $prac['Fase'];
        $imgPath = base_url('imagenes/' . $id . '-' . $nombre .'.jpg');
        $imgFile = FCPATH . 'imagenes/' . $id . '-' . $nombre . '.jpg';
        $hasImage = file_exists($imgFile);
        
        // DEBUG: Collect information about each practice
        $debugInfo[] = [
            'ID' => $id,
            'Titulo' => $prac['Titulo'],
            'Carrera' => $prac['Carrera'],
            'Fase' => $fase,
            'Estatus' => $prac['Estatus'],
            'Requisitos' => $prac['Requisitos'],
            'Integrantes' => $prac['Integrantes'],
            'FechaRegistroInicio' => $prac['FechaRegistroInicio'],
            'FechaRegistroFinal' => $prac['FechaRegistroFinal'],
            'checks' => [
                'fecha_inicio_ok' => ($fecha >= $prac['FechaRegistroInicio']),
                'fecha_final_ok' => ($fecha <= $prac['FechaRegistroFinal']),
                'carrera_match' => ($alumno['carrera'] == $prac['Carrera']),
                'fase_ok' => ($fase == 2),
                'estatus_ok' => ($prac['Estatus'] != 'Inactivo'),
                'semestre_ok' => ($semestre >= $prac['Requisitos']),
                'integrantes_ok' => ($prac['Integrantes'] > 0)
            ]
        ];
        
        // Validación incluyendo fechas de registro
        if ($fecha >= $prac['FechaRegistroInicio'] && $fecha <= $prac['FechaRegistroFinal'] && 
            $alumno['carrera'] == $prac['Carrera'] && $fase == 2 && $prac['Estatus'] != 'Inactivo' && 
            $semestre >= $prac['Requisitos'] && $prac['Integrantes'] > 0) {
            $availableProjects[] = [
                'data' => $prac,
                'hasImage' => $hasImage,
                'imgPath' => $imgPath
            ];
        }
    }
    
    // DEBUG: Show all practices and why they pass/fail
    echo "<div style='background: #fff3cd; padding: 20px; margin: 20px; border: 2px solid #856404; max-height: 400px; overflow-y: auto;'>";
    echo "<h2>DEBUG - All Practices Analysis</h2>";
    foreach ($debugInfo as $info) {
        echo "<div style='margin-bottom: 20px; padding: 10px; background: white; border: 1px solid #ccc;'>";
        echo "<h3>Practice ID: {$info['ID']} - {$info['Titulo']}</h3>";
        echo "<p><strong>Carrera:</strong> {$info['Carrera']}</p>";
        echo "<p><strong>Fase:</strong> {$info['Fase']}</p>";
        echo "<p><strong>Estatus:</strong> {$info['Estatus']}</p>";
        echo "<p><strong>Requisitos (Semestre):</strong> {$info['Requisitos']}</p>";
        echo "<p><strong>Integrantes:</strong> {$info['Integrantes']}</p>";
        echo "<p><strong>Fecha Registro:</strong> {$info['FechaRegistroInicio']} to {$info['FechaRegistroFinal']}</p>";
        echo "<h4>Validation Checks:</h4>";
        echo "<ul>";
        foreach ($info['checks'] as $check => $result) {
            $status = $result ? '✅ PASS' : '❌ FAIL';
            echo "<li><strong>{$check}:</strong> {$status}</li>";
        }
        echo "</ul>";
        $allPass = !in_array(false, $info['checks'], true);
        echo "<p style='font-weight: bold; color: " . ($allPass ? 'green' : 'red') . ";'>";
        echo $allPass ? "✅ THIS PRACTICE SHOULD BE VISIBLE" : "❌ THIS PRACTICE IS HIDDEN";
        echo "</p>";
        echo "</div>";
    }
    echo "</div>";
    ?>
    
    <?php if (empty($availableProjects)): ?>
        <div class="no-projects-modern">
            <div class="icon">📚</div>
            <h3>No hay proyectos disponibles</h3>
            <p>Por el momento no hay prácticas profesionales disponibles para tu carrera y semestre actual.</p>
        </div>
    <?php else: ?>
        <div class="modern-projects-grid">
            <?php foreach ($availableProjects as $project): ?>
                <?php $prac = $project['data']; ?>
                <div class="modern-project-card" onclick="loadPracticaA('<?= $prac['ID'] ?>')">
                    <div class="project-card-header">
                        <?php if ($project['hasImage']): ?>
                            <img src="<?= $project['imgPath'] . '?v=' . time() ?>" alt="<?= htmlspecialchars($prac['Titulo']) ?>" class="project-card-image">
                        <?php else: ?>
                            <div class="project-card-image-placeholder">
                                Sin imagen<br>disponible
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="project-card-content">
                        <h3 class="project-card-title"><?= htmlspecialchars($prac['Titulo']) ?></h3>
                        <div class="project-card-meta">
                            <div class="project-meta-item">
                                <span class="label">Carrera:</span>
                                <span class="value"><?= htmlspecialchars($prac['Carrera']) ?></span>
                            </div>
                            <div class="project-meta-item">
                                <span class="label">Estatus:</span>
                                <span class="value"><?= htmlspecialchars($prac['Estatus']) ?></span>
                            </div>
                            <div class="project-meta-item">
                                <span class="label">Integrantes:</span>
                                <span class="value"><?= htmlspecialchars($prac['Integrantes']) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div> 
<?php 
return;
else:?>

<div class="modern-projects-layout">
    <div class="projects-header">
        <h1>Tus Proyectos</h1>
        <p class="subtitle">Administra tus prácticas profesionales creadas</p>
    </div>
    
    <?php
        $correo = session()->get('correo'); 
        $userProjects = [];
        
        foreach ($practica as $prac) {
            $id = $prac['ID'];
            $nombre = $prac['Carrera'];
            $fase = $prac['Fase'];
            $imgPath = base_url('imagenes/' . $id . '-' . $nombre .'.jpg');
            $imgFile = FCPATH . 'imagenes/' . $id . '-' . $nombre . '.jpg';
            $hasImage = file_exists($imgFile);
            
            if ($fase == 2 && $correo == $prac['Autor']) {
                $userProjects[] = [
                    'data' => $prac,
                    'hasImage' => $hasImage,
                    'imgPath' => $imgPath
                ];
            }
        }
    ?>
    
    <?php if (empty($userProjects)): ?>
        <div class="no-projects-modern">
            <div class="icon">📋</div>
            <h3>No tienes proyectos creados</h3>
            <p>Aún no has creado ninguna práctica profesional. Comienza creando tu primer proyecto.</p>
            <button class="btn btn-primary" onclick="loadContent('formulario')">
                Crear Proyecto
            </button>
        </div>
    <?php else: ?>
        <div class="modern-projects-grid">
            <?php foreach ($userProjects as $project): ?>
                <?php $prac = $project['data']; ?>
                <div class="modern-project-card" onclick="loadPractica('<?= $prac['ID'] ?>')">
                    <div class="project-card-header">
                        <?php if ($project['hasImage']): ?>
                            <img src="<?= $project['imgPath'] . '?v=' . time() ?>" alt="<?= htmlspecialchars($prac['Titulo']) ?>" class="project-card-image">
                        <?php else: ?>
                            <div class="project-card-image-placeholder">
                                Sin imagen<br>disponible
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="project-card-content">
                        <h3 class="project-card-title"><?= htmlspecialchars($prac['Titulo']) ?></h3>
                        <div class="project-card-meta">
                            <div class="project-meta-item">
                                <span class="label">Carrera:</span>
                                <span class="value"><?= htmlspecialchars($prac['Carrera']) ?></span>
                            </div>
                            <div class="project-meta-item">
                                <span class="label">Estatus:</span>
                                <span class="value"><?= htmlspecialchars($prac['Estatus']) ?></span>
                            </div>
                            <div class="project-meta-item">
                                <span class="label">Integrantes:</span>
                                <span class="value"><?= htmlspecialchars($prac['Integrantes']) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php endif;?>
