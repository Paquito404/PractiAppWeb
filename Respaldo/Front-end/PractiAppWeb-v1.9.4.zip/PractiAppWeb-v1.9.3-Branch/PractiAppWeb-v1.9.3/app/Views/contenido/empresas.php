<?php 
$tipo = session()->get('tipo');
$departamento = session()->get('departamento'); 
?>

<div class="modern-projects-layout">
    <div class="projects-header">
        <h1>Administra las empresas registradas</h1>
    </div>
    
    <?php 
    $hasCompanies = false;
    $empresasList = [];
    
    foreach($empresa as $emp):
        $imgPath = base_url('empresas/' . $emp['ID'] . '-' . $emp['correo'] .'.jpg');
        $imgFile = FCPATH . 'empresas/' . $emp['ID'] . '-' . $emp['correo'] .'.jpg';
        $hasImage = file_exists($imgFile);
        
        // Mostrar empresas según tipo de usuario
        $shouldShow = false;
        if($tipo == 'moderador') {
            // Moderadores ven revisión y aprobadas
            if($emp['Fase'] == 1) {
                $shouldShow = true;
            }
        } elseif($departamento == $emp['departamento']) {
            $shouldShow = true;
        }
        
        if(!$shouldShow) continue;
        $hasCompanies = true;
        
        // Determinar el estado
        $estado = $emp['Fase'];

        $empresasList[] = [
            'data' => $emp,
            'hasImage' => $hasImage,
            'imgPath' => $imgPath,
            'estado' => $estado
        ];
    endforeach;
    ?>
    
    <?php if (!$hasCompanies): ?>
        <div class="no-projects-modern">
            <div class="icon">🏢</div>
            <h3>No hay empresas registradas</h3>
            <p>Actualmente no hay empresas pendientes de revisión o registradas en tu departamento.</p>
        </div>
    <?php else: ?>
        <div class="modern-projects-grid">
            <?php foreach($empresasList as $item): 
                $emp = $item['data'];
            ?>
                <div class="modern-project-card" onclick="loadEmpresa('<?= $emp['ID'] ?>')">
                    <div class="project-card-header">
                        <?php if ($item['hasImage']): ?>
                            <img src="<?= $item['imgPath'] . '?v=' . time() ?>" alt="Logo <?= htmlspecialchars($emp['nombre']) ?>" class="project-card-image">
                        <?php else: ?>
                            <div class="project-card-image-placeholder">
                                Sin imagen<br>disponible
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="project-card-content">
                        <h3 class="project-card-title"><?= htmlspecialchars($emp['nombre']) ?></h3>
                        <div class="project-card-meta">
                            <div class="project-meta-item">
                                <span class="label">RFC:</span>
                                <span class="value"><?= htmlspecialchars($emp['RFC']) ?></span>
                            </div>
                            <div class="project-meta-item">
                                <span class="label">Estatus:</span>
                                <span class="value"><?= htmlspecialchars($item['estado']) ?></span>
                            </div>
                            <div class="project-meta-item">
                                <span class="label">Departamento:</span>
                                <span class="value"><?= htmlspecialchars($emp['departamento']) ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
