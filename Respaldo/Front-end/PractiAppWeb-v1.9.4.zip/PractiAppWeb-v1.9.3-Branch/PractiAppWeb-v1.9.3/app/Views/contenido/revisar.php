<?php
    $depart = session()->get('departamento');
    $tipo = session()->get('tipo');
?>

<div class="content-wrapper">
    <section class="projects-container">
        <?php 
        $hasProjects = false;
        foreach ($practica as $prac):
            $id = $prac['ID'];
            $nombre = $prac['Carrera'];
            $fase = $prac['Fase'];
            $imgPath = base_url('imagenes/' . $id . '-' . $nombre .'.jpg');
            $imgFile = FCPATH . 'imagenes/' . $id . '-' . $nombre . '.jpg';
            $hasImage = file_exists($imgFile);
            
            // Filtrar por fase 1 y departamento
            if ($fase != 1) continue;
            if ($tipo != 'moderador' && $prac['Departamento'] != $depart) continue;
            
            $hasProjects = true;
        ?>
            <div class="enrolled-project-card" 
                 onclick="selectReviewProject(this)"
                 data-id="<?= $id ?>"
                 data-titulo="<?= htmlspecialchars($prac['Titulo']) ?>"
                 data-carrera="<?= htmlspecialchars($prac['Carrera']) ?>"
                 data-estado="<?= htmlspecialchars($prac['Estatus']) ?>"
                 data-integrantes="<?= htmlspecialchars($prac['Integrantes']) ?>"
                 data-img="<?= $hasImage ? ($imgPath . '?v=' . time()) : '' ?>">
                <div class="enrolled-project-info">
                    <h3 class="enrolled-project-title"><?= htmlspecialchars($prac['Titulo']) ?></h3>
                    <div class="enrolled-project-details">
                        <p class="enrolled-project-field"><strong>Carrera:</strong> <?= htmlspecialchars($prac['Carrera']) ?></p>
                        <p class="enrolled-project-field"><strong>Estado:</strong> <?= htmlspecialchars($prac['Estatus']) ?></p>
                        <p class="enrolled-project-field"><strong>Integrantes:</strong> <?= htmlspecialchars($prac['Integrantes']) ?></p>
                    </div>
                </div>
                <div class="enrolled-project-image <?= $hasImage ? '' : 'placeholder' ?>">
                    <?php if ($hasImage): ?>
                        <img src="<?= $imgPath . '?v=' . time() ?>" alt="Imagen <?= $id ?>">
                    <?php else: ?>
                        <span>Sin imagen disponible</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if (!$hasProjects): ?>
            <div class="no-projects">
                <h3>No hay prácticas en revisión</h3>
                <p>Actualmente no hay prácticas pendientes de revisión.</p>
            </div>
        <?php endif; ?>
    </section>

    <aside class="selected-project" id="revDetailPanel">
        <div class="placeholder-text">
            <p>Selecciona un proyecto para revisar</p>
        </div>
    </aside>
</div>


