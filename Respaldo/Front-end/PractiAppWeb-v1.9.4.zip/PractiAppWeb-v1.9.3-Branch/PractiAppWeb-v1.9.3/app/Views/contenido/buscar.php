<?php 
$departamento_usuario = session()->get('departamento');
$tipo = session()->get('tipo');
?>

<div class="modern-projects-layout">
    <div class="projects-header">
        <h1>Base de Datos</h1>
        <p class="subtitle">Explora todas las prácticas profesionales disponibles</p>
    </div>

    <div class="formulario-content" style="grid-template-columns: 1fr; gap: 1rem; align-items: stretch; margin-bottom: 1rem; overflow: visible;">
        <div class="form-group full-width">
            <label for="buscador">Buscar</label>
            <input class="form-control" type="text" id="buscador" placeholder="Buscar por nombre..." onkeyup="filtrarFilas()">
        </div>
        <div class="form-grid" style="grid-template-columns: repeat(4, 1fr);">
            <div class="form-group">
                <label for="filtro-estatus">Estatus</label>
                <select class="form-control" id="filtro-estatus">
                    <option value="">Todos</option>
                    <option value="Activo">Activo</option>
                    <option value="Inactivo">Inactivo</option>
                </select>
            </div>
            <div class="form-group">
                <label for="filtro-fecha">Ordenar por fecha</label>
                <select class="form-control" id="filtro-fecha">
                    <option value="">Sin ordenar</option>
                    <option value="asc">Más viejos</option>
                    <option value="desc">Más nuevos</option>
                </select>
            </div>
            <div class="form-group">
                <label for="filtro-carrera">Carrera</label>
                <select class="form-control" id="filtro-carrera">
                    <option value="">Todas</option>
                    <?php if ($tipo != 'moderador'): ?>
                        <?php foreach ($carrera as $car): ?>
                            <?php if ($car['Departamento'] == $departamento_usuario): ?>
                                <option value="<?= htmlspecialchars($car['nombre']) ?>"><?= htmlspecialchars($car['nombre']) ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>    
                    <?php else: ?>
                        <?php foreach ($carrera as $car): ?>
                            <option value="<?= htmlspecialchars($car['nombre']) ?>"><?= htmlspecialchars($car['nombre']) ?></option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="filtro-integrantes">Integrantes</label>
                <select class="form-control" id="filtro-integrantes">
                    <option value="">Todos</option>
                    <option value="0">0 integrantes</option>
                    <option value="1">1 o más</option>
                </select>
            </div>
        </div>
    </div>
    <div class="form-actions" style="justify-content: flex-end; margin-bottom: 1.5rem; border-top: none; padding-top: 0;">
        <button class="btn btn-secondary" onclick="restaurarFiltros()">Restaurar</button>
        <button class="btn btn-primary" onclick="aplicarFiltros()">Aplicar filtros</button>
    </div>

    <div class="db-projects-grid" id="resultado-filtro">
        <?php if ($tipo != 'moderador'): ?>
            <?php foreach ($practica as $prac): ?>
                <?php if ($prac['Departamento'] == $departamento_usuario): ?>
                    <div class="enrolled-project-card" onclick="loadPractica('<?= $prac['ID'] ?>')">
                        <div class="enrolled-project-info">
                            <h3 class="enrolled-project-title"><?= htmlspecialchars($prac['Titulo']) ?></h3>
                            <div class="enrolled-project-details">
                                <p class="enrolled-project-field"><strong>ID:</strong> <?= htmlspecialchars($prac['ID']) ?></p>
                                <p class="enrolled-project-field"><strong>Carrera:</strong> <?= htmlspecialchars($prac['Carrera']) ?></p>
                                <p class="enrolled-project-field"><strong>Estado:</strong> <?= htmlspecialchars($prac['Estatus']) ?></p>
                                <p class="enrolled-project-field"><strong>Integrantes:</strong> <?= htmlspecialchars($prac['Integrantes']) ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>    
        <?php else: ?>
            <?php foreach ($practica as $prac): ?>
                <div class="enrolled-project-card" onclick="loadPractica('<?= $prac['ID'] ?>')">
                    <div class="enrolled-project-info">
                        <h3 class="enrolled-project-title"><?= htmlspecialchars($prac['Titulo']) ?></h3>
                        <div class="enrolled-project-details">
                            <p class="enrolled-project-field"><strong>ID:</strong> <?= htmlspecialchars($prac['ID']) ?></p>
                            <p class="enrolled-project-field"><strong>Carrera:</strong> <?= htmlspecialchars($prac['Carrera']) ?></p>
                            <p class="enrolled-project-field"><strong>Estado:</strong> <?= htmlspecialchars($prac['Estatus']) ?></p>
                            <p class="enrolled-project-field"><strong>Integrantes:</strong> <?= htmlspecialchars($prac['Integrantes']) ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
