<?php  
    use App\Models\AlumnoModel;
    use App\Models\EscuelaModel;
    $alumnoModel = new AlumnoModel();
    $escuelaModel = new EscuelaModel();

    $usuario_id = session()->get('usuario_id');
    $alumno = $alumnoModel->find($usuario_id);
    $ID_Practica = $alumno['ID_Practica'];
    $practica = $escuelaModel->find($ID_Practica);
?>

<?php if($ID_Practica == NULL):?>
    <div class="modern-projects-layout">
        <div class="projects-header">
            <h1>Tus Proyectos</h1>
        </div>
        <div class="no-projects-modern">
            <div class="icon">📚</div>
            <h3>No tienes una práctica asignada</h3>
            <p>Por el momento no formas parte de ninguna práctica profesional. Explora los proyectos disponibles.</p>
            <button class="btn btn-primary" onclick="loadContent('inicio')">
                Ver Prácticas Disponibles
            </button>
        </div>
    </div>
<?php else:?>
    <?php
        $imagenPath = base_url('imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg');
        $imagenArchivo = FCPATH . 'imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg';
        
        // Determinar estado del alumno
        $estadoTexto = '';
        $estadoIcono = '';
        switch($alumno['Fase']){
            case 2:
                $estadoTexto = 'Postulado para la práctica';
                $estadoIcono = '⏳';
                break;
            case 3:
                $estadoTexto = 'Parte del proyecto';
                $estadoIcono = '✅';
                break;
        }
    ?>

    <div class="project-detail-container">
        <div class="project-detail-card">
            <?php if($estadoTexto): ?>
                <div style="background: var(--card-background); padding: 1rem; border-radius: var(--border-radius); margin-bottom: 1rem; text-align: center;">
                    <h3 style="color: var(--primary-color); margin: 0;">
                        <span style="font-size: 1.5rem; margin-right: 0.5rem;"><?= $estadoIcono ?></span>
                        Estatus: <?= $estadoTexto ?>
                    </h3>
                </div>
            <?php endif; ?>

            <div class="project-detail-grid">
                <div class="project-image-container">
                    <?php if (file_exists($imagenArchivo)): ?>
                        <img src="<?= $imagenPath . '?v=' . time() ?>" alt="Imagen de la práctica" class="project-detail-image">
                    <?php else: ?>
                        <div class="project-detail-image placeholder">
                            <span>Sin imagen disponible</span>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="project-info-container">
                    <?php if (isset($practica)): ?>
                        <h2 class="project-detail-title"><?= htmlspecialchars($practica['Titulo']) ?></h2>
                        
                        <div class="project-detail-info">
                            <div class="info-group">
                                <label>Descripción</label>
                                <p>Proyecto de <?= htmlspecialchars($practica['Carrera']) ?>.</p>
                            </div>

                            <div class="info-row">
                                <div class="info-group">
                                    <label>ID del Proyecto</label>
                                    <p><?= htmlspecialchars($practica['ID']) ?></p>
                                </div>
                                <div class="info-group">
                                    <label>Carrera</label>
                                    <p><?= htmlspecialchars($practica['Carrera']) ?></p>
                                </div>
                            </div>

                            <div class="info-row">
                                <div class="info-group">
                                    <label>Requisitos</label>
                                    <p><?= htmlspecialchars($practica['Requisitos']) ?> semestre(s) o más</p>
                                </div>
                                <div class="info-group">
                                    <label>Número de vacantes</label>
                                    <p><?= htmlspecialchars($practica['Integrantes']) ?></p>
                                </div>
                            </div>

                            <div class="info-row">
                                <div class="info-group">
                                    <label>Apoyo económico</label>
                                    <p>$<?= htmlspecialchars($practica['Pago']) ?></p>
                                </div>
                                <div class="info-group">
                                    <label>Estado</label>
                                    <p><?= htmlspecialchars($practica['Estatus']) ?></p>
                                </div>
                            </div>

                            <div class="info-group">
                                <label>Horario</label>
                                <p><?= substr(htmlspecialchars($practica['HorarioInicio']), 0, 5) ?> a <?= substr(htmlspecialchars($practica['HorarioFinal']), 0, 5) ?></p>
                            </div>

                            <div class="info-row">
                                <div class="info-group">
                                    <label>Registro</label>
                                    <p><?= htmlspecialchars($practica['FechaRegistroInicio']) ?> a <?= htmlspecialchars($practica['FechaRegistroFinal']) ?></p>
                                </div>
                                <div class="info-group">
                                    <label>Período de Actividad</label>
                                    <p><?= htmlspecialchars($practica['FechaActividadInicio']) ?> a <?= htmlspecialchars($practica['FechaActividadFinal']) ?></p>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <p>No se encontraron datos para esta práctica.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="button-container">
                <button class="btn btn-primary" onclick="loadContent('inicio')">Volver a Proyectos Disponibles</button>
            </div>
        </div>
    </div>
<?php endif;?>
