<?php 
$departamento = session()->get('departamento');
$tipo = session()->get('tipo');
?>

<div class="formulario-container">
    <div class="formulario-header">
        <h1>Editar Práctica <?= $practica['ID'] ?></h1>
        <p class="formulario-subtitle">Actualiza los campos necesarios del proyecto</p>
        <?php if ($practica['Postulados'] > 0): ?>
            <p style="color: var(--warning-color); font-size: 0.9rem; margin-top: 0.5rem;">
                ⚠️ Algunos campos no se pueden modificar porque ya hay estudiantes postulados
            </p>
        <?php endif; ?>
    </div>

    <form method="POST" id="formEditar" autocomplete="off" enctype="multipart/form-data" data-practica-id="<?= $practica['ID'] ?>">
        <div class="formulario-content">
            <div class="formulario-left">
                <div class="image-upload-section">
                    <label for="imagen" class="image-upload-area" id="imageUploadArea">
                        <div class="upload-placeholder" style="<?= $practica['Imagen'] ? 'display:none;' : '' ?>">
                            <div class="upload-icon">📁</div>
                            <p>Sube una imagen</p>
                        </div>
                        <img id="vistaPrevia" src="<?= $practica['Imagen'] ? base_url('imagenes/' . $practica['Imagen']) . '?v=' . time() : '#' ?>" alt="Vista previa" style="<?= $practica['Imagen'] ? '' : 'display:none;' ?> width:100%; height:100%; object-fit:cover;">
                    </label>
                    <input type="file" id="imagen" name="imagen" accept="image/jpeg" style="display:none">
                </div>
            </div>

            <div class="formulario-right">
                <div class="form-grid">
                    <div class="form-group half-width">
                        <label for="Titulo">Título</label>
                        <input class="form-control" type="text" name="Titulo" id="Titulo" value="<?= htmlspecialchars($practica['Titulo']) ?>" required>
                    </div>
                    
                    <?php if ($practica['Postulados'] == 0): ?>
                        <div class="form-group">
                            <label for="Carrera">Carrera</label>
                            <select class="form-control" name="Carrera" id="Carrera" required>
                                <option value="">Seleccionar</option>
                                <?php if ($tipo != 'moderador'): ?>
                                    <?php foreach ($carrera as $car): ?>
                                        <?php if ($car['Departamento'] == $departamento): ?>
                                            <option value="<?= htmlspecialchars($car['nombre']) ?>" <?= $practica['Carrera'] == $car['nombre'] ? 'selected' : '' ?>><?= htmlspecialchars($car['nombre']) ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; ?>    
                                <?php else: ?>
                                    <?php foreach ($carrera as $car): ?>
                                        <option value="<?= htmlspecialchars($car['nombre']) ?>" <?= $practica['Carrera'] == $car['nombre'] ? 'selected' : '' ?>><?= htmlspecialchars($car['nombre']) ?></option>
                                    <?php endforeach; ?> 
                                <?php endif; ?>
                            </select>
                        </div>
                    <?php else: ?>
                        <div class="form-group">
                            <label for="Carrera">Carrera</label>
                            <input class="form-control" type="text" value="<?= htmlspecialchars($practica['Carrera']) ?>" disabled>
                            <input type="hidden" name="Carrera" value="<?= htmlspecialchars($practica['Carrera']) ?>">
                        </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="Requisitos">Requisitos (semestre)</label>
                        <input class="form-control" type="number" name="Requisitos" id="Requisitos" value="<?= htmlspecialchars($practica['Requisitos']) ?>" required>
                    </div>
                    
                    <?php if ($practica['Postulados'] == 0): ?>
                        <div class="form-group">
                            <label for="Integrantes">Vacantes</label>
                            <input class="form-control" type="number" name="Integrantes" id="Integrantes" value="<?= htmlspecialchars($practica['Integrantes']) ?>" required>
                        </div>
                    <?php else: ?>
                        <div class="form-group">
                            <label for="Integrantes">Vacantes</label>
                            <input class="form-control" type="number" value="<?= htmlspecialchars($practica['Integrantes']) ?>" disabled>
                            <input type="hidden" name="Integrantes" value="<?= htmlspecialchars($practica['Integrantes']) ?>">
                        </div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="Pago">Apoyo económico</label>
                        <input class="form-control" type="number" name="Pago" id="Pago" value="<?= htmlspecialchars($practica['Pago']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="FechaRegistroInicio">Inicio</label>
                        <input class="form-control" type="date" name="FechaRegistroInicio" id="FechaRegistroInicio" value="<?= $practica['FechaRegistroInicio'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="FechaRegistroFinal">Fin</label>
                        <input class="form-control" type="date" name="FechaRegistroFinal" id="FechaRegistroFinal" value="<?= $practica['FechaRegistroFinal'] ?>" required>
                    </div>
                    
                    <?php if ($practica['Postulados'] == 0): ?>
                        <div class="form-group">
                            <label for="Estatus">Estatus</label>
                            <select class="form-control" name="Estatus" id="Estatus" required>
                                <option value="">Seleccionar</option>
                                <option value="Activo" <?= $practica['Estatus'] == 'Activo' ? 'selected' : '' ?>>Activo</option>
                                <option value="Inactivo" <?= $practica['Estatus'] == 'Inactivo' ? 'selected' : '' ?>>Inactivo</option>
                            </select>
                        </div>
                    <?php else: ?>
                        <div class="form-group">
                            <label for="Estatus">Estatus</label>
                            <input class="form-control" type="text" value="<?= htmlspecialchars($practica['Estatus']) ?>" disabled>
                            <input type="hidden" name="Estatus" value="<?= htmlspecialchars($practica['Estatus']) ?>">
                        </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label for="FechaActividadInicio">Período de actividad (inicio)</label>
                        <input class="form-control" type="date" name="FechaActividadInicio" id="FechaActividadInicio" value="<?= $practica['FechaActividadInicio'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="FechaActividadFinal">Período de actividad (fin)</label>
                        <input class="form-control" type="date" name="FechaActividadFinal" id="FechaActividadFinal" value="<?= $practica['FechaActividadFinal'] ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="HorarioInicio">Horario (inicio)</label>
                        <input class="form-control" type="time" name="HorarioInicio" id="HorarioInicio" value="<?= $practica['HorarioInicio'] ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="HorarioFinal">Horario (fin)</label>
                        <input class="form-control" type="time" name="HorarioFinal" id="HorarioFinal" value="<?= $practica['HorarioFinal'] ?>" required>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="button" class="btn btn-secondary" onclick="loadPractica(<?= $practica['ID'] ?>)">Cancelar</button>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </div>
    </form>
</div>

