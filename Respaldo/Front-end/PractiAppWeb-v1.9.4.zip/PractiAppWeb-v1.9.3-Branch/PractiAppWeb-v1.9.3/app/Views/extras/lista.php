<?php
    $correo = session()->get('correo');
    $imagenPath = base_url('imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg');
    $imagenArchivo = FCPATH . 'imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg';
?>

<div class="project-detail-container">
    <div class="project-detail-card">
        <div class="project-detail-grid">
            <div class="project-image-container">
                <?php if (file_exists($imagenArchivo)): ?>
                    <img src="<?= $imagenPath . '?v=' . time() ?>" alt="Imagen de la práctica" class="project-detail-image">
                <?php else: ?>
                    <div class="project-detail-image placeholder">
                        <span>Sin imagen disponible</span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="project-info-container">
                <?php if (isset($practica)): ?>
                    <h2 class="project-detail-title"><?= htmlspecialchars($practica['Titulo']) ?></h2>
                    
                    <div class="project-detail-info">
                        <div class="info-group">
                            <label>Descripción</label>
                            <p>Proyecto de <?= htmlspecialchars($practica['Carrera']) ?>.</p>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>ID del Proyecto</label>
                                <p><?= htmlspecialchars($practica['ID']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Carrera</label>
                                <p><?= htmlspecialchars($practica['Carrera']) ?></p>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Requisitos</label>
                                <p><?= htmlspecialchars($practica['Requisitos']) ?> semestre(s) o más</p>
                            </div>
                            <div class="info-group">
                                <label>Número de vacantes</label>
                                <p><?= htmlspecialchars($practica['Integrantes']) ?></p>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Apoyo económico</label>
                                <p>$<?= htmlspecialchars($practica['Pago']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Estado</label>
                                <p><?= htmlspecialchars($practica['Estatus']) ?></p>
                            </div>
                        </div>

                        <div class="info-group">
                            <label>Horario</label>
                            <p><?= substr(htmlspecialchars($practica['HorarioInicio']), 0, 5) ?> a <?= substr(htmlspecialchars($practica['HorarioFinal']), 0, 5) ?></p>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Registro</label>
                                <p><?= htmlspecialchars($practica['FechaRegistroInicio']) ?> a <?= htmlspecialchars($practica['FechaRegistroFinal']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Período de actividad</label>
                                <p><?= htmlspecialchars($practica['FechaActividadInicio']) ?> a <?= htmlspecialchars($practica['FechaActividadFinal']) ?></p>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <p>No se encontraron datos para esta práctica.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="button-container">
            <?php if ($correo == $practica['Autor']): ?>
                <?php if ($practica['Estatus'] == 'Activo'): ?>
                    <button class="btn btn-secondary" onclick="estudiantes(<?= $practica['ID'] ?>)">Estudiantes</button>
                    <?php if ($practica['Integrantes'] > 0): ?>
                        <button class="btn btn-secondary" onclick="postulados(<?= $practica['ID'] ?>)">Postulados</button>
                    <?php endif; ?>
                <?php endif; ?>
                <button class="btn btn-secondary" onclick="editarPractica(<?= $practica['ID'] ?>)">Editar</button>
                <button class="btn btn-secondary" onclick="papelera(<?= $practica['ID'] ?>)">Eliminar</button>
            <?php else: ?>
                <button class="btn btn-primary" type="button" onclick="confirmarEliminacionPractica()">Eliminar definitivamente</button>
            <?php endif; ?>
            <button class="btn btn-primary" onclick="loadContent('inicio')">Regresar</button>
        </div>
    </div>
</div>

<?php if ($correo != $practica['Autor']): ?>
<!-- Modern Modal for project deletion with comment -->
<div class="modal fade bootstrap-modal" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="commentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content modern-modal">
            <form id="formEliminacionPractica" action="<?= site_url('home/sendCommentP') ?>" method="post">
                <input type="hidden" name="id" value="<?= $practica['ID'] ?>">
                <div class="modal-header modern-modal-header">
                    <div class="modal-icon-wrapper">
                        <span class="modal-icon warning">⚠️</span>
                    </div>
                    <h5 class="modal-title modern-modal-title" id="commentModalLabel">Motivo de Eliminación</h5>
                </div>
                <div class="modal-body modern-modal-body">
                    <p class="modal-description">Ingrese el motivo para eliminar este proyecto. Se notificará al creador por correo.</p>
                    <div class="input-group-modern">
                        <label for="comment" class="modern-label">Motivo de eliminación</label>
                        <textarea class="form-control modern-textarea" id="comment" name="comment" rows="5" placeholder="Describe el motivo..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer modern-modal-footer">
                    <button type="button" class="btn btn-secondary modern-btn-cancel" data-dismiss="modal">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary modern-btn-submit">
                        Enviar correo
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($correo != $practica['Autor']): ?>
<style>
/* Modal styles v2.0 - Updated button design */
.modern-modal { border: none; border-radius: 12px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15); overflow: hidden; }
.modern-modal-header { background: linear-gradient(135deg, #2675db 0%, #1e5bb8 100%); color: white; border: none; padding: 2rem 1.5rem 1.5rem; position: relative; text-align: center; }
.modal-icon-wrapper { margin-bottom: 0.5rem; }
.modal-icon { font-size: 3rem; display: inline-block; }
.modern-modal-title { font-size: 1.5rem; font-weight: 600; margin: 0; color: white; }
.modern-close { position: absolute; top: 1rem; right: 1rem; color: white; opacity: 0.8; font-size: 1.5rem; font-weight: 300; transition: opacity 0.2s; }
.modern-close:hover { opacity: 1; }
.modern-modal-body { padding: 2rem 1.5rem; background: #f8f9fa; }
.input-group-modern { text-align: left; width: 100%; display: block; }
.modal-description { color: #666666; font-size: 0.95rem; margin-bottom: 1.5rem; line-height: 1.6; text-align: center; }
.modern-label { font-weight: 600; color: #333333; margin-bottom: 0.5rem; display: block; width: 100%; }
.modern-textarea { border: 2px solid #e0e0e0; border-radius: 8px; padding: 0.75rem; font-size: 0.95rem; transition: all 0.3s ease; resize: vertical; width: 100% !important; display: block; }
.modern-textarea:focus { border-color: #2675db; box-shadow: 0 0 0 3px rgba(38, 117, 219, 0.1); outline: none; }
.modern-modal-footer { background: white; border-top: 1px solid #e9ecef; padding: 1rem 1.5rem; display: flex; gap: 0.75rem; justify-content: flex-end; }
.modern-modal-footer .modern-btn-cancel, .modern-modal-footer .modern-btn-submit { padding: 0.75rem 2rem !important; font-weight: 500 !important; border-radius: 25px !important; border: none !important; cursor: pointer; transition: all 0.3s ease; font-size: 1rem !important; min-width: 120px !important; }
.modern-modal-footer .modern-btn-cancel { background-color: #2675db !important; color: white !important; }
.modern-modal-footer .modern-btn-cancel:hover { background-color: #1e5bb8 !important; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(38, 117, 219, 0.3); }
.modern-modal-footer .modern-btn-submit { background-color: #2675db !important; color: white !important; }
.modern-modal-footer .modern-btn-submit:hover { background-color: #1e5bb8 !important; transform: translateY(-2px); box-shadow: 0 4px 16px rgba(38, 117, 219, 0.4); }
</style>


<script>
// Handle form submission to maintain database tab selection
$(document).ready(function() {
    $('#formEliminacionPractica').on('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        $('#commentModal').modal('hide');
        
        fetch('<?= site_url('home/sendCommentP') ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            showSuccess('Proyecto eliminado y notificación enviada');
            // Reload database tab content
            loadContent('buscar');
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Error al eliminar el proyecto');
        });
    });
});
</script>
<?php endif; ?>
