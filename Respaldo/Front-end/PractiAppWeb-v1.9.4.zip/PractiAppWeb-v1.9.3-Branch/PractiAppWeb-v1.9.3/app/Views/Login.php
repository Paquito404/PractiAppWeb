<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practicas profesionales Unison</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/css/styles.css') ?>">
    <style>
        html, body {
            overflow: auto !important;
            height: auto !important;
        }
        body {
            min-height: 100vh;
            margin: 0;
            padding: 0;
            padding-top: 80px; /* Override styles.css 140px, adjusted for login header */
            /* Background image with soft white fade overlay */
            background: linear-gradient(rgba(255, 255, 255, 0.85), rgba(255, 255, 255, 0.85)),
                        url('<?= base_url('assets/img/background.jpg') ?>');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        .main-container { min-height: 100vh; position: relative; display: flex; flex-direction: column; }
        
        /* Overrides for Header on Login Page */
        .header {
            height: auto; /* Allow auto height since we don't have nav tabs */
            min-height: 70px;
        }
        /* Center the login box vertically */
        .content-center {
            flex: 1; /* Take remaining space */
            display: flex;
            align-items: center; /* Center vertically if space allows */
            justify-content: center;
            padding: 2rem 1rem;
        }
        .login-container { width: 100%; max-width: 400px; margin: 0 auto; padding: 20px; }
        .login-box { background: white; border-radius: 8px; box-shadow: 0 0 20px rgba(0,0,0,0.1); padding: 30px; }
        .welcome-text { margin-bottom: 20px; color: #666; }
        .form-control { border-radius: 4px; padding: 10px; border: 1px solid #ddd; }
        .form-control:focus { border-color: #2675db; box-shadow: 0 0 0 0.2rem rgba(38, 117, 219, 0.25); }
        .btn-primary { background-color: #2675db; border-color: #2675db; padding: 10px; }
        .btn-primary:hover { background-color: #1565c0; border-color: #1565c0; }
        .microsoft-btn { background-color: #fff; border: 1px solid #ddd; padding: 10px 20px; border-radius: 4px; display: flex; align-items: center; justify-content: center; margin: 20px 0; text-decoration: none; color: #000; transition: all 0.3s ease; }
        .microsoft-btn:hover { background-color: #f8f9fa; border-color: #2675db; color: #2675db; }
        .microsoft-btn img { width: 20px; margin-right: 10px; }
        /* Info section flows naturally now */
        .info-section { position: relative; background: white; padding: 20px; border-top: 1px solid #dee2e6; width: 100%; }
        .info-section .row { max-width: 1200px; margin: 0 auto; }
        .info-list { list-style: none; padding: 0; }
        .info-list li { margin-bottom: 8px; color: #666; }
    </style>
    </head>
<body>
    <div class="main-container">
        <header class="header">
            <div class="header-content">
                <div class="logo">
                    <img src="<?= base_url('assets/img/logo.png') ?>" alt="Universidad de Sonora" class="logo-img">
                    <h1>Prácticas Profesionales Unison</h1>
                </div>
            </div>
        </header>

        <div class="content-center">
            <div class="login-container">
            <div class="login-box">
                <h2 class="text-center mb-3">Inicia Sesión</h2>
                <p class="welcome-text text-center">Bienvenido a tu página</p>

                <?php if(session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>

                <?php if(session()->getFlashdata('message')): ?>
                    <div class="alert alert-success">
                        <?= session()->getFlashdata('message') ?>
                    </div>
                <?php endif; ?>

                <?php if (session()->has('validation')): ?>
                    <div class="alert alert-danger">
                        <?= session()->get('validation')->listErrors() ?>
                    </div>
                <?php endif; ?>

                <form action="<?= base_url('login') ?>" method="post">
                    <div class="mb-3">
                        <label for="correo" class="form-label">Correo</label>
                        <input type="email" class="form-control" id="correo" name="correo" value="<?= old('correo') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Contraseña</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                        <div class="text-end mt-2">
                            <a href="<?= base_url('forgot-password') ?>" class="text-decoration-none">¿Olvidaste tu contraseña?</a>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Iniciar Sesión</button>
                </form>

                <a href="<?= base_url('microsoft-login') ?>" class="microsoft-btn">
                    <img src="<?= base_url('assets/img/logo.png') ?>" alt="Microsoft">
                    Usar IdenTidad Unison
                </a>

                <div class="text-center mt-3 pt-3 border-top">
                    <p class="mb-2">¿Eres una empresa?</p>
                    <a href="<?= base_url('form_empresa') ?>" class="btn btn-outline-primary w-100">Registrar Empresa</a>
                </div>
            </div>
            </div>
        </div>

        <div class="info-section">
            <div class="row">
                <div class="col-md-6">
                    <h3>Información para alumnos:</h3>
                    <ul class="info-list">
                        <li>Información 1</li>
                        <li>Información 2</li>
                        <li>Información 3</li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <h3>Información de unidades receptoras:</h3>
                    <ul class="info-list">
                        <li>Información 1</li>
                        <li>Información 2</li>
                        <li>Información 3</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>