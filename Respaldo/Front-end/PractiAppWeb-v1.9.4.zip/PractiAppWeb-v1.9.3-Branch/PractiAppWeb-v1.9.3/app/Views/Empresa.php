<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empresa - Prácticas Profesionales Unison</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url('assets/css/styles.css') ?>">
</head>
<body>
    <header class="header">
        <div class="header-content">
            <div class="logo">
                <img src="<?= base_url('assets/img/logo.png') ?>" alt="Universidad de Sonora" class="logo-img">
                <h1>Prácticas Profesionales Unison</h1>
            </div>
            <div class="profile-container">
                <img src="<?= base_url('empresas/' . session('usuario_id') . '-' . session('correo') . '.jpg') ?>" 
                     alt="Profile" class="profile-icon" id="profileIcon" 
                     onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIGZpbGw9IiNmZmYiIHZpZXdCb3g9IjAgMCAyNCAyNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTIgMTJjMi4yMSAwIDQtMS43OSA0LTRzLTEuNzktNC00LTQtNCAxLjc5LTQgNCAx'+
                     'Ljc5IDQgNCA0em0wIDJjLTIuNjcgMC04IDEuMzQtOCA0djJoMTZ2LTJjMC0yLjY2LTUuMzMtNC04LTR6Ii8+PC9zdmc+'">
                <div class="profile-dropdown" id="profileDropdown">
                    <div class="profile-content">
                        <div class="profile-image-container">
                            <img src="<?= base_url('empresas/' . session('usuario_id') . '-' . session('correo') . '.jpg') ?>" 
                                 alt="Profile" class="profile-picture"
                                 onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgZmlsbD0iIzY2NiIgdmlld0JveD0iMCAwIDI0IDI0IiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXRoIGQ9Ik0xMiAxMmMyLjIxIDAgNC0xLjc5IDQtNHMtMS43OS00LTQtNC00IDEuNzktNCA0IDEuNzkgNCA0IDR6bTAgMmMtMi42NyAwLTggMS4zNC04IDR2MmgxNnYtMmMwLTIuNjYtNS4zMy00LTgtNHoiLz48L3N2Zz4='">
                        </div>
                        <h3 class="profile-title">Empresa</h3>
                        <div class="profile-details">
                            <div class="profile-field">
                                <span class="profile-label">Nombre:</span>
                                <span class="profile-value"><?= session('nombre') ?? 'N/A' ?></span>
                            </div>
                            <div class="profile-field">
                                <span class="profile-label">Email:</span>
                                <span class="profile-value"><?= session('correo') ?></span>
                            </div>
                            <div class="profile-field">
                                <span class="profile-label">RFC:</span>
                                <span class="profile-value"><?= session('RFC') ?? 'N/A' ?></span>
                            </div>
                            <div class="profile-field">
                                <span class="profile-label">Departamento:</span>
                                <span class="profile-value"><?= session('departamento') ?? 'N/A' ?></span>
                            </div>
                            <div class="profile-field">
                                <span class="profile-label">ID:</span>
                                <span class="profile-value"><?= session('usuario_id') ?></span>
                            </div>
                        </div>
                        <div class="profile-footer">
                            <a href="<?= base_url('logout') ?>" class="logout-button">Cerrar Sesión</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <nav class="nav-tabs">
            <ul class="nav-list">
                <li class="nav-item"><a href="#" onclick="loadContent('inicio')" class="active">Tus proyectos</a></li>
                <li class="nav-item"><a href="#" onclick="loadContent('formulario')">Subir proyectos</a></li>
                <li class="nav-item"><a href="#" onclick="loadContent('papelera')">Papelera</a></li>
            </ul>
        </nav>
    </header>

    <main class="container">
        <div id="content"></div>
    </main>

    <!-- Scripts Bootstrap + jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    const baseUrl = "<?= base_url() ?>";
    const idUsuario = <?= session('usuario_id') ?? 'null' ?>;
    </script>
    <script src="<?= base_url('assets/js/script.js') ?>"></script>

    <?php include(APPPATH . 'Views/partials/notification_modal.php'); ?>

    <?php if (session()->has('success')): ?>
    <div data-flash-success="<?= esc(session()->getFlashdata('success')) ?>" style="display:none;"></div>
    <?php endif; ?>
</body>
</html>
