<?php

namespace App\Models;

use CodeIgniter\Model;

class EscuelaModel extends Model
{
    protected $table      = 'Practicas';

    protected $primaryKey = 'ID';
    protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['Titulo', 
                                'Requisitos',
                                'Carrera',
                                'Departamento', 
                                'Estatus', 
                                'Integrantes',
                                'Pago',
                                'HorarioInicio',
                                'HorarioFinal', 
                                'FechaRegistroInicio',
                                'FechaRegistroFinal',
                                'FechaActividadInicio',
                                'FechaActividadFinal',
                                'Fase', 
                                'Fecha', 
                                'Imagen', 
                                'Autor',
                                'Postulados'];

    protected bool $allowEmptyInserts = true;
    protected bool $updateOnlyChanged = true;
}