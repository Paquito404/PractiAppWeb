<?php
try {
    echo "PDO::SQLSRV_ATTR_ENCODING: " . PDO::SQLSRV_ATTR_ENCODING . "\n";
} catch (Error $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
