$env:PHPRC = 'e:\backup\Users\Joan Kniffin\Downloads\PractiAppWeb-v1.9.3\PractiAppWeb-v1.9.3\php.ini'
& 'C:\php-8.2.30\php.exe' spark serve
