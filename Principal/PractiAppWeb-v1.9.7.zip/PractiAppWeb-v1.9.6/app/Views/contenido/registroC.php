<div class="formulario-container">
    <div class="formulario-header">
        <h1>Registrar Coordinador</h1>
        <p class="formulario-subtitle">Completa el formulario para registrar un nuevo coordinador</p>
    </div>

    <form action="<?= base_url('registroC') ?>" method="post" autocomplete="off" enctype="multipart/form-data">
        <div class="formulario-content">
            <div class="formulario-left">
                <div class="image-upload-section">
                    <label for="imagen" class="image-upload-area" id="imageUploadArea">
                        <div class="upload-placeholder">
                            <div class="upload-icon">📁</div>
                            <p>Sube una imagen</p>
                        </div>
                        <img id="vistaPrevia" src="#" alt="Vista previa" style="display:none; width:100%; height:100%; object-fit:cover;">
                    </label>
                    <input type="file" id="imagen" name="imagen" accept="image/jpeg" style="display:none">
                </div>
            </div>

            <div class="formulario-right">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input class="form-control" type="text" name="nombre" id="nombre" maxlength="30" required>
                    </div>
                    <div class="form-group">
                        <label for="departamento">Departamento</label>
                        <select class="form-control" name="departamento" id="departamento" required>
                            <option value="">Seleccione una opción</option>
                            <?php foreach ($departamento as $depa): ?>
                                <option value="<?= htmlspecialchars($depa['nombre']) ?>"><?= htmlspecialchars($depa['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="correo">Correo</label>
                        <input class="form-control" type="email" name="correo" id="correo" maxlength="30" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Contraseña</label>
                        <input class="form-control" type="password" name="password" id="password" maxlength="30" required>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="button" class="btn btn-secondary" onclick="goBack()">Cancelar</button>
            <button type="submit" class="btn btn-primary">Registrar</button>
        </div>
    </form>
</div>


