<?php 
    $departamento = session()->get('departamento');
    $tipo = session()->get('tipo');
?>

<div class="formulario-container">
    <div class="formulario-header">
        <h1>Subir Proyecto</h1>
        <p class="formulario-subtitle">Completa el formulario para registrar una nueva práctica profesional</p>
    </div>

    <form action="<?php echo base_url('escuela')?>" method="post" autocomplete="off" enctype="multipart/form-data">
        <div class="formulario-content">
            <div class="formulario-left">
                <div class="image-upload-section">
                    <label for="imagen" class="image-upload-area" id="imageUploadArea">
                        <div class="upload-placeholder">
                            <div class="upload-icon">📁</div>
                            <p>Sube una imagen</p>
                        </div>
                        <img id="vistaPrevia" src="#" alt="Vista previa" style="display:none; width:100%; height:100%; object-fit:cover;">
                    </label>
                    <input type="file" id="imagen" name="imagen" accept="image/jpeg" style="display:none">
                </div>
            </div>

            <div class="formulario-right">
                <div class="form-grid">
                    <div class="form-group half-width">
                        <label for="Titulo">Título</label>
                        <input class="form-control" type="text" name="Titulo" id="Titulo" maxlength="99" required>
                    </div>
                    <div class="form-group">
                        <label for="Carrera">Carrera</label>
                        <select class="form-control" name="Carrera" id="Carrera" required>
                            <option value="">Seleccionar</option>
                            <?php if ($tipo != 'moderador'): ?>
                                <?php foreach ($carrera as $car): ?>
                                    <?php if ($car['Departamento'] == $departamento): ?>
                                        <option value="<?= htmlspecialchars($car['nombre']) ?>"><?= htmlspecialchars($car['nombre']) ?></option>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <?php foreach ($carrera as $car): ?>
                                    <option value="<?= htmlspecialchars($car['nombre']) ?>"><?= htmlspecialchars($car['nombre']) ?></option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="Requisitos">Requisitos (semestre)</label>
                        <input class="form-control" type="number" name="Requisitos" id="Requisitos" min="1" max="12" maxlength="2" data-maxdigits="2" required>
                    </div>
                    <div class="form-group">
                        <label for="Integrantes">Vacantes</label>
                        <input class="form-control" type="number" name="Integrantes" id="Integrantes" min="0" max="999" maxlength="3" data-maxdigits="3" required>
                    </div>
                    <div class="form-group">
                        <label for="Pago">Apoyo económico</label>
                        <input class="form-control" type="number" name="Pago" id="Pago" min="0" max="999999" maxlength="6" data-maxdigits="6" required>
                    </div>

                    <div class="form-group">
                        <label for="FechaRegistroInicio">Inicio</label>
                        <input class="form-control" type="date" name="FechaRegistroInicio" id="FechaRegistroInicio" required>
                    </div>
                    <div class="form-group">
                        <label for="FechaRegistroFinal">Fin</label>
                        <input class="form-control" type="date" name="FechaRegistroFinal" id="FechaRegistroFinal" required>
                    </div>
                    <div class="form-group">
                        <label for="Estatus">Estatus</label>
                        <select class="form-control" name="Estatus" id="Estatus" required>
                            <option value="">Seleccionar</option>
                            <option value="Activo">Activo</option>
                            <option value="Inactivo">Inactivo</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="FechaActividadInicio">Período de actividad (inicio)</label>
                        <input class="form-control" type="date" name="FechaActividadInicio" id="FechaActividadInicio" required>
                    </div>
                    <div class="form-group">
                        <label for="FechaActividadFinal">Período de actividad (fin)</label>
                        <input class="form-control" type="date" name="FechaActividadFinal" id="FechaActividadFinal" required>
                    </div>

                    <div class="form-group">
                        <label for="HorarioInicio">Horario (inicio)</label>
                        <input class="form-control" type="time" name="HorarioInicio" id="HorarioInicio" required>
                    </div>
                    <div class="form-group">
                        <label for="HorarioFinal">Horario (fin)</label>
                        <input class="form-control" type="time" name="HorarioFinal" id="HorarioFinal" required>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="button" class="btn btn-secondary" onclick="goBack()">Cancelar</button>
            <button type="submit" class="btn btn-primary">Registrar</button>
        </div>
    </form>
</div>
