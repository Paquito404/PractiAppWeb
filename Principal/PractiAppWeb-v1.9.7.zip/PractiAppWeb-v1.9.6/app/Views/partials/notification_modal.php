<!-- Global Notification Modal -->
<div id="global-modal-overlay" class="global-modal-overlay" style="display:none;">
    <div class="global-modal-box">
        <div class="global-modal-icon" id="global-modal-icon">✓</div>
        <p id="global-modal-message">Mensaje</p>
        <div id="global-modal-buttons" class="global-modal-buttons">
            <button class="btn btn-primary" onclick="closeGlobalModal()">Aceptar</button>
        </div>
    </div>
</div>

<style>
.global-modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10000;
}

.global-modal-box {
    background: white;
    padding: 2rem;
    border-radius: 8px;
    text-align: center;
    max-width: 400px;
    min-width: 300px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    animation: modalFadeIn 0.2s ease-out;
}

@keyframes modalFadeIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.global-modal-icon {
    font-size: 3rem;
    margin-bottom: 1rem;
}

.global-modal-icon.success {
    color: #4CAF50;
}

.global-modal-icon.error {
    color: #f44336;
}

.global-modal-icon.warning {
    color: #ff9800;
}

.global-modal-icon.info {
    color: #2196F3;
}

.global-modal-box p {
    margin-bottom: 1.5rem;
    font-size: 1rem;
    color: #333;
    line-height: 1.5;
}

.global-modal-buttons {
    display: flex;
    gap: 1rem;
    justify-content: center;
}

.global-modal-buttons .btn {
    min-width: 100px;
}
</style>

<script>
// Global notification system
window.NotificationModal = {
    overlay: null,
    icon: null,
    message: null,
    buttons: null,
    currentCallback: null,

    init: function() {
        this.overlay = document.getElementById('global-modal-overlay');
        this.icon = document.getElementById('global-modal-icon');
        this.message = document.getElementById('global-modal-message');
        this.buttons = document.getElementById('global-modal-buttons');
    },

    show: function(message, type = 'success', callback = null) {
        if (!this.overlay) this.init();
        
        this.message.textContent = message;
        this.currentCallback = callback;
        
        // Set icon based on type
        const icons = {
            success: '✓',
            error: '✕',
            warning: '⚠️',
            info: 'ℹ️'
        };
        
        this.icon.textContent = icons[type] || icons.success;
        this.icon.className = 'global-modal-icon ' + type;
        
        // Single button for non-confirm modals
        this.buttons.innerHTML = '<button class="btn btn-primary" onclick="NotificationModal.handleConfirm()">Aceptar</button>';
        
        this.overlay.style.display = 'flex';
    },

    confirm: function(message, onConfirm, onCancel = null) {
        if (!this.overlay) this.init();
        
        this.message.textContent = message;
        this.icon.textContent = '?';
        this.icon.className = 'global-modal-icon info';
        
        // Two buttons for confirm
        this.buttons.innerHTML = `
            <button class="btn btn-secondary" onclick="NotificationModal.handleCancel()">Cancelar</button>
            <button class="btn btn-primary" onclick="NotificationModal.handleConfirm()">Confirmar</button>
        `;
        
        this.currentCallback = onConfirm;
        this.cancelCallback = onCancel;
        
        this.overlay.style.display = 'flex';
    },

    handleConfirm: function() {
        const callback = this.currentCallback; // Capture callback before close clears it
        this.close();
        if (callback) callback();
    },

    handleCancel: function() {
        this.close();
        if (this.cancelCallback) this.cancelCallback();
    },

    close: function() {
        if (this.overlay) {
            this.overlay.style.display = 'none';
        }
        this.currentCallback = null;
        this.cancelCallback = null;
    }
};

// Convenient global functions
function closeGlobalModal() {
    NotificationModal.close();
}

function showSuccess(message, callback) {
    NotificationModal.show(message, 'success', callback);
}

function showError(message, callback) {
    NotificationModal.show(message, 'error', callback);
}

function showWarning(message, callback) {
    NotificationModal.show(message, 'warning', callback);
}

function showInfo(message, callback) {
    NotificationModal.show(message, 'info', callback);
}

function showConfirm(message, onConfirm, onCancel) {
    NotificationModal.confirm(message, onConfirm, onCancel);
}

// Auto-show flash messages if present
document.addEventListener('DOMContentLoaded', function() {
    const flashSuccess = document.querySelector('[data-flash-success]');
    const flashError = document.querySelector('[data-flash-error]');
    
    if (flashSuccess) {
        showSuccess(flashSuccess.getAttribute('data-flash-success'));
    } else if (flashError) {
        showError(flashError.getAttribute('data-flash-error'));
    }
});
</script>

<script>

window.rejectSelected = function() {
   var btn = document.getElementById('revRejectBtn');
   if (!btn || !btn.dataset.id || btn.disabled) return;
   var id = btn.dataset.id

   function setButtons(disabled) {
	document.querySelectorAll('#revDetailPanel button').forEach(function (b) {
	   b.disabled = disabled;
	   b.style.pointerEvents = disabled ? 'none' : '';
	});
   }

   showConfirm('¿Estas seguro de que deseas rechazar el proyecto?', function () {
	setButtons(true);

	var fd = new FormData();
	fd.append('id', id);

	fetch(baseUrl + 'home/sendCommentP', {
	   method: 'POST',
	   body: fd
	})
	.then(function (response) {
	   if (!response.ok) throw new Error('Error al rechazar la practica');
	   return response.text();
	})
	.then(function () {
	   showSuccess('Proyecto rechazado', function () {
		loadContent('revisar');
	   });
	})
	.catch(function (error) {
	   console.error('Error:', error);
	   setButtons(false);
	   showError('Error al rechazar la practica');
	});
   });
};
</script>

<script>

window.confirmarEliminacionPractica = function () {
   var input = document.querySelector('#formEliminacionPractica input[name="id"]');
   if(!input || !input.value) return;
   var id = input.value;

   function setButtons(disabled) {
	document.querySelectorAll('.button-container button').forEach(function (b) {
	   b.disabled = disabled;
	   b.style.pointerEvents = disabled ? 'none' : '';
	});
   }

   showConfirm('¿Estas seguro de que quieres eliminar el proyecto?', function () {
	setButtons(true);

	var fd = new FormData();
	fd.append('id', id);

	fetch(baseUrl + 'home/sendCommentP', {
	   method: 'POST',
	   body: fd
	})
	.then(function (response) {
	   if(!response.ok) throw new Error('Error al eliminar la practica');
	   return response.text();
	})
	.then(function () {
	   showSuccess('Practica eliminada con exito', function () {
		loadContent('buscar');
	   });
	})
	.catch(function (error) {
	   console.error('Error:', error);
	   setButtons(false);
	   showError('Error al eliminar la practica')
	});
   });
};

</script>

<script>

function bloquearAcciones(disabled) {
   document.querySelectorAll('#content button, #content a.btn').forEach(function (b) {
	b.disabled = disabled;
	b.style.pointerEvents = disabled ? 'none' : '';
   });
}

function ejecutarRechazoSimple(opts) {
   showConfirm(opts.confirmMsg, function () {
	bloquearAcciones(true);

	var fd = new FormData();
	fd.append('id', opts.id);

	fetch(baseUrl + opts.endpoint, { method: 'POST', body: fd })
	.then(function (response) {
	   if(!response.ok) throw new Error('Error al rechazar al usuario');
	   return response.text();
	})
	.then(function () {
	   showSuccess(opts.okMsg, function () {
		loadContent(opts.page);
	   });
	})
	.catch(function (error) {
	   console.error('Error:', error);
	   bloquearAcciones(false);
	   showError(opts.errMsg);
	});
   });
}

function idAlumnoDeVista() {
   var inp = document.querySelector('#commentModal input[name="id"]');
   if (inp && inp.value) return inp.value;
   var btns = document.querySelectorAll('#content .button-container button[onclick]');
   for (var i = 0; i < btns.length; i++) {
	var m = btns[i].getAttribute('onclick').match(/aprobar\((\d+)\)/);
	if (m) return m[1];
   }
   return null;
}

window.rechazar = function (id) {
   ejecutarRechazoSimple({
	id: id,
	endpoint: 'home/sendCommentA',
	confirmMsg: '¿Estas seguro de que quieres rechazar al estudiante?',
	okMsg: 'Estudiante rechazado con exito',
	errMsg: 'Error al rechazar al estudiante',
	page: 'inicio'
   });
};

window.confirmarRechazo = function () {
   var id = idAlumnoDeVista();
   if (!id) return;
   ejecutarRechazoSimple({
	id: id,
	endpoint: 'home/sendCommentA',
	confirmMsg: '¿Estas seguro de que deseas rechazar el estudiante?',
	okMsg: 'Estudiante rechazado',
	errMsg: 'Error al rechazar al estudiante',
	page: 'inicio'
   });
};

window.confirmarEliminacion = function () {
   var id = idAlumnoDeVista();
   if (!id) return;
   ejecutarRechazoSimple({
	id: id,
	endpoint: 'home/sendCommentA',
	confirmMsg: '¿Estas seguro de que quieres eliminar al estudiante de la practica?',
	okMsg: 'Estudiante eliminado',
	errMsg: 'Error al eliminar al estudiante',
	page: 'inicio'
   });
};

window.prepararRechazoEmpresa = function (id) {
   ejecutarRechazoSimple({
	id: id,
	endpoint: 'home/sendCommentE',
	confirmMsg: '¿Estas seguro de que quieres rechazar la empresa?',
	okMsg: 'Empresa Rechazada con exito',
	errMsg: 'Error al rechazar la empresa',
	page:'empresas'
   });
};

</script>

<script>

window.aplicar = function (id) {
   var contentDiv = document.getElementById('content');

   showConfirm('¿Estas seguro de que quiere aplicar para esta practica?', function () {
	bloquearAcciones(true);

	fetch(baseUrl + 'aplicar/' + id)
	.then(function (response) {
	   if(!response.ok) throw new Error('Error al aplicar a la practica');
	   return response.text();
	})
	.then(function (data) {
	   contentDiv.innerHTML = data;
	   showSuccess('Has aplicado correctamente');
	})
	.catch(function (error) {
	   console.error('Error:', error);
	   bloquearAcciones(false);
	   showError('Error al aplicar para la practica');
	});
   });
};

</script>
