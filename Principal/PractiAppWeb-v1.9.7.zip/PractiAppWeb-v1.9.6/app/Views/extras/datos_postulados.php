<?php
    $imagenPath = base_url('alumnos/' . $alumno['ID'] . '-' . $alumno['correo'] . '.jpg');
    $imagenArchivo = FCPATH . 'alumnos/' . $alumno['ID'] . '-' . $alumno['correo'] . '.jpg';
?>

<div class="project-detail-container">
    <div class="project-detail-card">
        <div class="project-detail-grid">
            <div class="project-image-container">
                <?php if (file_exists($imagenArchivo)): ?>
                    <img src="<?= $imagenPath . '?v=' . time() ?>" alt="Foto del estudiante" class="project-detail-image">
                <?php else: ?>
                    <div class="project-detail-image placeholder">
                        <span>Sin foto disponible</span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="project-info-container">
                <?php if (isset($alumno)): ?>
                    <h2 class="project-detail-title"><?= htmlspecialchars($alumno['nombre']) ?></h2>
                    
                    <div class="project-detail-info">
                        <div class="info-row">
                            <div class="info-group">
                                <label>ID del Estudiante</label>
                                <p><?= htmlspecialchars($alumno['ID']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Carrera</label>
                                <p><?= htmlspecialchars($alumno['carrera']) ?></p>
                            </div>
                        </div>

                        <div class="info-group">
                            <label>Correo Electrónico</label>
                            <p><?= htmlspecialchars($alumno['correo']) ?></p>
                        </div>

                        <?php if (isset($alumno['semestre'])): ?>
                        <div class="info-group">
                            <label>Semestre</label>
                            <p><?= htmlspecialchars($alumno['semestre']) ?></p>
                        </div>
                        <?php endif; ?>

                        <div class="info-group">
                            <label>Estado</label>
                            <p><span style="color: var(--warning-color);">⏳ Postulado para esta práctica</span></p>
                        </div>
                    </div>
                <?php else: ?>
                    <p>No se encontraron datos del estudiante.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="button-container">
            <button class="btn btn-primary" onclick="aprobar(<?= $alumno['ID'] ?>)">Aprobar Estudiante</button>
            <button class="btn btn-secondary" type="button" onclick="confirmarRechazo()">Rechazar</button>
            <button class="btn btn-back" onclick="goBack()">Regresar</button>
        </div>
    </div>
</div>



<style>
/* Modal styles v2.0 - Updated button design */
.modern-modal {
    border: none;
    border-radius: 12px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
    overflow: hidden;
}

.modern-modal-header {
    background: linear-gradient(135deg, #2675db 0%, #1e5bb8 100%);
    color: white;
    border: none;
    padding: 2rem 1.5rem 1.5rem;
    position: relative;
    text-align: center;
}

.modal-icon-wrapper {
    margin-bottom: 0.5rem;
}

.modal-icon {
    font-size: 3rem;
    display: inline-block;
}

.modern-modal-title {
    font-size: 1.5rem;
    font-weight: 600;
    margin: 0;
    color: white;
}

.modern-close {
    position: absolute;
    top: 1rem;
    right: 1rem;
    color: white;
    opacity: 0.8;
    font-size: 1.5rem;
    font-weight: 300;
    transition: opacity 0.2s;
}

.modern-close:hover {
    opacity: 1;
}

.modern-modal-body {
    padding: 2rem 1.5rem;
    background: #f8f9fa;
}

.modal-description {
    color: #666666;
    font-size: 0.95rem;
    margin-bottom: 1.5rem;
    line-height: 1.6;
}

.modern-label {
    font-weight: 600;
    color: #333333;
    margin-bottom: 0.5rem;
    display: block;
}

.modern-textarea {
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    padding: 0.75rem;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    resize: vertical;
}

.modern-textarea:focus {
    border-color: #2675db;
    box-shadow: 0 0 0 3px rgba(38, 117, 219, 0.1);
    outline: none;
}

.modern-modal-footer {
    background: white;
    border-top: 1px solid #e9ecef;
    padding: 1rem 1.5rem;
    display: flex;
    gap: 0.75rem;
    justify-content: flex-end;
}

.modern-modal-footer .modern-btn-cancel,
.modern-modal-footer .modern-btn-submit {
    padding: 0.75rem 2rem !important;
    font-weight: 500 !important;
    border-radius: 25px !important;
    border: none !important;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 1rem !important;
    min-width: 120px !important;
}

.modern-modal-footer .modern-btn-cancel {
    background-color: #2675db !important;
    color: white !important;
}

.modern-modal-footer .modern-btn-cancel:hover {
    background-color: #1e5bb8 !important;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(38, 117, 219, 0.3);
}

.modern-modal-footer .modern-btn-submit {
    background-color: #2675db !important;
    color: white !important;
}

.modern-modal-footer .modern-btn-submit:hover {
    background-color: #1e5bb8 !important;
    transform: translateY(-2px);
    box-shadow: 0 4px 16px rgba(38, 117, 219, 0.4);
}

/* Responsive adjustments */
@media (max-width: 576px) {
    .modern-modal-header {
        padding: 1.5rem 1rem 1rem;
    }
    
    .modern-modal-title {
        font-size: 1.25rem;
    }
    
    .modal-icon {
        font-size: 2.5rem;
    }
    
    .modern-modal-body {
        padding: 1.5rem 1rem;
    }
}
</style>


<script>
function confirmarRechazo() {
    Swal.fire({
        title: '¿Está seguro?',
        text: "¿Desea rechazar a este estudiante?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, rechazar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            document.querySelectorAll('.button-container button').forEach(function (b) {
                b.disabled = true;
                b.classList.add('btn-loading');
            });
            $('#commentModal').modal('show');
            $('#commentModal').off('hidden.bs.modal').on('hidden.bs.modal', function () {
                document.querySelectorAll('.button-container button').forEach(function (b) {
                    b.disabled = false;
                    b.classList.remove('btn-loading');
                });
            });
        }
    });
}
</script>
