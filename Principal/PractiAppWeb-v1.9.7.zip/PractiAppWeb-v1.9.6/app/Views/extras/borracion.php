<h1 class="texto-practica">Detalles de la Práctica</h1>

<div class="tabla-contenedor">
    <?php if (isset($practica)): ?>
        <table border="1" cellpadding="10">
            <tr>
                <th>ID</th>
                <th>Titulo</th>
                <th>Carrera</th>
                <th>Estatus</th>
                <th>Integrantes</th>
            </tr>
            <tr>
                <td><?= htmlspecialchars($practica['ID']) ?></td>
                <td><?= htmlspecialchars($practica['Titulo']) ?></td>
                <td><?= htmlspecialchars($practica['Carrera']) ?></td>
                <td><?= htmlspecialchars($practica['Estatus']) ?></td>
                <td><?= htmlspecialchars($practica['Integrantes']) ?></td>
            </tr>
            <tr>
                <th>Requisitos</th>
                <th>Pago</th>
                <th>Horario</th>
                <th>Fecha de Registro</th>
                <th>Fecha de actividad</th>
            </tr>
            <tr>
                <td><?= htmlspecialchars($practica['Requisitos']) ?></td>
                <td><?= htmlspecialchars($practica['Pago']) ?></td>
                <td><?= substr(htmlspecialchars($practica['HorarioInicio']), 0, 5) ?> a <?= substr(htmlspecialchars($practica['HorarioFinal']), 0, 5) ?></td>
                <td><?= htmlspecialchars($practica['FechaRegistroInicio']) ?> a <?= htmlspecialchars($practica['FechaRegistroFinal']) ?> <br><span style="font-size: 0.8em; color: <?= date('Y-m-d') <= $practica['FechaRegistroFinal'] ? 'green' : 'red' ?>; font-weight: bold;"><?= date('Y-m-d') <= $practica['FechaRegistroFinal'] ? '(Vigente)' : '(No Vigente)' ?></span></td>
                <td><?= htmlspecialchars($practica['FechaActividadInicio']) ?> a <?= htmlspecialchars($practica['FechaActividadFinal']) ?> <br><span style="font-size: 0.8em; color: <?= date('Y-m-d') <= $practica['FechaActividadFinal'] ? 'green' : 'red' ?>; font-weight: bold;"><?= date('Y-m-d') <= $practica['FechaActividadFinal'] ? '(Vigente)' : '(No Vigente)' ?></span></td>
            </tr>
        </table>
    <?php else: ?>
        <p>No se encontraron datos para esta práctica.</p>
    <?php endif; ?>
</div>

<?php
    // Ruta a la imagen
    $imagenPath = base_url('imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg');
    $imagenArchivo = FCPATH . 'imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg';
?>

<?php if (file_exists($imagenArchivo)): ?>
    <div style="text-align: center; margin-top: 20px;">
        <h3>Imagen de la Práctica</h3>
        <img src="<?= $imagenPath . '?v=' . time() ?>" alt="Imagen de la práctica" width="200" height="200" style="object-fit: cover; border: 1px solid #ccc;">
    </div>
<?php else: ?>
    <div style="text-align: center; margin-top: 20px;">
        <p><em>No hay imagen asociada a esta práctica.</em></p>
    </div>
<?php endif; ?>

<div class="botones-tabla">
    <button onclick="restaurar(<?= $practica['ID'] ?>)">Restaurar</button>
    <button onclick="eliminarPractica(<?= $practica['ID'] ?>)">Eliminar definitivamente</button>
    <button onclick="loadContent('papelera')">Cancelar</button>
</div>

<script>
function restaurar(id) {
    showConfirm('¿Estás seguro de que deseas restaurar este proyecto?', function () {
        lockAllButtons();
        fetch(baseUrl + '/fase/' + id, { method: 'POST' })
            .then(function(r) { return r.ok ? r.json() : Promise.reject(); })
            .then(function(data) {
                showSuccess('Proyecto restaurado correctamente', function () {
                    loadContent('papelera');
                });
            })
            .catch(function() {
                showError('Error al restaurar el proyecto');
                unlockAllButtons();
            });
    });
}
</script>