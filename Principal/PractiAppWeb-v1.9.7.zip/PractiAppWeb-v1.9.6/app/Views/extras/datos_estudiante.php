<?php
    $imagenPath = base_url('alumnos/' . $alumno['ID'] . '-' . $alumno['correo'] . '.jpg');
    $imagenArchivo = FCPATH . 'alumnos/' . $alumno['ID'] . '-' . $alumno['correo'] . '.jpg';
?>

<div class="project-detail-container">
    <div class="project-detail-card">
        <div class="project-detail-grid">
            <div class="project-image-container">
                <?php if (file_exists($imagenArchivo)): ?>
                    <img src="<?= $imagenPath . '?v=' . time() ?>" alt="Foto del estudiante" class="project-detail-image">
                <?php else: ?>
                    <div class="project-detail-image placeholder">
                        <span>Sin foto disponible</span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="project-info-container">
                <?php if (isset($alumno)): ?>
                    <h2 class="project-detail-title"><?= htmlspecialchars($alumno['nombre']) ?></h2>
                    
                    <div class="project-detail-info">
                        <div class="info-row">
                            <div class="info-group">
                                <label>ID del Estudiante</label>
                                <p><?= htmlspecialchars($alumno['ID']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Carrera</label>
                                <p><?= htmlspecialchars($alumno['carrera']) ?></p>
                            </div>
                        </div>

                        <div class="info-group">
                            <label>Correo Electrónico</label>
                            <p><?= htmlspecialchars($alumno['correo']) ?></p>
                        </div>

                        <?php if (isset($alumno['semestre'])): ?>
                        <div class="info-group">
                            <label>Semestre</label>
                            <p><?= htmlspecialchars($alumno['semestre']) ?></p>
                        </div>
                        <?php endif; ?>

                        <div class="info-group">
                            <label>Estado</label>
                            <p>
                                <?php 
                                switch($alumno['Fase']) {
                                    case 2:
                                        echo '<span style="color: var(--warning-color);">⏳ Postulado</span>';
                                        break;
                                    case 3:
                                        echo '<span style="color: var(--success-color);">✅ Aceptado en el proyecto</span>';
                                        break;
                                    default:
                                        echo '<span style="color: var(--text-light);">Sin práctica asignada</span>';
                                }
                                ?>
                            </p>
                        </div>
                    </div>
                <?php else: ?>
                    <p>No se encontraron datos del estudiante.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="button-container">
            <button class="btn btn-secondary" type="button" onclick="confirmarEliminacion()">Eliminar de la Práctica</button>
            <button class="btn btn-primary" onclick="goBack()">Regresar</button>
        </div>
    </div>
</div>

<!-- Modern Modal para eliminar con comentario -->
<div class="modal fade bootstrap-modal" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="commentModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content modern-modal">
            <form id="Formulario correo" action="<?= site_url('home/sendCommentA') ?>" method="post">
                <input type="hidden" name="id" value="<?= $alumno['ID'] ?>">
                <div class="modal-header modern-modal-header">
                    <div class="modal-icon-wrapper">
                        <span class="modal-icon warning">⚠️</span>
                    </div>
                    <h5 class="modal-title modern-modal-title" id="commentModalLabel">Motivo de Eliminación</h5>
                </div>
                <div class="modal-body modern-modal-body">
                    <p class="modal-description">Ingrese el motivo para retirar al estudiante. Se le notificará por correo.</p>
                    <div class="input-group-modern">
                        <label for="comment" class="modern-label">Motivo de la baja</label>
                        <textarea class="form-control modern-textarea" id="comment" name="comment" rows="5" placeholder="Describe el motivo..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer modern-modal-footer">
                    <button type="button" class="btn btn-secondary modern-btn-cancel" data-dismiss="modal">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary modern-btn-submit">
                        Enviar correo
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function confirmarEliminacion() {
    Swal.fire({
        title: '¿Está seguro?',
        text: "¿Desea eliminar a este estudiante de la práctica?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            document.querySelectorAll('.button-container button').forEach(function (b) {
                b.disabled = true;
                b.classList.add('btn-loading');
            });
            $('#commentModal').modal('show');
            $('#commentModal').off('hidden.bs.modal').on('hidden.bs.modal', function () {
                document.querySelectorAll('.button-container button').forEach(function (b) {
                    b.disabled = false;
                    b.classList.remove('btn-loading');
                });
            });
        }
    });
}
</script>
