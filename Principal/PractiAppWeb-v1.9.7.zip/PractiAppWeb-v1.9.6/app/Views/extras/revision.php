<?php
    $autorEmail = isset($practica['Autor']) ? $practica['Autor'] : '';
    $tipoAutor = 'al responsable';
    if ($autorEmail) {
        $maestroModel = new \App\Models\MaestroModel();
        $coordinadorModel = new \App\Models\CoordinadorModel();
        if ($maestroModel->where('correo', $autorEmail)->first()) {
            $tipoAutor = 'al maestro';
        } elseif ($coordinadorModel->where('correo', $autorEmail)->first()) {
            $tipoAutor = 'al coordinador';
        }
    }
?>
<div class="project-detail-container">
    <div class="project-detail-card">
        <div class="button-container">
            <button class="btn btn-back" onclick="loadContent('revisar')">← Volver</button>
            <button class="btn btn-primary" onclick="fase(<?= $practica['ID'] ?>)">Aprobar</button>
            <button class="btn btn-secondary" type="button" onclick="rechazarSinCorreo(<?= $practica['ID'] ?>)">Rechazar</button>
        </div>

        <div class="project-detail-grid">
            <div class="project-image-container">
                <?php
                    $imagenPath = base_url('imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg');
                    $imagenArchivo = FCPATH . 'imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg';
                ?>
                <?php if (file_exists($imagenArchivo)): ?>
                    <img src="<?= $imagenPath . '?v=' . time() ?>" alt="Imagen de la práctica" class="project-detail-image">
                <?php else: ?>
                    <div class="project-detail-image placeholder">
                        <span>Sin imagen disponible</span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="project-info-container">
                <?php if (isset($practica)): ?>
                    <h2 class="project-detail-title"><?= htmlspecialchars($practica['Titulo']) ?></h2>
                    
                    <div class="project-detail-info">
                        <div class="info-row">
                            <div class="info-group">
                                <label>ID</label>
                                <p><?= htmlspecialchars($practica['ID']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Carrera</label>
                                <p><?= htmlspecialchars($practica['Carrera']) ?></p>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Estatus</label>
                                <p><?= htmlspecialchars($practica['Estatus']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Vacantes</label>
                                <p><?= htmlspecialchars($practica['Integrantes']) ?></p>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Requisitos (semestre)</label>
                                <p><?= htmlspecialchars($practica['Requisitos']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Apoyo económico</label>
                                <p>$<?= htmlspecialchars($practica['Pago']) ?></p>
                            </div>
                        </div>

                        <div class="info-group">
                            <label>Horario</label>
                            <p><?= substr(htmlspecialchars($practica['HorarioInicio']), 0, 5) ?> a <?= substr(htmlspecialchars($practica['HorarioFinal']), 0, 5) ?></p>
                        </div>

                        <div class="info-group">
                            <label>Fecha de Registro</label>
                            <p><?= htmlspecialchars($practica['FechaRegistroInicio']) ?> a <?= htmlspecialchars($practica['FechaRegistroFinal']) ?> <span style="font-size: 0.8em; color: <?= date('Y-m-d') <= $practica['FechaRegistroFinal'] ? 'green' : 'red' ?>; margin-left: 5px; font-weight: bold;"><?= date('Y-m-d') <= $practica['FechaRegistroFinal'] ? '(Vigente)' : '(No Vigente)' ?></span></p>
                        </div>

                        <div class="info-group">
                            <label>Período de Actividad</label>
                            <p><?= htmlspecialchars($practica['FechaActividadInicio']) ?> a <?= htmlspecialchars($practica['FechaActividadFinal']) ?> <span style="font-size: 0.8em; color: <?= date('Y-m-d') <= $practica['FechaActividadFinal'] ? 'green' : 'red' ?>; margin-left: 5px; font-weight: bold;"><?= date('Y-m-d') <= $practica['FechaActividadFinal'] ? '(Vigente)' : '(No Vigente)' ?></span></p>
                        </div>
                    </div>
                <?php else: ?>
                    <p>No se encontraron datos para esta práctica.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<script>

function rechazarSinCorreo(id) {
	Swal.fire({
	    title: '¿Estas seguro?',
	    text: '¿Desea rechazar este proyecto?',
	    icon: 'warning',
	    showCancelButton: true,
	    confirmButtonText: 'Si, rechazar',
	    cancelButtonText: 'Cancelar'
	}).then(function (result) {
	    if(!result.isConfirmed) return;
	    var fd = new FormData();
	    fd.append('id', id);
	    fetch('<?= site_url('home/sendCommentP') ?>', {method: 'POST', body: fd })
		.then(function (r) { if (!r.ok) throw new Error(); return r.text(); })
		.then(function () {
		    showSuccess('Proyecto rechazado con exito', function () { loadContent('revisar'); });
		})
		.catch(function () {showError('Error al rechazar la practica'); });
	});
}

</script>
