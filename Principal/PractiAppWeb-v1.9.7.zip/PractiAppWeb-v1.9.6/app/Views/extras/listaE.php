<?php
    $imagenPath = base_url('empresas/' . $empresa['imagen']);
    $constanciaPath = base_url('constancia/' . $empresa['constancia']);
    $FPP1Path = base_url('FPP-1/' . $empresa['FPP1']);
    $imagenArchivo = FCPATH . 'empresas/' . $empresa['ID'] . '-' . $empresa['correo'] .'.jpg';
?>

<div class="project-detail-container">
    <div class="project-detail-card">
        <div class="project-detail-grid">
            <div class="project-image-container">
                <?php if (file_exists($imagenArchivo)): ?>
                    <img src="<?= $imagenPath . '?v=' . time() ?>" alt="Logo de la empresa" class="project-detail-image">
                <?php else: ?>
                    <div class="project-detail-image placeholder">
                        <span>Sin imagen disponible</span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="project-info-container">
                <?php if (isset($empresa)): ?>
                    <h2 class="project-detail-title"><?= htmlspecialchars($empresa['nombre']) ?></h2>
                    
                    <div class="project-detail-info">
                        <div class="info-row">
                            <div class="info-group">
                                <label>ID de la Empresa</label>
                                <p><?= htmlspecialchars($empresa['ID']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>RFC</label>
                                <p><?= htmlspecialchars($empresa['RFC']) ?></p>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Correo Electrónico</label>
                                <p><?= htmlspecialchars($empresa['correo']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Departamento</label>
                                <p><?= htmlspecialchars($empresa['departamento']) ?></p>
                            </div>
                        </div>

                        <div class="info-group">
                            <label>Fase de Registro</label>
                            <p>
                                <?php 
                                switch($empresa['Fase']) {
                                    case 1:
                                        echo '<span style="color: var(--warning-color);">⏳ En revisión</span>';
                                        break;
                                    case 2:
                                        echo '<span style="color: var(--success-color);">✅ Aprobada</span>';
                                        break;
                                    default:
                                        echo '<span style="color: var(--text-light);">Estado desconocido</span>';
                                }
                                ?>
                            </p>
                        </div>

                        <div class="info-group" style="background: var(--card-background); padding: 1rem; border-radius: var(--border-radius);">
                            <label style="color: var(--primary-color);">Documentos Adjuntos</label>
                            <p style="color: var(--text-light); font-size: 0.9rem; margin: 0.5rem 0;">
                                ✓ Constancia de situación fiscal<br>
                                ✓ Formato FPP-1
                            </p>
                            <div style="display: flex; gap: 0.5rem; margin-top: 0.5rem;">
                                <a href="<?= $constanciaPath ?>" download="<?= $empresa['constancia'] ?>" class="btn btn-secondary" style="flex: 1; text-align: center; text-decoration: none; font-size: 0.85rem;">
                                    📄 Constancia
                                </a>
                                <a href="<?= $FPP1Path ?>" download="<?= $empresa['FPP1'] ?>" class="btn btn-secondary" style="flex: 1; text-align: center; text-decoration: none; font-size: 0.85rem;">
                                    📋 FPP-1
                                </a>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <p>No se encontraron datos para esta empresa.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="button-container">
            <button class="btn btn-secondary" onclick="loadContent('empresas')">← Volver</button>
            <?php if ($empresa['Fase'] == 1): ?>
                <button class="btn btn-primary" onclick="unirse(<?= $empresa['ID'] ?>)">Aprobar Empresa</button>
                <button class="btn btn-secondary" type="button" onclick="prepararRechazoEmpresa(<?= $empresa['ID'] ?>)">Rechazar</button>
            <?php endif; ?>
        </div>
    </div>
</div>
