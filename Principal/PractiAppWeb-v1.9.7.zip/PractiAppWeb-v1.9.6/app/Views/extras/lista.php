<?php
    $correo = session()->get('correo');
    $imagenPath = base_url('imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg');
    $imagenArchivo = FCPATH . 'imagenes/' . $practica['ID'] . '-' . $practica['Carrera'] . '.jpg';
?>

<div class="project-detail-container">
    <div class="project-detail-card">
        <div class="project-detail-grid">
            <div class="project-image-container">
                <?php if (file_exists($imagenArchivo)): ?>
                    <img src="<?= $imagenPath . '?v=' . time() ?>" alt="Imagen de la práctica" class="project-detail-image">
                <?php else: ?>
                    <div class="project-detail-image placeholder">
                        <span>Sin imagen disponible</span>
                    </div>
                <?php endif; ?>
            </div>

            <div class="project-info-container">
                <?php if (isset($practica)): ?>
                    <h2 class="project-detail-title"><?= htmlspecialchars($practica['Titulo']) ?></h2>
                    
                    <div class="project-detail-info">
                        <div class="info-group">
                            <label>Descripción</label>
                            <p>Proyecto de <?= htmlspecialchars($practica['Carrera']) ?>.</p>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>ID del Proyecto</label>
                                <p><?= htmlspecialchars($practica['ID']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Carrera</label>
                                <p><?= htmlspecialchars($practica['Carrera']) ?></p>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Requisitos</label>
                                <p><?= htmlspecialchars($practica['Requisitos']) ?> semestre(s) o más</p>
                            </div>
                            <div class="info-group">
                                <label>Número de vacantes</label>
                                <p><?= htmlspecialchars($practica['Integrantes']) ?></p>
                            </div>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Apoyo económico</label>
                                <p>$<?= htmlspecialchars($practica['Pago']) ?></p>
                            </div>
                            <div class="info-group">
                                <label>Estado</label>
                                <p><?= htmlspecialchars($practica['Estatus']) ?></p>
                            </div>
                        </div>

                        <div class="info-group">
                            <label>Horario</label>
                            <p><?= substr(htmlspecialchars($practica['HorarioInicio']), 0, 5) ?> a <?= substr(htmlspecialchars($practica['HorarioFinal']), 0, 5) ?></p>
                        </div>

                        <div class="info-row">
                            <div class="info-group">
                                <label>Registro</label>
                                <p><?= htmlspecialchars($practica['FechaRegistroInicio']) ?> a <?= htmlspecialchars($practica['FechaRegistroFinal']) ?> <span style="font-size: 0.8em; color: <?= date('Y-m-d') <= $practica['FechaRegistroFinal'] ? 'green' : 'red' ?>; margin-left: 5px; font-weight: bold;"><?= date('Y-m-d') <= $practica['FechaRegistroFinal'] ? '(Vigente)' : '(No Vigente)' ?></span></p>
                            </div>
                            <div class="info-group">
                                <label>Período de actividad</label>
                                <p><?= htmlspecialchars($practica['FechaActividadInicio']) ?> a <?= htmlspecialchars($practica['FechaActividadFinal']) ?> <span style="font-size: 0.8em; color: <?= date('Y-m-d') <= $practica['FechaActividadFinal'] ? 'green' : 'red' ?>; margin-left: 5px; font-weight: bold;"><?= date('Y-m-d') <= $practica['FechaActividadFinal'] ? '(Vigente)' : '(No Vigente)' ?></span></p>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <p>No se encontraron datos para esta práctica.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="button-container">
            <?php if ($correo == $practica['Autor']): ?>
                <?php if ($practica['Estatus'] == 'Activo'): ?>
                    <button class="btn btn-secondary" onclick="estudiantes(<?= $practica['ID'] ?>)">Estudiantes</button>
                    <?php if ($practica['Integrantes'] > 0): ?>
                        <button class="btn btn-secondary" onclick="postulados(<?= $practica['ID'] ?>)">Postulados</button>
                    <?php endif; ?>
                <?php endif; ?>
                <button class="btn btn-secondary" onclick="editarPractica(<?= $practica['ID'] ?>)">Editar</button>
                <button class="btn btn-secondary" onclick="papelera(<?= $practica['ID'] ?>)">Eliminar</button>
            <?php else: ?>
                <button class="btn btn-primary" type="button" onclick="confirmarEliminacionPractica()">Eliminar definitivamente</button>
            <?php endif; ?>
            <button class="btn btn-primary" onclick="loadContent('inicio')">Regresar</button>
        </div>
    </div>
</div>

<?php if ($correo != $practica['Autor']): ?>
<!-- Modern Modal for project deletion with comment -->
<div class="modal fade bootstrap-modal" id="commentModal" tabindex="-1" role="dialog" aria-labelledby="commentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content modern-modal">
            <form id="formEliminacionPractica" action="<?= site_url('home/sendCommentP') ?>" method="post">
                <input type="hidden" name="id" value="<?= $practica['ID'] ?>">
                <div class="modal-header modern-modal-header">
                    <div class="modal-icon-wrapper">
                        <span class="modal-icon warning">⚠️</span>
                    </div>
                    <h5 class="modal-title modern-modal-title" id="commentModalLabel">Motivo de Eliminación</h5>
                </div>
                <div class="modal-body modern-modal-body">
                    <p class="modal-description">Ingrese el motivo para eliminar este proyecto. Se notificará al creador por correo.</p>
                    <div class="input-group-modern">
                        <label for="comment" class="modern-label">Motivo de eliminación</label>
                        <textarea class="form-control modern-textarea" id="comment" name="comment" rows="5" placeholder="Describe el motivo..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer modern-modal-footer">
                    <button type="button" class="btn btn-secondary modern-btn-cancel" data-dismiss="modal">
                        Cancelar
                    </button>
                    <button type="submit" class="btn btn-primary modern-btn-submit">
                        Enviar correo
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($correo != $practica['Autor']): ?>

<script>
// Handle form submission to maintain database tab selection
$(document).ready(function() {
    $('#formEliminacionPractica').on('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        $('#commentModal').modal('hide');
        
        fetch('<?= site_url('home/sendCommentP') ?>', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            showSuccess('Proyecto eliminado y notificación enviada');
            // Reload database tab content
            loadContent('buscar');
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Error al eliminar el proyecto');
        });
    });
});
</script>
<?php endif; ?>
