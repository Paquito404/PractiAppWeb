<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// ------------------------ Login ------------------------- //

$routes->get('/', 'Home::index');
$routes->post('login', 'Home::login');
$routes->get('logout', 'Home::logout');

// -------------------------------------------------------- //

//------------------------ Contenido ---------------------- //

$routes->get('alumno', 'Home::alumno');
$routes->get('maestro', 'Home::maestro');
$routes->get('moderador', 'Home::moderador');
$routes->get('coordinador', 'Home::coordinador');
$routes->get('empresa', 'Home::empresa');
$routes->get('carga/(:any)', 'Home::carga/$1');
$routes->get('carga_debug/(:any)', 'Home::carga_debug/$1');

$routes->get('/borracion/(:num)', 'Home::borracion/$1');
$routes->post('/papelera/(:num)', 'Home::papelera/$1');
$routes->post('/coordinador/eliminarPermanente/(:num)', 'Home::eliminar/$1');

$routes->get('/revision/(:num)', 'Home::revision/$1');
$routes->post('/fase/(:num)', 'Home::fase/$1');

$routes->get('/vistaA/(:num)', 'Home::vistaA/$1');
$routes->get('/aplicar/(:num)', 'Home::aplicar/$1');
$routes->get('/estudiantes/(:num)', 'Home::estudiantes/$1');
$routes->get('/postulados/(:num)', 'Home::postulados/$1');
$routes->get('/api/postulados/(:num)', 'Home::api_postulados/$1');
$routes->get('/api/estudiantes/(:num)', 'Home::api_estudiantes/$1');
$routes->get('/datos_estudiante/(:num)', 'Home::datos_estudiante/$1');
$routes->get('/datos_postulados/(:num)', 'Home::datos_postulados/$1');
$routes->get('/aprobar/(:num)', 'Home::aprobar/$1');
$routes->get('/rechazar/(:num)', 'Home::rechazar/$1');

// -------------------------------------------------------- //

// -------------------- CRUD Practicas -------------------- //

$routes->post('escuela', 'Home::guardar');
$routes->get('/vista/(:num)', 'Home::vista/$1');
$routes->get('/editar/(:num)', 'Home::editar/$1');
$routes->post('/actualizar/(:num)', 'Home::actualizar/$1');
$routes->delete('/eliminar/(:num)', 'Home::eliminar/$1');
$routes->get('/checkStudents/(:num)', 'Home::checkStudents/$1');

// -------------------------------------------------------- //

// ---------------------- Registros ----------------------- //

$routes->post('registroM', 'Home::guardarM'); // Maestros
$routes->post('registroC', 'Home::guardarC'); // Coordinadores

// -------------------------------------------------------- //

// ---------------------- Obtencion ----------------------- //

$routes->get('/obtenerC/(:num)', 'Home::ObtenerC/$1'); //Coordinador
$routes->get('/obtenerMo/(:num)', 'Home::ObtenerMo/$1'); //Moderador
$routes->get('/obtenerM/(:num)', 'Home::ObtenerM/$1'); //Maestro
$routes->get('/obtenerA/(:num)', 'Home::ObtenerA/$1'); //Alumno
$routes->get('/obtenerE/(:num)', 'Home::ObtenerE/$1'); //Empresa

// -------------------------------------------------------- //

// ----------------------- Empresas ----------------------- //

$routes->get('form_empresa', 'Home::form_empresa');
$routes->post('registro', 'Home::registro');
$routes->get('/vistaE/(:num)', 'Home::vistaE/$1');
$routes->post('/unirse/(:num)', 'Home::unirse/$1');
$routes->delete('/desaprobar/(:num)', 'Home::desaprobar/$1');

// -------------------------------------------------------- //

// ---------------- Correos personalizados ---------------- //

$routes->post('home/sendCommentE', 'Home::sendCommentE');
$routes->post('home/sendCommentA', 'Home::sendCommentA');
$routes->post('home/sendCommentP', 'Home::sendCommentP');