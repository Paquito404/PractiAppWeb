<?php

namespace Config;

use CodeIgniter\Database\Config;
use PDO;

class Database extends Config
{
    public string $filesPath = APPPATH . 'Database' . DIRECTORY_SEPARATOR;

    public string $defaultGroup = 'default';

    /**
     * The default database connection.
     *
     * @var array<string, mixed>
     */
    
        public array $default = [
            'DSN'        => '',
            'servername' => '',
            // 1. Apuntamos al contenedor de Docker por su nombre de servicio
            'hostname'   => 'sqlserver', 
            // 2. Usuario administrador por defecto de SQL Server
            'username'   => 'sa',
            // 3. La contraseña que definimos en el docker-compose.yml
            'password'   => 'Practica_Segura_2026!',
            // 4. El nombre de tu base de datos
            'database'   => 'Escuela',
            'schema'     => 'dbo',
            'DBDriver'   => 'SQLSRV',
            'DBPrefix'   => '',
            'pConnect'   => false,
            'DBDebug'    => true,
            'charset'    => 'UTF-8',
            'swapPre'    => '',
            'encrypt'    => false,
            'failover'   => [],
            'port'       => 1433,
            // 5. Vital para el Driver 18 de ODBC
            'TrustServerCertificate' => true,
            'dateFormat' => [
                'date'     => 'Y-m-d',
                'datetime' => 'Y-m-d H:i:s',
                'time'     => 'H:i:s',
            ],
            'encoding'   => 'SQLSRV_ENC_CHAR',
            'options' => [
                PDO::SQLSRV_ATTR_ENCODING => PDO::SQLSRV_ENCODING_BINARY,
                PDO::SQLSRV_ATTR_DIRECT_QUERY => true
            ]
        ];

    /**
     * This database connection is used when running PHPUnit database tests.
     *
     * @var array<string, mixed>
     */

    public function __construct()
    {
        parent::__construct();

        if (ENVIRONMENT === 'testing') {
            $this->defaultGroup = 'tests';
        }
    }
}
