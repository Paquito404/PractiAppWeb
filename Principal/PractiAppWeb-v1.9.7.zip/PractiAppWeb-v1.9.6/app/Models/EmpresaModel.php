<?php

namespace App\Models;
use CodeIgniter\Model;

class EmpresaModel extends Model
{
    protected $table = 'empresas';
    protected $returnType = 'array';
    protected $primaryKey = 'ID';
    protected $allowedFields = ['nombre', 
                                'correo', 
                                'RFC', 
                                'departamento',
                                'password', 
                                'Fase', 
                                'imagen',
                                'constancia',
                                'FPP1'];
}