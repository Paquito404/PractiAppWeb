USE Escuela;
GO

CREATE TABLE Practicas (

    ID INT PRIMARY KEY IDENTITY(1,1),

    Titulo VARCHAR(100),

    Requisitos INT,

    Carrera VARCHAR(100),

    Departamento VARCHAR(100),

    Estatus VARCHAR(50),

    Integrantes INT,

    Pago INT,

    HorarioInicio TIME(0),

    HorarioFinal TIME(0),

    FechaRegistroInicio DATE,

    FechaRegistroFinal DATE,

    FechaActividadInicio DATE,

    FechaActividadFinal DATE,

    Fase INT,

    Fecha DATETIME2(0) NULL,

    Imagen VARCHAR(255),

    Autor VARCHAR(30),

    Postulados INT

);

CREATE TABLE alumnos (

	ID INT PRIMARY KEY IDENTITY(1,1),

	nombre VARCHAR(50),

	carrera VARCHAR(50),

	correo VARCHAR(50),

	semestre INT,

	password VARCHAR(50),

	ID_Practica INT,

	Fase INT

);

CREATE TABLE maestros (

	ID INT PRIMARY KEY IDENTITY(1,1),

	nombre VARCHAR(50),

	departamento VARCHAR(50),

	correo VARCHAR(50),

	password VARCHAR(50)

);



CREATE TABLE coordinadores (

	ID INT PRIMARY KEY IDENTITY(1,1),

	nombre VARCHAR(50),

	departamento VARCHAR(50),

	correo VARCHAR(50),

	password VARCHAR(50)

);



CREATE TABLE moderadores (

	ID INT PRIMARY KEY IDENTITY(1,1),

	nombre VARCHAR(50),

	departamento VARCHAR(50),

	correo VARCHAR(50),

	password VARCHAR(50)

);



CREATE TABLE empresas (

	ID INT PRIMARY KEY IDENTITY(1,1),

	nombre VARCHAR(50),

	correo VARCHAR(50),

	RFC VARCHAR(50),

	departamento VARCHAR(50),

	password VARCHAR(50),

	Fase INT,

	imagen VARCHAR(50),

	constancia VARCHAR(50),

	FPP1 VARCHAR(50)

);



CREATE TABLE Carreras (

	ID INT PRIMARY KEY IDENTITY(1,1),

	nombre VARCHAR(100),

	Departamento VARCHAR(100)

);



CREATE TABLE Departamentos (

	nombre VARCHAR(100)

);

GO

INSERT INTO Departamentos VALUES ('Ingenieria');

INSERT INTO Departamentos VALUES ('Medicina');

INSERT INTO Departamentos VALUES ('Licenciatura');

INSERT INTO Departamentos VALUES ('Arte');



INSERT INTO Carreras VALUES ('Programación','Ingenieria');

INSERT INTO Carreras VALUES ('Mecatronica','Ingenieria');

INSERT INTO Carreras VALUES ('Electronica','Ingenieria');

INSERT INTO Carreras VALUES ('Consultoria','Medicina');

INSERT INTO Carreras VALUES ('Pediatria','Medicina');

INSERT INTO Carreras VALUES ('Oftalmologia','Medicina');

INSERT INTO Carreras VALUES ('Criminologia','Licenciatura');

INSERT INTO Carreras VALUES ('Copyright','Licenciatura');

INSERT INTO Carreras VALUES ('Derecho','Licenciatura');

INSERT INTO Carreras VALUES ('Lenguas','Arte');

INSERT INTO Carreras VALUES ('Lectura','Arte');

INSERT INTO Carreras VALUES ('Actuación','Arte');



INSERT INTO alumnos VALUES ('David', 'Programación', '100@gmail.com', 12, '100', NULL, 1);

INSERT INTO alumnos VALUES ('Antonio', 'Programación', '200@gmail.com', 9, '200', NULL, 1);

INSERT INTO alumnos VALUES ('Roberto', 'Programación', '300@gmail.com', 3, '300', NULL, 1);



INSERT INTO maestros VALUES ('Gonzales', 'Ingenieria', '111@gmail.com', 'abcd');

INSERT INTO coordinadores VALUES ('Tony', 'Medicina', 'Z@gmail.com', 'zzzz');

INSERT INTO moderadores VALUES ('Ochoa', 'Licenciatura', 'abcd@gmail.com', '1111');
GO
