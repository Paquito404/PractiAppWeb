// Navigation history stack for SPA back navigation
window.navigationHistory = window.navigationHistory || [];

/**
 * Deshabilita todos los botones dentro de un elemento (o del documento)
 * y aplica la clase visual btn-loading al botón que disparó la acción.
 * @param {HTMLElement|null} triggerBtn  Botón que inició la acción (recibe el spinner).
 * @param {HTMLElement}      [scope]     Contenedor donde buscar botones (default: form del trigger).
 */
function disableButtons(triggerBtn, scope) {
    const container = scope || (triggerBtn && triggerBtn.closest('form')) || document;
    container.querySelectorAll('button, input[type="submit"]').forEach(function (btn) {
        btn.disabled = true;
    });
    if (triggerBtn) {
        triggerBtn.classList.add('btn-loading');
    }
}

/**
 * Re-habilita los botones dentro de un contenedor y quita el spinner.
 * @param {HTMLElement|null} triggerBtn
 * @param {HTMLElement}      [scope]
 */
function enableButtons(triggerBtn, scope) {
    const container = scope || (triggerBtn && triggerBtn.closest('form')) || document;
    container.querySelectorAll('button, input[type="submit"]').forEach(function (btn) {
        btn.disabled = false;
    });
    if (triggerBtn) {
        triggerBtn.classList.remove('btn-loading');
    }
}

/**
 * Bloquea TODOS los botones, inputs submit y enlaces .btn del documento.
 * Marca window._actionInProgress = true para indicar que hay una acción en curso.
 * Usar siempre al confirmar una acción que produzca redirección.
 */
function lockAllButtons() {
    window._actionInProgress = true;
    document.querySelectorAll('button, input[type="submit"], a.btn').forEach(function (el) {
        el.disabled = true;
        el.style.pointerEvents = 'none';
    });
}

/**
 * Re-habilita TODOS los botones, inputs submit y enlaces .btn del documento.
 * Marca window._actionInProgress = false.
 * Usar solo en caminos de cancelación (nunca tras un submit exitoso que redirige).
 */
function unlockAllButtons() {
    window._actionInProgress = false;
    document.querySelectorAll('button, input[type="submit"], a.btn').forEach(function (el) {
        el.disabled = false;
        el.style.pointerEvents = '';
    });
}

/**
 * Aplica límites de fecha a todos los <input type="date"> de un formulario.
 *
 * - max: hoy + 5 años (evita años absurdos que causan errores en SQL Server)
 * - min: hoy si enforceMin=true (formularios de creación)
 *        sin mínimo si enforceMin=false (formularios de edición, para no bloquear fechas pasadas)
 * - Validación cruzada: cada campo "Final" no puede ser menor que su par "Inicio".
 *
 * @param {HTMLElement} form        Formulario objetivo.
 * @param {boolean}     enforceMin  Si true, los campos de inicio tienen min=hoy.
 */
function applyDateLimits(form, enforceMin) {
    if (!form) return;

    const today = new Date();
    const oneWeekAgo = new Date(today);
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const todayStr = oneWeekAgo.toISOString().split('T')[0]; // YYYY-MM-DD (una semana antes)

    const maxDate = new Date(today);
    maxDate.setFullYear(maxDate.getFullYear() + 5);
    const maxStr = maxDate.toISOString().split('T')[0];

    // Aplicar max a todos los date inputs; min solo si enforceMin
    form.querySelectorAll('input[type="date"]').forEach(function (input) {
        input.setAttribute('max', maxStr);
        if (enforceMin) {
            input.setAttribute('min', todayStr);
        }
    });

    // Validación cruzada: Final >= Inicio para cada par de fechas
    var pairs = [
        ['FechaRegistroInicio', 'FechaRegistroFinal'],
        ['FechaActividadInicio', 'FechaActividadFinal']
    ];

    pairs.forEach(function (pair) {
        var inicioInput = form.querySelector('[name="' + pair[0] + '"]');
        var finalInput = form.querySelector('[name="' + pair[1] + '"]');
        if (!inicioInput || !finalInput) return;

        // Cuando cambia el inicio, ajustar el mínimo del final
        inicioInput.addEventListener('change', function () {
            if (this.value) {
                finalInput.setAttribute('min', this.value);
                // Si el final ya elegido queda antes del nuevo inicio, corregirlo
                if (finalInput.value && finalInput.value < this.value) {
                    finalInput.value = this.value;
                }
            }
        });

        // Inicializar el mínimo del final según el valor actual del inicio
        if (inicioInput.value) {
            finalInput.setAttribute('min', inicioInput.value);
        }
    });
}

function loadContent(pagina) {
    const contentDiv = document.getElementById('content');

    // Save current page to history before loading new content
    if (window.currentPage && window.currentPage !== pagina) {
        window.navigationHistory.push(window.currentPage);
    }
    window.currentPage = pagina;

    fetch(baseUrl + '/carga/' + pagina)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar el contenido');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
            initializeImageUploadPreviews();
            initializeFormularioValidation();
            initializeRegistroMValidation();
            initializeRegistroCValidation();

            // Update active tab to match loaded content
            updateActiveTabForPage(pagina);
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar el contenido.</p>';
            console.error('Error:', error);
        });
}

// Global back navigation function
window.goBack = function () {
    if (window.navigationHistory.length > 0) {
        const previousPage = window.navigationHistory.pop();
        // Load previous page without adding to history
        const temp = window.currentPage;
        window.currentPage = previousPage;
        loadContent(previousPage);
        // Prevent the page we're leaving from being added back to history
        window.currentPage = previousPage;
    } else {
        // Fallback to 'inicio' if no history
        loadContent('inicio');
    }
};


document.querySelectorAll('nav ul li button').forEach(btn => {
    btn.addEventListener('click', e => {
        e.preventDefault();
        const pagina = btn.getAttribute('onclick').match(/'(.+?)'/)[1];
        loadContent(pagina);
        setTimeout(() => window.scrollTo(0, 0), 50);
    });
});

window.onload = function () {
    loadContent('inicio');
    initializeProfileDropdown();
    updateActiveNavItem();
};


function initializeProfileDropdown() {
    const profileIcon = document.getElementById('profileIcon');
    const profileDropdown = document.getElementById('profileDropdown');

    if (profileIcon && profileDropdown) {
        profileIcon.addEventListener('click', function (e) {
            e.stopPropagation();
            profileDropdown.classList.toggle('active');
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function (e) {
            if (!profileIcon.contains(e.target) && !profileDropdown.contains(e.target)) {
                profileDropdown.classList.remove('active');
            }
        });
    }
}


function updateActiveNavItem() {
    const navLinks = document.querySelectorAll('.nav-item a');
    navLinks.forEach(link => {
        link.addEventListener('click', function () {
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

// Update active tab to match the current page content
function updateActiveTabForPage(pagina) {
    // Map page identifiers to their corresponding onclick values
    const pageToTabMap = {
        'inicio': 'inicio',
        'datos_practica': 'datos_practica',
        'formulario': 'formulario',
        'papelera': 'papelera',
        'revisar': 'revisar',
        'buscar': 'buscar',
        'registroM': 'registroM',
        'registroC': 'registroC',
        'empresas': 'empresas'
    };

    const targetPage = pageToTabMap[pagina] || 'inicio';
    const navLinks = document.querySelectorAll('.nav-item a');

    navLinks.forEach(link => {
        const onclick = link.getAttribute('onclick');
        if (onclick && onclick.includes(`'${targetPage}'`)) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}



function initializeImageUploadPreviews() {
    // Handle regular image upload area
    const area = document.getElementById('imageUploadArea');
    const preview = document.getElementById('vistaPrevia');
    const input = document.getElementById('imagen');

    if (area && preview && input && !input.dataset.initialized) {
        input.dataset.initialized = 'true';

        // NO click listener needed - label's 'for' attribute handles this

        input.addEventListener('change', function (e) {
            const file = e.target.files && e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = function (evt) {
                preview.src = evt.target.result;
                preview.style.display = 'block';
                const ph = area.querySelector('.upload-placeholder');
                if (ph) ph.style.display = 'none';
            };
            reader.readAsDataURL(file);
        });
    }

    // Handle coordinator image upload area
    const areaC = document.getElementById('imageUploadAreaC');
    const previewC = document.getElementById('vistaPreviaC');
    const inputC = document.querySelectorAll('#imagen')[1]; // Second imagen input for coordinator

    if (areaC && previewC && inputC && !inputC.dataset.initialized) {
        inputC.dataset.initialized = 'true';

        // NO click listener needed - label's 'for' attribute handles this

        inputC.addEventListener('change', function (e) {
            const file = e.target.files && e.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = function (evt) {
                previewC.src = evt.target.result;
                previewC.style.display = 'block';
                const ph = areaC.querySelector('.upload-placeholder');
                if (ph) ph.style.display = 'none';
            };
            reader.readAsDataURL(file);
        });
    }
}


// Attaches image-required validation to the "Subir Proyecto" form.
// Must be called after AJAX content is injected (innerHTML does not execute <script> tags).
function initializeFormularioValidation() {
    const form = document.querySelector('form[action="' + baseUrl + 'escuela"]');
    const input = document.getElementById('imagen');

    if (!form || !input) return; // Not on the formulario page
    if (form.dataset.photoValidated) return; // Prevent duplicate listeners
    form.dataset.photoValidated = 'true';

    // Aplicar límites de fecha: min=hoy, max=hoy+5años, validación cruzada inicio/fin
    applyDateLimits(form, true);

    form.addEventListener('submit', function (e) {
        if (!input.files || input.files.length === 0) {
            e.preventDefault();
            e.stopImmediatePropagation();
            if (typeof showWarning === 'function') {
                showWarning('Por favor, agrega una foto antes de continuar.');
            } else {
                alert('Por favor, agrega una foto antes de continuar.');
            }
            return false;
        }
        // Deshabilitar todos los botones del formulario para evitar doble envío
        const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
        disableButtons(submitBtn, form);
    }, true); // capture phase so it fires before any other submit handler
}


// Attaches image-required validation to the "Registrar Maestro" form.
function initializeRegistroMValidation() {
    const form = document.querySelector('form[action="' + baseUrl + 'registroM"]');
    const input = document.getElementById('imagen');

    if (!form || !input) return;
    if (form.dataset.photoValidated) return;
    form.dataset.photoValidated = 'true';

    form.addEventListener('submit', function (e) {
        if (!input.files || input.files.length === 0) {
            e.preventDefault();
            e.stopImmediatePropagation();
            if (typeof showWarning === 'function') {
                showWarning('Por favor, agrega una foto del maestro antes de continuar.');
            } else {
                alert('Por favor, agrega una foto del maestro antes de continuar.');
            }
            return false;
        }
        const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
        disableButtons(submitBtn, form);
    }, true);
}


// Attaches image-required validation to the "Registrar Coordinador" form.
function initializeRegistroCValidation() {
    const form = document.querySelector('form[action="' + baseUrl + 'registroC"]');
    const input = document.getElementById('imagen');

    if (!form || !input) return;
    if (form.dataset.photoValidated) return;
    form.dataset.photoValidated = 'true';

    form.addEventListener('submit', function (e) {
        if (!input.files || input.files.length === 0) {
            e.preventDefault();
            e.stopImmediatePropagation();
            if (typeof showWarning === 'function') {
                showWarning('Por favor, agrega una foto del coordinador antes de continuar.');
            } else {
                alert('Por favor, agrega una foto del coordinador antes de continuar.');
            }
            return false;
        }
        const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
        disableButtons(submitBtn, form);
    }, true);
}


// Attaches image preview update to the "Editar Práctica" form.
// Called from editarPractica() after innerHTML injection (scripts inside innerHTML never execute).
function initializeEditarValidation() {
    const form = document.getElementById('formEditar');
    const input = document.getElementById('imagen');
    const area = document.getElementById('imageUploadArea');
    const preview = document.getElementById('vistaPrevia');

    if (!form || !input || !area || !preview) return;
    if (input.dataset.editInitialized) return; // prevent duplicate listeners
    input.dataset.editInitialized = 'true';

    // Aplicar límites de fecha: sin min (fechas pasadas son válidas al editar), max=hoy+5años
    applyDateLimits(form, false);

    // Update preview whenever the user picks a new image
    input.addEventListener('change', function (e) {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function (evt) {
            preview.src = evt.target.result;
            preview.style.display = 'block';
            const ph = area.querySelector('.upload-placeholder');
            if (ph) ph.style.display = 'none';
        };
        reader.readAsDataURL(file);
    });

    // Wire up submit → actualizarPractica (the IIFE in editar.php never ran)
    form.addEventListener('submit', function (e) {
        e.preventDefault();
        const placeholder = area.querySelector('.upload-placeholder');
        // Placeholder visible means no image at all (new project with nothing selected)
        if (placeholder && placeholder.style.display !== 'none') {
            if (typeof showWarning === 'function') {
                showWarning('Por favor, agrega una imagen antes de continuar.');
            } else {
                alert('Por favor, agrega una imagen antes de continuar.');
            }
            return;
        }
        if (typeof actualizarPractica === 'function') {
            const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
            disableButtons(submitBtn, form);
            actualizarPractica(e, form.dataset.practicaId);
        }
    });
}


function activateNavForPage(pageKey) {
    const navLinks = document.querySelectorAll('.nav-item a');
    let target = null;
    navLinks.forEach(link => {
        const on = link.getAttribute('onclick') || '';
        if (on.includes("'" + pageKey + "'") || on.includes('"' + pageKey + '"')) {
            target = link;
        }
    });
    if (target) {
        navLinks.forEach(l => l.classList.remove('active'));
        target.classList.add('active');
    }
}


window.goToAvailable = function () {
    activateNavForPage('inicio');
    loadContent('inicio');
}





function mostrarAlumno() {
    if (!idUsuario) {
        document.getElementById('infoUsuario').innerHTML = `<p>Error: ID de usuario no disponible.</p>`;
        document.getElementById('usuarioPanel').style.display = 'block';
        return;
    }

    fetch(`${baseUrl}obtenerA/${idUsuario}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                document.getElementById('infoUsuario').innerHTML = `<p>${data.error}</p>`;
            } else {
                const imgPath = `${baseUrl}alumnos/${data.ID}-${data.correo}.jpg`;
                document.getElementById('infoUsuario').innerHTML = `
                    <img src="${imgPath}" alt="Foto de perfil" width="100"><br>
                    <strong>Nombre:</strong> ${data.nombre}<br>
                    <strong>Carrera:</strong> ${data.carrera}<br>
                    <strong>Correo:</strong> ${data.correo}<br>
                `;
            }
            document.getElementById('usuarioPanel').style.display = 'block';
        })
        .catch(error => {
            console.error('Error al obtener los datos del alumno:', error);
            document.getElementById('infoUsuario').innerHTML = `<p>Error al cargar la información.</p>`;
            document.getElementById('usuarioPanel').style.display = 'block';
        });
}

function mostrarMaestro() {
    if (!idUsuario) {
        document.getElementById('infoUsuario').innerHTML = `<p>Error: ID de usuario no disponible.</p>`;
        document.getElementById('usuarioPanel').style.display = 'block';
        return;
    }

    fetch(`${baseUrl}obtenerM/${idUsuario}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                document.getElementById('infoUsuario').innerHTML = `<p>${data.error}</p>`;
            } else {
                const imgPath = `${baseUrl}maestros/${data.ID}-${data.correo}.jpg`;
                document.getElementById('infoUsuario').innerHTML = `
                    <img src="${imgPath}" alt="Foto de perfil" width="100"><br>
                    <strong>Nombre:</strong> ${data.nombre}<br>
                    <strong>Departamento:</strong> ${data.departamento}<br>
                    <strong>Correo:</strong> ${data.correo}<br>
                `;
            }
            document.getElementById('usuarioPanel').style.display = 'block';
        })
        .catch(error => {
            console.error('Error al obtener los datos del maestro:', error);
            document.getElementById('infoUsuario').innerHTML = `<p>Error al cargar la información.</p>`;
            document.getElementById('usuarioPanel').style.display = 'block';
        });
}

function mostrarCoordinador() {
    if (!idUsuario) {
        document.getElementById('infoUsuario').innerHTML = `<p>Error: ID de usuario no disponible.</p>`;
        document.getElementById('usuarioPanel').style.display = 'block';
        return;
    }

    fetch(`${baseUrl}obtenerC/${idUsuario}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                document.getElementById('infoUsuario').innerHTML = `<p>${data.error}</p>`;
            } else {
                const imgPath = `${baseUrl}coordinadores/${data.ID}-${data.correo}.jpg`;
                document.getElementById('infoUsuario').innerHTML = `
                    <img src="${imgPath}" alt="Foto de perfil" width="100"><br>
                    <strong>Nombre:</strong> ${data.nombre}<br>
                    <strong>Departamento:</strong> ${data.departamento}<br>
                    <strong>Correo:</strong> ${data.correo}<br>
                `;
            }
            document.getElementById('usuarioPanel').style.display = 'block';
        })
        .catch(error => {
            console.error('Error al obtener los datos del coordinador:', error);
            document.getElementById('infoUsuario').innerHTML = `<p>Error al cargar la información.</p>`;
            document.getElementById('usuarioPanel').style.display = 'block';
        });
}

function mostrarModerador() {
    if (!idUsuario) {
        document.getElementById('infoUsuario').innerHTML = `<p>Error: ID de usuario no disponible.</p>`;
        document.getElementById('usuarioPanel').style.display = 'block';
        return;
    }

    fetch(`${baseUrl}obtenerMo/${idUsuario}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                document.getElementById('infoUsuario').innerHTML = `<p>${data.error}</p>`;
            } else {
                const imgPath = `${baseUrl}moderadores/${data.ID}-${data.correo}.jpg`;
                document.getElementById('infoUsuario').innerHTML = `
                    <img src="${imgPath}" alt="Foto de perfil" width="100"><br>
                    <strong>Nombre:</strong> ${data.nombre}<br>
                    <strong>Departamento:</strong> ${data.departamento}<br>
                    <strong>Correo:</strong> ${data.correo}<br>
                `;
            }
            document.getElementById('usuarioPanel').style.display = 'block';
        })
        .catch(error => {
            console.error('Error al obtener los datos del moderador:', error);
            document.getElementById('infoUsuario').innerHTML = `<p>Error al cargar la información.</p>`;
            document.getElementById('usuarioPanel').style.display = 'block';
        });
}

function cerrarPanel() {
    document.getElementById('usuarioPanel').style.display = 'none';
}





// Expose selection handlers globally for revisar view
window.selectReviewProject = function (cardEl) {
    const id = cardEl.dataset.id;
    const titulo = cardEl.dataset.titulo || 'Proyecto';
    const carrera = cardEl.dataset.carrera || '—';
    const estado = cardEl.dataset.estado || '—';
    const integrantes = cardEl.dataset.integrantes || '—';
    const imgUrl = cardEl.dataset.img || '';

    const panel = document.getElementById('revDetailPanel');
    if (!panel) return;

    const imageBlock = imgUrl
        ? `<div class="selected-project-image" id="revImageWrapper"><img src="${imgUrl}" alt="Imagen del proyecto" style="width:100%;height:100%;object-fit:cover;"></div>`
        : `<div class="selected-project-image placeholder" id="revImageWrapper"><span>Sin imagen disponible</span></div>`;

    panel.innerHTML = `
        ${imageBlock}
        <div id="revDetailSection">
            <div class="selected-project-info">
                <h3 id="revTitulo">${titulo}</h3>
                <div class="detail-row"><strong>ID del Proyecto:</strong><p id="revId">${id}</p></div>
                <div class="detail-row"><strong>Carrera:</strong><p id="revCarrera">${carrera}</p></div>
                <div class="detail-row"><strong>Estado:</strong><p id="revEstado">${estado}</p></div>
                <div class="detail-row"><strong>Integrantes:</strong><p id="revIntegrantes">${integrantes}</p></div>
                <div class="detail-row"><strong>Fase:</strong><p>En revisión (Fase 1)</p></div>
            </div>
            <div class="button-container">
                <button class="btn btn-secondary" id="revRejectBtn" onclick="rejectSelected()" data-id="${id}">Desaprobar Proyecto</button>
                <button class="btn btn-primary" id="revApproveBtn" onclick="approveSelected()" data-id="${id}">Aprobar Proyecto</button>
            </div>
        </div>`;
};

window.approveSelected = function () {
    const btn = document.getElementById('revApproveBtn');
    if (btn && btn.dataset.id) {
        fase(btn.dataset.id);
    }
}

window.rejectSelected = function () {
    const btn = document.getElementById('revRejectBtn');
    if (!btn || !btn.dataset.id) return;
    const id = btn.dataset.id;

    showConfirm('¿Estás seguro de que deseas desaprobar este proyecto?', function () {
        // Deshabilitar todos los botones SIN activar _actionInProgress.
        // La bandera solo se activa al enviar el formulario del motivo.
        window._actionInProgress = false;
        document.querySelectorAll('button, input[type="submit"], a.btn').forEach(function (el) {
            el.disabled = true;
            el.style.pointerEvents = 'none';
        });

        if (!document.getElementById('revRejectionModal')) {
            var modalHtml = `
<div class="modal fade bootstrap-modal" id="revRejectionModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content modern-modal">
            <form id="formRevRechazo">
                <input type="hidden" name="id" id="revRechazoId">
                <div class="modal-header modern-modal-header">
                    <div class="modal-icon-wrapper"><span class="modal-icon warning">⚠️</span></div>
                    <h5 class="modal-title modern-modal-title">Motivo de Rechazo</h5>
                </div>
                <div class="modal-body modern-modal-body">
                    <p class="modal-description">Por favor, proporciona una explicación del motivo por el cual se rechaza este proyecto. Este mensaje será enviado al responsable.</p>
                    <div class="input-group-modern">
                        <label for="revRejComment" class="modern-label">Motivo del rechazo</label>
                        <textarea class="form-control modern-textarea" id="revRejComment" name="comment" rows="5" placeholder="Describe el motivo del rechazo..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer modern-modal-footer">
                    <button type="button" class="btn btn-secondary modern-btn-cancel" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary modern-btn-submit">Enviar correo</button>
                </div>
            </form>
        </div>
    </div>
</div>`;
            document.body.insertAdjacentHTML('beforeend', modalHtml);

            document.getElementById('formRevRechazo').addEventListener('submit', function (e) {
                e.preventDefault();
                var formData = new FormData(this);
                // Asegurar que todos los botones sigan bloqueados tras el submit
                lockAllButtons();
                $('#revRejectionModal').modal('hide');

                fetch(baseUrl + 'home/sendCommentP', {
                    method: 'POST',
                    body: formData
                })
                    .then(function (response) {
                        if (!response.ok) throw new Error('Error en la petición');
                        return response.text();
                    })
                    .then(function () {
                        showSuccess('Proyecto rechazado: Se notificó al responsable', function () {
                            loadContent('revisar');
                        });
                    })
                    .catch(function (error) {
                        console.error('Error:', error);
                        showError('Error al procesar el rechazo');
                        unlockAllButtons();
                    });
            });

            // Solo rehabilitar botones si el modal fue cerrado SIN haber enviado (cancelación)
            $('#revRejectionModal').on('hidden.bs.modal', function () {
                if (!window._actionInProgress) {
                    unlockAllButtons();
                }
            });
        }

        document.getElementById('revRechazoId').value = id;
        document.getElementById('revRejComment').value = '';
        // Re-habilitar solo los botones del modal para que el usuario pueda interactuar con él
        var modalForm = document.getElementById('formRevRechazo');
        if (modalForm) {
            modalForm.querySelectorAll('button, input[type="submit"]').forEach(function (b) {
                b.disabled = false;
                b.style.pointerEvents = '';
            });
        }
        $('#revRejectionModal').modal('show');
    });
}


window.selectTrashProject = function (cardEl) {
    const id = cardEl.dataset.id;
    const titulo = cardEl.dataset.titulo || 'Proyecto';
    const carrera = cardEl.dataset.carrera || '—';
    const estado = cardEl.dataset.estado || '—';
    const integrantes = cardEl.dataset.integrantes || '—';
    const imgUrl = cardEl.dataset.img || '';

    const panel = document.getElementById('trashDetailPanel');
    if (!panel) return;

    const imageBlock = imgUrl
        ? `<div class="selected-project-image" id="trashImageWrapper"><img src="${imgUrl}" alt="Imagen del proyecto" style="width:100%;height:100%;object-fit:cover;"></div>`
        : `<div class="selected-project-image placeholder" id="trashImageWrapper"><span>Sin imagen disponible</span></div>`;

    panel.innerHTML = `
        ${imageBlock}
        <div id="trashDetailSection">
            <div class="selected-project-info">
                <h3 id="trashTitulo">${titulo}</h3>
                <div class="detail-row"><strong>ID del Proyecto:</strong><p id="trashId">${id}</p></div>
                <div class="detail-row"><strong>Carrera:</strong><p id="trashCarrera">${carrera}</p></div>
                <div class="detail-row"><strong>Estado:</strong><p id="trashEstado">${estado}</p></div>
                <div class="detail-row"><strong>Integrantes:</strong><p id="trashIntegrantes">${integrantes}</p></div>
                <div class="detail-row"><strong>Fase:</strong><p>En papelera (Fase 0)</p></div>
            </div>
            <div class="button-container">
                <button class="btn btn-secondary" id="trashRestoreBtn" onclick="restoreSelected()" data-id="${id}">Restaurar</button>
                <button class="btn btn-primary" id="trashDeleteBtn" onclick="executeTrashDeletion(event)" data-id="${id}">Eliminar definitivamente</button>
            </div>
        </div>`;
};

window.restoreSelected = function () {
    const btn = document.getElementById('trashRestoreBtn');
    if (btn && btn.dataset.id) {
        showConfirm('¿Estás seguro de que deseas restaurar este proyecto?', function () {
            lockAllButtons();

            fetch(`${baseUrl}/fase/${btn.dataset.id}`, { method: 'POST' })
                .then(r => r.ok ? r.json() : Promise.reject())
                .then(data => {
                    showSuccess('Proyecto restaurado correctamente', function () {
                        loadContent('papelera');
                    });
                })
                .catch(() => {
                    showError('Error al restaurar el proyecto');
                    unlockAllButtons();
                });
        });
    }
}

window.executeTrashDeletion = function (event) {
    if (event) event.preventDefault();
    const btn = document.getElementById('trashDeleteBtn');
    if (btn && btn.dataset.id) {
        const id = btn.dataset.id;
        showConfirm('¿Estás seguro de que deseas eliminar este proyecto definitivamente?', function () {
            lockAllButtons();

            fetch(`${baseUrl}coordinador/eliminarPermanente/${id}`, {
                method: 'POST'
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showSuccess('Proyecto eliminado', function () {
                            loadContent('papelera');
                        });
                    } else {
                        showError('Error al eliminar el proyecto');
                        unlockAllButtons();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showError('Error al eliminar el proyecto');
                    unlockAllButtons();
                });
        });
    }
}

function revisar(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/revision/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar la práctica');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
            initializeImageUploadPreviews();
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar la práctica.</p>';
            console.error('Error:', error);
        });
}

function fase(id) {
    const btn = document.getElementById('revApproveBtn');
    disableButtons(btn);
    fetch(`${baseUrl}/fase/${id}`, {
        method: 'POST'
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al actualizar la práctica');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                showSuccess('Estado del proyecto actualizado', function () {
                    loadContent('inicio');
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Error al actualizar la práctica');
            enableButtons(btn);
        });
}





function papelera(id) {
    // Primero verificar si hay alumnos vinculados
    fetch(`${baseUrl}/checkStudents/${id}`)
        .then(response => response.json())
        .then(data => {
            var mensaje = '¿Estás seguro de que deseas enviar este proyecto a la papelera?';
            if (data.count > 0) {
                mensaje = 'Esta práctica tiene ' + data.count + ' alumno(s) vinculado(s). Serán desvinculados del proyecto. ¿Deseas continuar?';
            }
            showConfirm(mensaje, function () {
                lockAllButtons();
                fetch(`${baseUrl}/papelera/${id}`, {
                    method: 'POST'
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Error al eliminar la práctica');
                        }
                        return response.json();
                    })
                    .then(result => {
                        if (result.success) {
                            showSuccess('Proyecto enviado a la papelera', function () {
                                loadContent('inicio');
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showError('Error al eliminar la práctica');
                        unlockAllButtons();
                    });
            });
        })
        .catch(error => {
            console.error('Error al verificar estudiantes:', error);
            showError('Error al verificar estudiantes vinculados');
        });
}

function borrar(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/borracion/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar la práctica');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
            initializeImageUploadPreviews();
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar la práctica.</p>';
            console.error('Error:', error);
        });
}





function loadPractica(id) {
    const contentDiv = document.getElementById('content');

    // Save current page to history before loading project details
    if (window.currentPage) {
        window.navigationHistory.push(window.currentPage);
    }
    window.currentPage = `practica_${id}`;

    fetch(`${baseUrl}/vista/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar la práctica');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
            initializeImageUploadPreviews();
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar la práctica.</p>';
            console.error('Error:', error);
        });
}

function editarPractica(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/editar/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar el formulario de edición');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
            initializeEditarValidation();
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar el formulario de edición.</p>';
            console.error('Error:', error);
        });
}

function actualizarPractica(event, id) {
    event.preventDefault();

    const form = event.target || document.getElementById('formEditar');
    const formData = new FormData(form);

    fetch(`${baseUrl}/actualizar/${id}`, {
        method: 'POST',
        body: formData
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al actualizar la práctica');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                showSuccess('Práctica actualizada correctamente', function () {
                    loadContent('inicio');
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Error al actualizar la práctica');
            // Rehabilitar botones si la actualización falla
            if (form) {
                const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
                enableButtons(submitBtn, form);
            }
        });
}

function eliminarPractica(id) {
    // Primero verificar si hay alumnos vinculados
    fetch(`${baseUrl}/checkStudents/${id}`)
        .then(response => response.json())
        .then(data => {
            var mensaje = '¿Estás seguro de que deseas eliminar esta práctica?';
            if (data.count > 0) {
                mensaje = 'Esta práctica tiene ' + data.count + ' alumno(s) vinculado(s). Serán desvinculados del proyecto. ¿Deseas continuar?';
            }
            showConfirm(mensaje, function () {
                lockAllButtons();
                fetch(`${baseUrl}/eliminar/${id}`, {
                    method: 'DELETE'
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Error al eliminar la práctica');
                        }
                        return response.json();
                    })
                    .then(result => {
                        if (result.success) {
                            showSuccess('Práctica eliminada correctamente', function () {
                                loadContent('inicio');
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showError('Error al eliminar la práctica');
                        unlockAllButtons();
                    });
            });
        })
        .catch(error => {
            console.error('Error al verificar estudiantes:', error);
            showError('Error al verificar estudiantes vinculados');
        });
}


function mostrarIMG() {
    document.getElementById('imagen').addEventListener('change', function (event) {
        const file = event.target.files[0];
        const reader = new FileReader();

        reader.onload = function () {
            let output = document.getElementById('vistaPrevia');
            output.src = reader.result;
            output.style.display = 'block';
        }
        reader.readAsDataURL(file);
    });
}

function filtrarFilas() {
    const input = document.getElementById("buscador");
    if (!input) return;
    const filter = input.value.toLowerCase().trim();

    const contenedor = document.getElementById("resultado-filtro");
    if (!contenedor) return;

    const tarjetas = contenedor.querySelectorAll(".enrolled-project-card");

    tarjetas.forEach(function (tarjeta) {
        const titulo = tarjeta.querySelector("h3");
        const texto = titulo ? titulo.innerText.toLowerCase() : "";
        tarjeta.style.display = texto.includes(filter) ? "" : "none";
    });
}

function aplicarFiltros() {
    const estatus = document.getElementById("filtro-estatus").value;
    const fecha = document.getElementById("filtro-fecha").value;
    const carrera = document.getElementById("filtro-carrera").value;
    const integrantes = document.getElementById("filtro-integrantes").value;

    const params = new URLSearchParams({
        estatus,
        fecha,
        carrera,
        integrantes
    });

    fetch(`${baseUrl}/carga/buscar?${params}`)
        .then(res => res.text())
        .then(html => {

            const temp = document.createElement('div');
            temp.innerHTML = html;
            const practicas = temp.querySelector("#resultado-filtro");

            if (practicas) {
                document.getElementById("resultado-filtro").innerHTML = practicas.innerHTML;
            }
        })
        .catch(err => {
            console.error("Error al aplicar filtros:", err);
        });
}

function restaurarFiltros() {
    document.getElementById("filtro-estatus").value = "";
    document.getElementById("filtro-fecha").value = "";
    document.getElementById("filtro-carrera").value = "";
    document.getElementById("filtro-integrantes").value = "";

    aplicarFiltros();
}

// ----------------------------- Alumnos ------------------------------- //

function loadPracticaA(id) {
    const contentDiv = document.getElementById('content');

    // Save current page to history before loading project details
    if (window.currentPage) {
        window.navigationHistory.push(window.currentPage);
    }
    window.currentPage = `practicaA_${id}`;

    fetch(`${baseUrl}/vistaA/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar la práctica');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar la práctica.</p>';
            console.error('Error:', error);
        });
}

function aplicar(id) {
    const contentDiv = document.getElementById('content');
    showConfirm('¿Estás seguro de que quieres aplicar para esta práctica?', function () {
        // Deshabilitar botones de acción del detalle del proyecto
        document.querySelectorAll('.action-buttons button, .project-actions button').forEach(function (b) {
            b.disabled = true;
        });
        fetch(`${baseUrl}/aplicar/${id}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al cargar la práctica');
                }
                return response.text();
            })
            .then(data => {
                contentDiv.innerHTML = data;
                showSuccess('Has aplicado correctamente');
            })
            .catch(error => {
                contentDiv.innerHTML = '<p>Error al cargar la práctica</p>';
                console.error('Error:', error);
            });

    });

}

function estudiantes(id) {
    // Inline render inside project detail view; keep left image
    const panel = document.querySelector('.project-detail-card .project-info-container');
    const imgContainer = document.querySelector('.project-detail-card .project-image-container');
    if (!panel || !imgContainer) {
        // Fallback to previous navigation if structure isn't present
        const contentDiv = document.getElementById('content');
        fetch(`${baseUrl}/estudiantes/${id}`).then(r => r.text()).then(html => { contentDiv.innerHTML = html; });
        return;
    }

    fetch(`${baseUrl}/api/estudiantes/${id}`)
        .then(res => res.json())
        .then(json => {
            const items = (json && json.data) ? json.data : [];
            const header = `
                  <h2 class=\"project-detail-title\">Estudiantes</h2>
                  <div class=\"info-group\"><p class=\"text-left\">Estudiantes aceptados en este proyecto</p></div>
              `;
            if (!items.length) {
                panel.innerHTML = `${header}<div class=\"no-projects\"><h3>No hay estudiantes aún</h3><p>Cuando existan, aparecerán aquí.</p></div>`;
                return;
            }
            const cards = items.map(a => {
                const img = `${baseUrl}alumnos/${a.ID}-${a.correo}.jpg`;
                return `
                  <div class=\"applicant-card\">
                      <div class=\"applicant-image\"><img src=\"${img}\" onerror=\"this.style.display='none'\" alt=\"${a.nombre}\"></div>
                      <div class=\"applicant-info\">
                          <h4 class=\"applicant-name\">${a.nombre}</h4>
                          <p class=\"applicant-field\"><strong>Carrera:</strong> ${a.carrera}</p>
                          <p class=\"applicant-field\"><strong>Correo:</strong> ${a.correo}</p>
                          <div class=\"applicant-actions\">
                              <button class=\"btn btn-secondary\" onclick=\"rechazar(${a.ID})\">Eliminar</button>
                          </div>
                      </div>
                  </div>`;
            }).join('');
            panel.innerHTML = `${header}<div class=\"applicant-list\">${cards}</div>`;
        })
        .catch(() => {
            panel.innerHTML = '<div class=\"error-message\"><h2>Error</h2><p>No se pudieron cargar los estudiantes.</p></div>';
        });
}

function postulados(id) {
    // Try inline render inside current detail view; keep image
    const panel = document.querySelector('.project-detail-card .project-info-container');
    const imgContainer = document.querySelector('.project-detail-card .project-image-container');
    if (!panel || !imgContainer) {
        // Fallback: navigate as before
        const contentDiv = document.getElementById('content');
        fetch(`${baseUrl}/postulados/${id}`)
            .then(r => r.text())
            .then(html => { contentDiv.innerHTML = html; })
            .catch(() => { contentDiv.innerHTML = '<p>Error al cargar la lista.</p>'; });
        return;
    }

    fetch(`${baseUrl}/api/postulados/${id}`)
        .then(res => res.json())
        .then(json => {
            const items = (json && json.data) ? json.data : [];
            const header = `
                  <h2 class="project-detail-title">Postulados</h2>
                  <div class="info-group"><p class="text-left">Aplicantes para este proyecto</p></div>
              `;
            if (!items.length) {
                panel.innerHTML = `${header}<div class="no-projects"><h3>No hay postulados aún</h3><p>Cuando existan, aparecerán aquí.</p></div>`;
                return;
            }
            const cards = items.map(a => {
                const img = `${baseUrl}alumnos/${a.ID}-${a.correo}.jpg`;
                return `
                  <div class="applicant-card">
                      <div class="applicant-image"><img src="${img}" onerror="this.style.display='none'" alt="${a.nombre}"></div>
                      <div class="applicant-info">
                          <h4 class="applicant-name">${a.nombre}</h4>
                          <p class="applicant-field"><strong>Carrera:</strong> ${a.carrera}</p>
                          <p class="applicant-field"><strong>Correo:</strong> ${a.correo}</p>
                          <div class="applicant-actions">
                              <button class="btn btn-secondary" onclick="rechazar(${a.ID})">Rechazar</button>
                              <button class="btn btn-primary" onclick="aprobar(${a.ID})">Aprobar</button>
                          </div>
                      </div>
                  </div>`;
            }).join('');
            panel.innerHTML = `${header}<div class="applicant-list">${cards}</div>`;
        })
        .catch(() => {
            panel.innerHTML = '<div class="error-message"><h2>Error</h2><p>No se pudieron cargar los postulados.</p></div>';
        });
}

function datos_estudiante(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/datos_estudiante/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar el estudiante');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar el estudiante.</p>';
            console.error('Error:', error);
        });
}

function datos_postulados(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/datos_postulados/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar el estudiante');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar el estudiante.</p>';
            console.error('Error:', error);
        });
}

function aprobar(id) {
    showConfirm('¿Estás seguro de que quieres aprobar el estudiante?', function () {
        lockAllButtons();
        fetch(`${baseUrl}/aprobar/${id}`)
            .then(response => response.text())
            .then(function () {
                showSuccess('Estudiante aprobado correctamente', function () {
                    loadContent('inicio');
                });
            })
            .catch(error => {
                console.error('Error:', error);
                showError('Error al aprobar el estudiante');
                unlockAllButtons();
            });

    });
}

// Inject modal and styles if not present
function injectStudentRejectionModal() {
    if (!document.getElementById('studentRejectionModal')) {
        const modalHtml = `
<div class="modal fade bootstrap-modal" id="studentRejectionModal" tabindex="-1" role="dialog" aria-labelledby="studentRejectionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content modern-modal">
            <form id="formRechazoEstudiante">
                <input type="hidden" name="id" id="rechazoAlumnoId">
                <div class="modal-header modern-modal-header">
                    <div class="modal-icon-wrapper">
                        <span class="modal-icon warning">⚠️</span>
                    </div>
                    <h5 class="modal-title modern-modal-title" id="studentRejectionModalLabel">Motivo de Eliminación</h5>
                </div>
                <div class="modal-body modern-modal-body">
                    <p class="modal-description">Ingrese el motivo para retirar al estudiante. Se le notificará por correo.</p>
                    <div class="input-group-modern">
                        <label for="commentRechazo" class="modern-label">Motivo de la baja</label>
                        <textarea class="form-control modern-textarea" id="commentRechazo" name="comment" rows="5" placeholder="Describe el motivo..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer modern-modal-footer">
                    <button type="button" class="btn btn-secondary modern-btn-cancel" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary modern-btn-submit">Enviar correo</button>
                </div>
            </form>
        </div>
    </div>
</div>
<style id="studentRejectionStyles">
.modern-modal { border: none; border-radius: 12px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15); overflow: hidden; }
.modern-modal-header { background: linear-gradient(135deg, #2675db 0%, #1e5bb8 100%); color: white; border: none; padding: 2rem 1.5rem 1.5rem; position: relative; text-align: center; }
.modal-icon { font-size: 3rem; display: inline-block; }
.modern-modal-title { font-size: 1.5rem; font-weight: 600; margin: 0; color: white; }
.modern-close { position: absolute; top: 1rem; right: 1rem; color: white; opacity: 0.8; font-size: 1.5rem; font-weight: 300; transition: opacity 0.2s; }
.modern-close:hover { opacity: 1; }
.modern-modal-body { padding: 2rem 1.5rem; background: #f8f9fa; }
.input-group-modern { text-align: left; width: 100%; display: block; }
.modal-description { color: #666666; font-size: 0.95rem; margin-bottom: 1.5rem; line-height: 1.6; text-align: center; }
.modern-label { font-weight: 600; color: #333333; margin-bottom: 0.5rem; display: block; width: 100%; }
.modern-textarea { border: 2px solid #e0e0e0; border-radius: 8px; padding: 0.75rem; font-size: 0.95rem; transition: all 0.3s ease; resize: vertical; width: 100% !important; display: block; }
.modern-textarea:focus { border-color: #2675db; box-shadow: 0 0 0 3px rgba(38, 117, 219, 0.1); outline: none; }
.modern-modal-footer { background: white !important; border-top: 1px solid #e9ecef !important; padding: 1rem 1.5rem !important; display: flex !important; flex-direction: row !important; flex-wrap: nowrap !important; gap: 0.75rem !important; justify-content: center !important; align-items: center !important; }
.modern-modal-footer .modern-btn-cancel, .modern-modal-footer .modern-btn-submit { padding: 0.75rem 2rem !important; padding-left: 2rem !important; padding-right: 2rem !important; font-weight: 500 !important; border-radius: 25px !important; border: none !important; cursor: pointer !important; transition: all 0.3s ease !important; font-size: 1rem !important; min-width: 150px !important; width: auto !important; display: inline-flex !important; justify-content: center !important; align-items: center !important; flex: 0 0 auto !important; margin: 0 !important; text-align: center !important; white-space: nowrap !important; }
.modern-modal-footer .modern-btn-cancel { background-color: #2675db !important; color: white !important; order: 1 !important; }
.modern-modal-footer .modern-btn-cancel:hover { background-color: #1e5bb8 !important; transform: translateY(-2px) !important; box-shadow: 0 4px 12px rgba(38, 117, 219, 0.3) !important; }
.modern-modal-footer .modern-btn-submit { background-color: #2675db !important; color: white !important; order: 2 !important; }
.modern-modal-footer .modern-btn-submit:hover { background-color: #1e5bb8 !important; transform: translateY(-2px) !important; box-shadow: 0 4px 16px rgba(38, 117, 219, 0.4) !important; }
</style>`;
        document.body.insertAdjacentHTML('beforeend', modalHtml);

        // Add submit handler
        document.getElementById('formRechazoEstudiante').addEventListener('submit', function (e) {
            e.preventDefault();
            const id = document.getElementById('rechazoAlumnoId').value;
            const formData = new FormData(this);
            // Append ID manually if not picked up (input disabled/hidden issues sometimes)
            formData.set('id', id);

            // Bloquear TODOS los botones — se mantendrán bloqueados hasta la redirección
            lockAllButtons();

            // Manually hide modal (Bootstrap 4 compatible without jQuery)
            hideStudentRejectionModal();

            // Use sendCommentA to send email and delete
            fetch(`${baseUrl}home/sendCommentA`, {
                method: 'POST',
                body: formData
            })
                .then(response => {
                    if (!response.ok) throw new Error('Error en la petición');
                    return response.text();
                })
                .then(data => {
                    showSuccess('Acción completada: Alumno notificado y rechazado', function () {
                        loadContent('inicio');
                    });
                })
                .catch(error => {
                    console.error('Error:', error);
                    showError('Error al procesar la solicitud');
                    unlockAllButtons();
                });
        });

        // Add close button handlers
        const closeButtons = document.querySelectorAll('#studentRejectionModal [data-dismiss="modal"]');
        closeButtons.forEach(btn => {
            btn.addEventListener('click', function () {
                hideStudentRejectionModal();
            });
        });

        // Add backdrop click handler
        document.addEventListener('click', function (e) {
            if (e.target.classList.contains('modal-backdrop')) {
                hideStudentRejectionModal();
            }
        });
    }
}

// Helper function to show modal manually (Bootstrap 4 compatible)
function showStudentRejectionModal() {
    const modal = document.getElementById('studentRejectionModal');
    if (!modal) return;

    // Add backdrop
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop fade show';
    backdrop.id = 'studentRejectionBackdrop';
    document.body.appendChild(backdrop);

    // Show modal
    modal.classList.add('show');
    modal.style.display = 'block';
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('role', 'dialog');
    modal.removeAttribute('aria-hidden');
    document.body.classList.add('modal-open');
}

// Helper function to hide modal manually (Bootstrap 4 compatible)
function hideStudentRejectionModal() {
    const modal = document.getElementById('studentRejectionModal');
    const backdrop = document.getElementById('studentRejectionBackdrop');

    if (modal) {
        modal.classList.remove('show');
        modal.style.display = 'none';
        modal.setAttribute('aria-hidden', 'true');
        modal.removeAttribute('aria-modal');
        modal.removeAttribute('role');
    }

    if (backdrop) {
        backdrop.remove();
    }

    document.body.classList.remove('modal-open');

    // Solo rehabilitar botones si NO hay una acción en progreso (es decir, fue una cancelación)
    if (!window._actionInProgress) {
        unlockAllButtons();
    }
}

function rechazar(id) {
    injectStudentRejectionModal();
    document.getElementById('rechazoAlumnoId').value = id;
    document.getElementById('commentRechazo').value = '';

    // Deshabilitar todos los botones de la página SIN activar la bandera _actionInProgress.
    // La bandera solo se activa al enviar el formulario (Enviar correo).
    // Esto permite que al dar Cancelar, los botones se rehabiliten correctamente.
    window._actionInProgress = false;
    document.querySelectorAll('button, input[type="submit"], a.btn').forEach(function (el) {
        el.disabled = true;
        el.style.pointerEvents = 'none';
    });

    // Re-habilitar solo los botones del propio modal para que el usuario pueda interactuar
    var modalForm = document.getElementById('formRechazoEstudiante');
    if (modalForm) {
        modalForm.querySelectorAll('button, input[type="submit"]').forEach(function (b) {
            b.disabled = false;
            b.style.pointerEvents = '';
        });
    }

    showStudentRejectionModal();
}

// ----------------------------- Empresas ------------------------------- //

function loadEmpresa(id) {
    const contentDiv = document.getElementById('content');

    fetch(`${baseUrl}/vistaE/${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al cargar la empresa');
            }
            return response.text();
        })
        .then(data => {
            contentDiv.innerHTML = data;
        })
        .catch(error => {
            contentDiv.innerHTML = '<p>Error al cargar la empresa.</p>';
            console.error('Error:', error);
        });
}

function unirse(id) {
    showConfirm('¿Estás seguro de que quieres aprobar esta empresa?', function () {
        lockAllButtons();
        fetch(`${baseUrl}/unirse/${id}`, {
            method: 'POST'
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al aprobar la empresa');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    showSuccess('Empresa aprobada exitosamente', function () {
                        loadContent('empresas');
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showError('Error al aprobar la empresa');
                unlockAllButtons();
            });
    });
}

// --------------------------------------------------------------------- //

// ---------------------- Project Deletion (Database) ---------------------- //
window.confirmarEliminacionPractica = function () {
    // Directly show the modal without SweetAlert confirmation
    $('#commentModal').modal('show');
};

function prepararRechazoEmpresa(id) {
    // Deshabilitar todos los botones SIN activar _actionInProgress.
    // La bandera solo se activa al enviar el formulario (rechazarEmpresaSubmit).
    window._actionInProgress = false;
    document.querySelectorAll('button, input[type="submit"], a.btn').forEach(function (el) {
        el.disabled = true;
        el.style.pointerEvents = 'none';
    });

    if (!document.getElementById('commentModalEmpresa')) {
        var modalHtml = `
<div class="modal fade bootstrap-modal" id="commentModalEmpresa" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content modern-modal">
            <form id="formRechazarEmpresa" action="${baseUrl}/home/sendCommentE" method="post" onsubmit="rechazarEmpresaSubmit(event, this)">
                <input type="hidden" name="id" id="rechazarEmpresaId">
                <div class="modal-header modern-modal-header">
                    <div class="modal-icon-wrapper"><span class="modal-icon warning">⚠️</span></div>
                    <h5 class="modal-title modern-modal-title">Motivo de Rechazo</h5>
                </div>
                <div class="modal-body modern-modal-body">
                    <p class="modal-description">Por favor, proporciona una explicación por el cual se rechaza esta empresa. Este mensaje será enviado al solicitante.</p>
                    <div class="input-group-modern">
                        <label for="commentRechazoEmpresa" class="modern-label">Motivo del rechazo</label>
                        <textarea class="form-control modern-textarea" id="commentRechazoEmpresa" name="comment" rows="5" placeholder="Describe el motivo del rechazo..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer modern-modal-footer">
                    <button type="button" class="btn btn-secondary modern-btn-cancel" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary modern-btn-submit">Enviar correo</button>
                </div>
            </form>
        </div>
    </div>
</div>`;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    }

    document.getElementById('rechazarEmpresaId').value = id;
    var modal = $('#commentModalEmpresa');

    // Re-habilitar solo los botones del modal para que el usuario pueda interactuar
    var modalForm = document.getElementById('formRechazarEmpresa');
    if (modalForm) {
        modalForm.querySelectorAll('button, input[type="submit"]').forEach(function (b) {
            b.disabled = false;
            b.style.pointerEvents = '';
        });
    }

    // Solo rehabilitar el resto de botones si el modal fue cerrado SIN enviar (cancelación)
    modal.off('hide.bs.modal').on('hide.bs.modal', function () {
        if (!window._actionInProgress) {
            unlockAllButtons();
        }
    });

    modal.modal('show');
}

function rechazarEmpresaSubmit(event, form) {
    event.preventDefault();
    var formData = new FormData(form);
    var modal = $('#commentModalEmpresa');

    // Bloquear TODOS los botones — se mantendrán bloqueados hasta la redirección
    lockAllButtons();

    fetch(form.action, {
        method: 'POST',
        body: formData
    })
        .then(response => {
            if (!response.ok) throw new Error('Network error');
            return response.text();
        })
        .then(data => {
            modal.modal('hide');
            showSuccess('Se rechazó la empresa y se notificó exitosamente.', function () {
                loadContent('empresas');
            });
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Error al rechazar la empresa.');
            unlockAllButtons();
        });
}
